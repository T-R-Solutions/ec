# Portable source notes

Bibliographic and reading-scope snapshot from the authoring library. No books or research ledgers are required to use this skill. Extraction does not establish reading, and historical reading does not establish execution or current platform compatibility. No new reading or example execution occurred during packaging.

## B03: AI Engineering: Building Applications with Foundation Models

Authors: Chip Huyen. Edition/year: 1st, December 2024; copyright 2025.

Examined sections: ch. 4 pp. 200–206; ch. 5 pp. 233–235 and 248–251. Metadata examined: PDF 5–6.

Analyzed physical PDF ranges (1-based): [[224, 230], [257, 259], [272, 275]]. Visual pages: []. Book examples executed: False.

Source of this portable copy: `prompt/references/portable-sources.md` in the authoring library; SHA-256 before adaptation: `2e55aa1b138beb140f2b598ef04cf4737df5fc09a4e832ed93225cd5c3e59be4`. This copy is independently usable; reconcile technical changes manually when updating.

## Extraction and interpretation limits

Only the listed sections were analyzed. All other content remains unanalyzed. Diagrams and images were not visually inspected, except the GC copyright page explicitly recorded above; EPUB figures were not inspected. Error-free text extraction does not establish full fidelity.
