# Skills candidatas alinhadas à biblioteca

Este diretório preserva as **40 skills recebidas**, agora com a mesma separação
entre método técnico e integração SDD usada no projeto. Elas continuam candidatas:
não foram promovidas ao catálogo principal nem instaladas no ambiente do agente.

```text
skills/<nome>/SKILL.md       Entrada independente e referências internas
sdd/chain/<nome>.md          Ponte opcional; skill_path precisa ser configurado
```

Os lotes anteriores tinham 15 skills genéricas de interface/protocolos (`01`),
16 especializações do produto Ec (`02`) e nove competências CI/CD (`03`).
Nomes e proveniência foram preservados no
[registro da adaptação](../doc/skills/new-skills-alignment-2026-11-02/report.md).
As especializações Ec continuam específicas desse consumidor; seus exemplos não
estabelecem requisitos de outros produtos nem comprovam funcionalidades existentes.

## Uso e adoção

1. Copie a pasta completa da skill escolhida de `skills/` para um local autorizado.
2. Para uso independente, informe ao agente o caminho de seu `SKILL.md`.
3. Se o consumidor usar SDD, obtenha o modelo em
   [sdd/model/](../sdd/model/README.md), reconciliando arquivos existentes.
4. Copie somente a ponte correspondente de `sdd/chain/` e configure `skill_path`
   relativo à raiz do consumidor. A ponte não instala skills nem muda o núcleo.

Não é preciso levar esta pasta inteira, o histórico, os testes da fábrica ou os
outros especialistas. `sources-*` e registros de pesquisa importados conservam o
contexto da autoria original; comandos e resultados ali mencionados não são
ferramentas distribuídas nem verificações reexecutadas nesta adaptação.

## Catálogo

- [cli-engineering](skills/cli-engineering/SKILL.md): Design, implement, or review command-line behavior, help, machine output, exit codes, and safe retries. Use for CLI consumer contracts; skip shell scripting without a CLI design question.
- [css-layout-engineering](skills/css-layout-engineering/SKILL.md): Implement or diagnose CSS sizing, Grid/Flexbox, responsive layout, overflow and reflow. Use for concrete layout behavior; skip branding, navigation taxonomy and framework state.
- [frontend-form-engineering](skills/frontend-form-engineering/SKILL.md): Implement or review web form state, validation, submission and recovery. Use for interactive field and commit semantics; skip resource-schema ownership and unrelated component styling.
- [frontend-routing](skills/frontend-routing/SKILL.md): Implement or review client-side URL, navigation, history and guard contracts, including Vue Router adapters. Skip information architecture, data-cache ownership and backend authorization design.
- [frontend-state-and-cache](skills/frontend-state-and-cache/SKILL.md): Design or repair frontend state ownership, remote-query caches, invalidation and optimistic updates. Use for cross-view consistency or stale-state defects; skip local bindings and server persistence design.
- [frontend-testing](skills/frontend-testing/SKILL.md): Implement or diagnose frontend unit, component, browser and end-to-end tests. Use for interaction or harness evidence; skip generic test strategy and backend-only contracts.
- [http-api-contracts](skills/http-api-contracts/SKILL.md): Design or evolve HTTP resource, method, representation, error and compatibility contracts. Use for HTTP semantics and consumer-facing changes; skip non-HTTP protocols and test-suite strategy alone.
- [identity-federation](skills/identity-federation/SKILL.md): Implement or review federated authentication, OIDC/OAuth flows, session lifecycle and identity-provider interoperability. Skip application RBAC policy and generic security reviews without federation.
- [information-architecture](skills/information-architecture/SKILL.md): Design or evaluate navigation, taxonomy, labels and search for findability. Use for task-to-destination ambiguity; skip visual styling, router implementation and unsupported aesthetic judgments.
- [internationalization](skills/internationalization/SKILL.md): Implement or review locale negotiation, message resources, formatting, pluralization and bidirectional UI. Skip translation-only writing and product language policy decisions.
- [property-based-testing](skills/property-based-testing/SKILL.md): Design or repair generated-input, metamorphic and state-machine tests with meaningful oracles, shrinking and replay. Skip generic suite strategy and claims of correctness from random sampling.
- [typescript-engineering](skills/typescript-engineering/SKILL.md): Implement, refactor or review TypeScript types, boundaries, public APIs and compiler/module configuration. Skip framework lifecycle and runtime validation claims based only on type checking.
- [vue3-engineering](skills/vue3-engineering/SKILL.md): Implement or review Vue 3 components and composables, reactivity, typed bindings and lifecycle cleanup. Skip standalone TypeScript, routing and remote-cache policy without a Vue-specific issue.
- [web-accessibility](skills/web-accessibility/SKILL.md): Implement or evaluate semantic, keyboard, focus, perception and assistive-technology behavior on the web. Use for concrete accessibility requirements; skip visual taste and conformance claims from screenshots.
- [web-realtime-streaming](skills/web-realtime-streaming/SKILL.md): Implement or diagnose browser SSE/WebSocket delivery, lifecycle, replay and bounded buffering. Skip durable server messaging guarantees and UI rendering without a streaming concern.
- [ec-agent-control-protocol](skills/ec-agent-control-protocol/SKILL.md): Implement or review Ec agent/control-plane authentication, version negotiation, heartbeats, leases and result receipts. Skip scheduling policy and local process execution.
- [ec-agent-pool-console](skills/ec-agent-pool-console/SKILL.md): Implement or review Ec agent/pool administration and explainable eligibility views. Skip scheduler placement algorithms, agent wire protocols and local execution.
- [ec-configuration-publication](skills/ec-configuration-publication/SKILL.md): Implement or review Ec configuration publication, immutable revisions, approval binding, conflicts and reconciliation. Skip schema definitions, editor projections and application deployment.
- [ec-declarative-resource-schemas](skills/ec-declarative-resource-schemas/SKILL.md): Design or review Ec YAML resource schemas, parser boundaries, validation, evolution and diagnostics. Skip editor presentation, publication and execution without a schema question.
- [ec-effective-permissions](skills/ec-effective-permissions/SKILL.md): Implement or review Ec effective authorization, inherited grants, provenance, freshness and delegation controls. Skip authentication federation and access-administration UI alone.
- [ec-environments-and-approvals](skills/ec-environments-and-approvals/SKILL.md): Implement or review Ec environment resources, promotion requests, approval gates and operational feedback. Skip generic rollout algorithms and configuration publication.
- [ec-integrations-and-webhooks](skills/ec-integrations-and-webhooks/SKILL.md): Implement or review Ec connector administration, credential references, webhook setup and diagnostics. Skip generic VCS event processing and identity-federation protocol design.
- [ec-operations-and-administration-console](skills/ec-operations-and-administration-console/SKILL.md): Implement or review Ec health, audit, diagnostics and administrative operations screens. Skip run controls, pool management and telemetry-backend design without a console concern.
- [ec-people-and-access-administration](skills/ec-people-and-access-administration/SKILL.md): Implement or review Ec users, teams, groups, memberships and role-binding administration. Skip federation protocols and the effective-permission evaluation algorithm.
- [ec-pipeline-authoring-workspace](skills/ec-pipeline-authoring-workspace/SKILL.md): Implement or review Ec pipeline canvas, inspector, Form/YAML coordination and draft interactions. Skip DAG algorithms, schema ownership and execution scheduling.
- [ec-plugin-isolation-and-lifecycle](skills/ec-plugin-isolation-and-lifecycle/SKILL.md): Implement or review Ec plugin artifact trust, isolation, granted capabilities and lifecycle recovery. Skip manifest compatibility alone and unrelated extension UI.
- [ec-plugin-manifests-and-compatibility](skills/ec-plugin-manifests-and-compatibility/SKILL.md): Design or review Ec plugin manifests, extension contracts and dependency compatibility. Skip runtime isolation, artifact trust verification and generic package upgrades.
- [ec-product-contract-test-harness](skills/ec-product-contract-test-harness/SKILL.md): Build or review an Ec cross-layer test harness for configuration, authorization, revision and execution contracts. Skip generic test strategy and product-policy invention.
- [ec-project-hierarchy-management](skills/ec-project-hierarchy-management/SKILL.md): Implement or review Ec project trees, inheritance and hierarchy mutations. Skip pipeline DAGs, membership graphs and schema or permission-engine ownership.
- [ec-run-execution-operations](skills/ec-run-execution-operations/SKILL.md): Implement or review Ec operator-facing run/job/attempt status, cancellation, retry and diagnostics. Skip scheduler allocation, local process control and configuration publication.
- [ec-semantic-configuration-projections](skills/ec-semantic-configuration-projections/SKILL.md): Implement or review loss-preserving Ec YAML/Form/Visual projections and draft synchronization. Skip schema definition, publication and styling without semantic edits.
- [cicd-agent-runtime](skills/cicd-agent-runtime/SKILL.md): Implement or review CI/CD agent lifecycle, capability reporting, local capacity and recovery. Skip scheduler allocation, product wire protocols and step process isolation.
- [cicd-artifacts-and-retention](skills/cicd-artifacts-and-retention/SKILL.md): Implement or review CI/CD artifact ingestion, integrity, provenance, retrieval and retention. Skip build caches and process execution.
- [cicd-build-cache](skills/cicd-build-cache/SKILL.md): Implement or review CI/CD build-cache keys, trust scopes, integrity and eviction. Skip immutable run-artifact retention and runtime scheduling.
- [cicd-execution-runtime](skills/cicd-execution-runtime/SKILL.md): Implement or review CI/CD step execution, output draining, deadlines, cancellation and process isolation. Skip queue scheduling, agent protocols and log storage.
- [cicd-logs-and-test-results](skills/cicd-logs-and-test-results/SKILL.md): Implement or review CI/CD log chunks, replay, redaction and test-report ingestion. Skip platform telemetry design, process output capture and UI layout.
- [cicd-pipeline-graph](skills/cicd-pipeline-graph/SKILL.md): Implement or review CI/CD dependency-graph validation, cycle diagnostics, deterministic ordering and readiness. Skip canvas interactions, resource scheduling and execution.
- [cicd-release-and-deployment](skills/cicd-release-and-deployment/SKILL.md): Implement or review CI/CD artifact promotion, rollout gates, deployment state and recovery. Skip product-specific environment resources, scheduling and artifact-storage internals.
- [cicd-scheduler](skills/cicd-scheduler/SKILL.md): Implement or review CI/CD eligibility, queue fairness, capacity reservations, leases and recovery. Skip graph editing, agent wire protocols and step execution.
- [cicd-vcs-event-processing](skills/cicd-vcs-event-processing/SKILL.md): Implement or review CI/CD VCS webhook authentication, event normalization, revision resolution and durable triggers. Skip connector administration and scheduler dispatch.

## Verificação na fábrica

Da raiz deste repositório, com Python 3.11+ e biblioteca padrão:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s src/tests/sdd -p test_new_skills_portability.py -v
PYTHONDONTWRITEBYTECODE=1 python3 sdd/model/tools/validate.py --skill new_skills/skills/vue3-engineering
```

O primeiro comando cobre as 40 skills e pontes em consumidores temporários; o
segundo mostra a checagem de uma entrada. As regressões também integram o runner
habitual. Aprovação estrutural não comprova seleção por um agente, integração Ec,
compatibilidade com ferramentas atuais ou eficácia comparativa.
