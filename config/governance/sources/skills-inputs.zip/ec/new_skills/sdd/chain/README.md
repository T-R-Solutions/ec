# Pontes opcionais das skills candidatas

Este é um catálogo de autoria, não um SDD instalado. Cada uma das 40 pontes usa
`skill_path: UNCONFIGURED`; isso é intencional. Copie apenas as selecionadas para
`sdd/chain/` de um consumidor e configure o caminho relativo ao `SKILL.md` real.

O modelo continua em [sdd/model/](../../../sdd/model/README.md) na fábrica.
As contribuições das pontes respeitam spec, plan/ADRs, tasks e evidências do
consumidor; não repetem procedimentos técnicos nem concedem autorização.
Uma mudança local pode usar a skill sem ponte e sem fabricar uma feature.

[Catálogo das 40 skills](../../README.md).
