# Skills independentes candidatas

Copie uma pasta completa, com `SKILL.md` e referências internas. Nenhuma requer
SDD, o histórico de autoria ou outra skill para ser carregada. Os caminhos reais,
as versões e os contratos do produto são descobertos no consumidor.

[Catálogo e adoção](../README.md). Pontes opcionais ficam separadas em
[sdd/chain/](../sdd/chain/README.md). Não são instaladas automaticamente.
