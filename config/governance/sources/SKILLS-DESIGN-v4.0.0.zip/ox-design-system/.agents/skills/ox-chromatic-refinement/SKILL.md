---
name: ox-chromatic-refinement
description: "Improve Ox color distribution without changing Signature Blue, state truth or evidence semantics."
---

# Ox Chromatic Refinement — mais significado, não mais tinta

## Quando usar
Ao avaliar monocromia, categorias indistinguíveis, estados com pouca presença, excesso de azul ou nova escala de cores. Tradução crítica do `colorize` do Impeccable para a Ox.

## Pré-condições
Ler `DESIGN.md` §§2–4, `data/design-tokens.json`, `data/role-map.json`, dados de teste e o CSS efetivo da superfície.

## Procedimento obrigatório
1. Inventariar local exato de `#hex`, aliases `--accent`, `--category-*`, `series-*`, `syntax-*`, seletores globais e casos que dependem de `?categoryTrial=teal`.
2. Preservar valores Signature Blue e cores semânticas Light **byte-equivalentes no significado**, sem recolorir shell/CTA/foco.
3. Definir **A** = base neutralizada/status, **B** = A + teal código `#2B7078` e mineral documentação `#6E6259` em alvos pequenos, **C** = expansão somente se investigação provar necessidade.
4. Traçar o significado de cada uso: estado (verde/âmbar/vermelho/violeta), categoria (teal/mineral/indigo/copper), sintaxe (independente), dados (séries com nomes). A mesma cor não muda de significado em telas diferentes.
5. Usar `data-ox-direction="chromatic-b"` apenas para experimento em protótipos; Dark/HC possuem valores explícitos e exigem teste independente. Nunca usar `filter:invert()`.
6. Construir **comparação A/B da MESMA fixture**, primeiro Start/Settings/Explorer, depois Architecture/Agents/Editor/Observability. Evidenciar pelo menos foco, seleção, warning, unknown, inferred, verified.
7. Calcular pares opacos, testar composição real, ler rótulos, checar contraste e reconhecer estado sem cor; retirar cor que não melhora identificação.
8. Registrar decisão/approver; **sem aprovação B permanece PROPOSED** e não substitui default.

## Saídas
Mapa `surface → component → token → role → state`, screenshots A/B e relatório sobre distinção visual, legibilidade, semântica e riscos.

## Anti-padrões
Verde para implemented; violeta para unknown; amarelo em todo card; múltiplas séries inventadas; gradientes multi-cromáticos genéricos; teal como CTA.
