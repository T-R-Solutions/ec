---
name: ox-native-handoff
description: "Translate approved Ox visual roles and component states into a Rust/Iced implementation contract."
---

# Ox Rust/Iced Handoff — contrato verificável

## Quando usar
Após design de componente aprovado, quando entregar UI tokens e comportamento visual para o frontend nativo.

## Entrada
`DESIGN.md`, `data/native-tokens-manifest.json`, role map, screenshot aprovado, versão fixada de `iced`, OS alvo, source/fixtures e state machine real.

## Plano
1. Separar `DESIGN-ACCEPTED` de `NATIVE-IMPLEMENTED` e `NATIVE-VERIFIED`.
2. Mapear os 63 roles sRGB para estruturas Rust semanticamente nomeadas; tema Light/Dark/HC e densidades usam mesmos nomes e valores por tema. Iced usa estilos/temas de widgets, **não interpreta CSS do protótipo como contrato nativo**.
3. Confirmar API de Iced **na versão travada do produto** (docs.rs/iced). Não escrever exemplo de closure baseado em versão incompatível.
4. Para cada widget, mapear estados visuais e do domínio, constraints, foco, leitura assistiva, eventos/atalhos e controles de redimensionamento.
5. Fazer snapshot nativo com mesma fixture e janela de referência; aceitar diferenças razoáveis de rendering de fontes/OS justificadas, sem exigir pixel-perfect cego.
6. Testar keyboard/focus e OS accessibility APIs, DPI 100/125/150/200, temas/HC; reportar memória/latência somente se medidos com setup/benchmark reproduzível.
7. Retornar evidências e desvios para design system. Não declarar integração de agente/permissão só porque a UI existe.

## Saídas
Contrato `token → widget Rust → state → test → screenshot`, lacunas da API, riscos cross-platform, implementação status e relatório de aprovação nativa.

## Proibição
Não adicionar dependências JS, Tailwind, CSS parsing runtime nem conversões `oklch()` não verificadas ao renderer Rust.
