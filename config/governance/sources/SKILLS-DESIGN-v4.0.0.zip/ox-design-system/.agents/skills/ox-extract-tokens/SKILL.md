---
name: ox-extract-tokens
description: "Consolidate Ox CSS and style tokens into one audited semantic system without changing domain behavior."
---

# Ox Extract Tokens — refatoração CSS/JSON controlada

## Quando usar
Ao migrar R12→R13, reduzir overrides e divergência entre `assets/tokens.css`, `data/tokens.json` e `assets/r12-refinement.css`. Inspirado no `extract` do Impeccable, com saída para Rust/Iced.

## Procedimento
1. Ler `DESIGN.md` §§3–4, arquivo-alvo e `data/role-map.json`; inventariar seletor, regra, especificidade, HEX e token efetivo.
2. Classificar papel: `brand`, `surface`, `text`, `status`, `category`, `syntax`, `data-viz`, `component`; exceções recebem justificativa e dono.
3. Preservar integralmente os tokens `LOCKED` da R12 Light; manter aliases de compatibilidade até confirmação de ausência de dependências.
4. Consolidar em `data/design-tokens.json`, gerar com `python scripts/build_tokens.py`; **não editar CSS gerado manualmente**. Nas telas de protótipo, aplicar nomes de roles `--ox-*` e estilos específicos por componente.
5. Eliminar regras globais amplas que mudam muitos controles (`button:hover`, `small`, `:focus-visible` sem contrato), substituindo por estilos base de controle + variante local. Não remover foco acessível por acidente.
6. Verificar especificidade, `:has`, `color-mix`, `oklch`, sombras, r12 overrides, dark/hc/compact, SVG paramétrico e efeitos da flag B. Iced recebe apenas sRGB calculado de papéis, não CSS.
7. Rodar `python scripts/validate_design.py`; calcular `eligible`, `tokenized`, `excluded` e `exceptions`, informando denominador e causa. Alvo inicial ≥95%, 0 exceções não revisadas.
8. Reexecutar os contratos existentes (sem reescrever fixtures), screenshot antes/depois e smoke de teclado; falhou regressão → rollback seletivo e nova iteração.

## Entregáveis
`token-diff`, `CSS-dependency-map`, `component-migration-map`, contagens, exceções, CSS/manifesto gerados, screenshot pareado e log de decisão.

## Proibição
Nenhum refactor estético pode mudar dados, permissões, progressos, URLs de domínio ou significado dos badges.
