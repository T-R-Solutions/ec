---
name: ox-accessibility
description: "Audit Ox visual and interaction accessibility with WCAG-informed checks and native-platform caveats."
---

# Ox Accessibility — acessibilidade verificável

## Quando usar
Sempre que houver alteração de cor, foco, seleção, temas, dialogs, árvores, grafos, diff, ícones, keyboard shortcuts ou microcopy.

## Processo
1. Ler `DESIGN.md` §10 e W3C WCAG 2.2 oficial. Mapear componentes e estados efetivamente presentes, não auditar exemplos fictícios.
2. Calcular pares opacos documentados com `python scripts/validate_design.py`; depois verificar **cor efetiva renderizada**, alpha, hover/pressed/disabled/selected, contraste de borda essencial, focus ring e icon/data-viz.
3. Testar identificação sem cor: `unknown` vs `inferred` (tracejado/rótulo), red vs green em diff e testes, estados de agentes, eventos e permissões.
4. Operar com teclado: Tab/Shift+Tab, Enter/Space, Escape, setas na árvore, foco do modal, retorno ao disparador, buscas/menus, graph quando suportado. Registrar browser, OS, viewport e resultado.
5. Validar labels de inputs e botões de ícone, nomes e roles acessíveis, mensagens de erro com texto, ordem de leitura, tooltip/overflow, tamanhos de ponteiro e zoom.
6. Repetir Light, Dark, HC, Comfortable, Compact, reduced-motion e content stress. **HC web não implica HC nativo**; testar assistência na aplicação Rust/Iced quando disponível.
7. Classificar cada falha por severidade e impacto, registrar cenário e evidência. `PASS` só para caso executado; `NOT-TESTED` não é `PASS`.

## Saída
Relatório: critério aplicável, componente, cenário, cor fg/bg efetiva, razão de contraste quando relevante, método, status, screenshot, problema, fix e reteste.

## Veto
Nenhuma ação crítica inacessível via teclado; nenhuma decisão sem consequência explicitada; nenhum dado codificado apenas por cor.
