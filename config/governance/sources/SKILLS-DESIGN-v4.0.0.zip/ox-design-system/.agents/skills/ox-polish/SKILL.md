---
name: ox-polish
description: "Perform the final Ox desktop visual refinement without hiding functional problems or increasing decoration."
---

# Ox Polish — acabamento consistente, sem “AI slop”

## Quando usar
Após a arquitetura de layout e os estados estarem corretos. Nunca usar como substituto de corrigir falha semântica ou acessibilidade.

## Processo
1. Ler `DESIGN.md` e o relatório de `ox-critique`; resolver P0/P1 antes de P3.
2. Comparar alinhamento de baseline de texto, ícones 16/20, gaps 4/8/12, borders essenciais, altura de input, tab marker e raios por papel (0/4/6/8/12).
3. Reduzir containers redundantes, sombras decorativas, cor em excesso e rótulos truncados; preservar separadores úteis para leitura de tabela/trace.
4. Verificar contraste real e foco após cada refinamento; não “suavizar” funcionalmente um contorno crítico.
5. Corrigir visual de empty/loading/error sem introduzir dados, estados ou funcionalidades que não existem.
6. Conferir 1366×768, 1440×900 e ao menos uma variante Dark/HC/Compact do alvo; screenshots pareados e leitura a 100%.
7. Repetir uma rodada de crítica independente para localizar efeitos colaterais; remover ajuste que não demonstrou benefício.

## Saída
Lista ordenada de pequenos patches com screenshot antes/depois, role/papel alterado, risco, testes e resultado.

## Anti-slop adaptado à IDE
Nada de stack de cards macios, toolbars em pills arbitrárias, gradients publicitários, avatar decorativo, hover que desloca código, animação de sucesso contínua, ícone desnecessário ou tipografia “futurista” sacrificando leitura.
