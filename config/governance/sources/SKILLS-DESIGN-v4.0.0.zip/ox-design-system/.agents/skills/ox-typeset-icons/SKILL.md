---
name: ox-typeset-icons
description: "Tune Ox typography and iconography at real desktop density while preserving current IBM Plex baseline."
---

# Ox Typeset & Icons — clareza a 100% lógico

## Quando usar
Clipping de texto, hierarquia de informação, troca de fonte, legibilidade do código, problemas ópticos dos ícones ou excesso de símbolos.

## Processo
1. Ler `DESIGN.md` §§5 e 7. **Baseline da R12:** IBM Plex Sans/Mono. Inter/JetBrains Mono são proposta A/B sem aprovação; não migrar silenciosamente.
2. Inventariar `font-family`, pesos, line heights, fallback de WOFF2, tamanhos `13/14/15` e hot spots em Settings/Workbench/Explorer/Editor.
3. Capturar R12 em 100% e, se avaliar fonte alternativa, comparar o **mesmo conteúdo, zoom e viewport**. Medir largura e clipping de caminho, tab, label, botão e código.
4. Testar glyphs `0/O`, `1/l/I`, operadores `=> !=`, símbolos Rust, pt-BR (`ação`, `preferências`, `verificação`), números tabulares e desativação de ligaturas do código.
5. Conferir ícones 12/16/20/24 px em 1×/1,25×/1,5×/2×; IDs semânticos, stroke, alinhamento óptico, cores por role e acessibilidade (tooltip/aria-label).
6. Remover ícone redundante onde não melhora localização ou estado. Não usar cor de tipo como se fosse resultado de teste ou status Git.
7. Verificar escala Compact sem sacrificar text/code, e matriz Light/Dark/HC sem falha de fallback.

## Saída
Tabela com medidas reais e screenshots A/B; proposta aprovada/rejeitada; atualizações pontuais de tokens, não regras globais de `small{}`.

## Restrições
Não redistribuir fontes deste kit. Inspeção estática não prova renderização de glyph na Iced.
