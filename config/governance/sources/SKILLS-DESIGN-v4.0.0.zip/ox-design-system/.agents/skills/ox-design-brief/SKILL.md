---
name: ox-design-brief
description: "Define scope, authority, design direction and acceptance before any Ox IDE visual change."
---

# Ox Design Brief — decidir antes de desenhar

## Quando usar
Antes de alterar uma tela, criar variante, mudar uma família de componentes, propor tema ou receber uma referência nova. O objetivo é impedir que o agente adote automaticamente padrões de landing page ou altere a semântica do produto.

## Entrada obrigatória
- `DESIGN.md` (autoridade), `data/coverage-matrix.json`, histórico da tela/domínio e screenshots/fixtures do estado vigente.
- Solicitação do usuário, alvo por ID `Sxx/W00/Axx/TWxx`, temas/densidades, constraints de plataforma e evidência disponível.

## Processo
1. **Identificar classe:** melhoria de layout, contraste, componente, estado, tokens, iconografia ou proposta funcional. Se for mudança funcional, separar em decisão de produto; design não a implementa por inferência.
2. **Fixar autoridade:** R2 workspaces base; R3 review/failure/focus; R4 entrada/tarefas/settings; R5 administração; R11/R12 somente quando realmente sobrescrevem componente. Mostrar arquivo da composição.
3. **Redigir uma hipótese verificável** em uma frase, por exemplo: “marcador teal em arquivos Rust reduz confusão com docs, sem prejudicar status Git”.
4. **Dials adaptados de Taste Skill:** variar pouco shell, moderar conteúdo específico, movimento próximo de zero, densidade profissional. Não “sortear” estilo de marketing.
5. **Delimitar não-objetivos:** dados, permissões, backend, performance, ações de agente, estados de verdade.
6. **Definir matriz de comparação:** mesma fixture, zoom, resolução, tema, densidade e estado. Especificar gatilhos para A/B/C e atores que devem aprovar.
7. **Registrar design brief** com IDs, links locais, decisão, riscos, métrica e status LOCKED/PROPOSED/VALIDATED.

## Saída padrão
`Goal / Surface / Baseline / Problem evidence / Proposed roles & components / Non-goals / Viewports & states / Acceptance criteria / Open decisions`.

## Bloqueios
Não começar com rebrand, trocar IBM Plex por Inter automaticamente, criar tela duplicada nem apresentar screenshots existentes como prova de implementação nativa.
