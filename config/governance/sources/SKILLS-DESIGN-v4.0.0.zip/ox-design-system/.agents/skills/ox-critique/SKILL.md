---
name: ox-critique
description: "Critique existing Ox desktop flows with evidence, severity, usability and technical semantics."
---

# Ox Critique — avaliação crítica com evidências

## Quando usar
Uma tela está muito azul, apertada, pouco legível, confusa, difícil de navegar ou visualmente inconsistente. Inspirado no vocabulário `critique` do Impeccable, porém especializado em desktop IDE.

## Processo
1. Ler `DESIGN.md`, estado funcional e versão do alvo. Capturar o estado a **100% lógico**; se não houver browser/IDE real, rotular análise como estática/indireta.
2. Realizar **duas leituras**: (a) tarefa real do usuário e hierarquia informacional; (b) papel de cada cor/forma, contorno, foco, alinhamento, densidade, truncamento.
3. Verificar separadamente `Task` de `Execution`, agent definition de instance, `implemented/verified/accepted`, `inferred/unknown`, `requested/confirmed`, `estimate/observed`.
4. Pontuar cada achado com `P0` (quebra crítica de certeza/acesso), `P1` (impede trabalho), `P2` (fricção/consistência), `P3` (polish). **Não usar nota estética sem evidência observável.**
5. Para cada achado, registrar screenshot+região/componente+fixture+causa provável+regra violada+ação mínima+risco de regressão.
6. Propor correções estruturais primeiro (hierarquia, espaço, legibilidade, confirmação), depois ajuste cromático. Não aumentar saturação só porque uma página parece monocromática.
7. Priorizar no máximo três intervenções por ciclo; recapturar e comparar a mesma tela, sem trocar conteúdo/dados.

## Saída
Tabela de achados com ID, P0–P3, evidência, regra `DESIGN.md`, hipótese, mudança mínima, estado da prova e decisão. Incluir o que **não foi possível verificar**.

## Regras de rejeição
Texto ilegível, ação inalcançável, status indevido e permissão ambígua bloqueiam aprovação mesmo com screenshot visualmente atraente.
