---
name: ox-visual-qa
description: "Capture and compare Ox R11/R12/R13 desktop visuals; repeat until measurable gates pass."
---

# Ox Visual QA — captura, inspeção e regressão

## Quando usar
Toda mudança de design antes de handoff. Inspirada nos loops `inspect → fix → inspect` de Taste Skill e nos gates `audit/polish` do Impeccable.

## Processamento
1. Ler `DESIGN.md` §12, `docs/QA_PROTOCOL.md`, manifestos de screenshot e origem da fixture.
2. Capturar baseline e candidato com **mesmo** HTML/rotas, fixture, resolução, zoom, DPI, tema, densidade, estado e tempo de estabilização. Nunca comparar PNG R11 histórico a uma suposta R12 atual.
3. Mínimo recomendado: 7 superfícies × 3 temas × 2 densidades = 42 casos a 1440×900; mais janelas críticas e conteúdos extremos. Se não executar tudo, preencher status `PENDING` com denominador real.
4. Inspecionar **cada captura a 100%**: clipping, contraste, alinhamento, hierarquia, foco, stato labels, ícones, linhas de graph, dados/units, excesso de cor, ação principal.
5. Testar keyboard e fluxo real no browser/nativo disponível. Um DOM simulado não é E2E, e Chromium com assets inline não equivale a navegação por HTTP.
6. Gerar findings P0–P3 com evidência, seletor/coordenada, causa, correção e risco; corrigir P0/P1 primeiro, recapturar e comparar.
7. Repetir ciclos até não haver falhas no escopo executado. Separar `PASS`, `FAIL`, `PENDING`, `BLOCKED` e `NOT-APPLICABLE`.
8. Fechar com screenshot manifest, hashes relevantes, versão da fonte, ambiente, método, decisões abertas e aprovação humana quando necessária.

## Entregáveis
`visual-qa-matrix`, capturas, anotação A/B, lista de regressões, testes teclado/links, nota de restrição e aprovação por superfície/tema.

## Critério de parada
Somente declarar conclusão de design quando os gates verificáveis passaram. Não declarar 100% nativo sem executar Rust/Iced real.
