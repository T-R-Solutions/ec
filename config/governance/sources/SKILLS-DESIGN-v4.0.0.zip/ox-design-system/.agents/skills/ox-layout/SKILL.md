---
name: ox-layout
description: "Refine Ox desktop workbench layout, docking, density, panel hierarchy and overflow."
---

# Ox Layout — geometria de IDE desktop

## Quando usar
Problemas de painéis, editor comprimido, largura de sidebar, duplicação de barras, alinhamento, modo Compact, multi-monitor ou clipping. Tradução do `layout`, `distill` e `adapt` do Impeccable, sem filosofia mobile-first.

## Processo
1. Ler `DESIGN.md` §§6–8 e recuperar a composição vigente, preferencialmente com regiões medidas em px lógicos.
2. Identificar **área primária** da tarefa (editor, review, arquitetura) e painéis auxiliares (conversation, explorer, inspector, trace). Preservar a primária antes de reduzir qualquer fonte.
3. Usar grid de 4 px, titlebar 48–52, rail 48, explorer 240–320 reajustável, tool headers 36–44, linhas 28–32, editor mono 15/26 e statusbar 26–28 **como pontos de partida**, não magic numbers.
4. Converter alturas e larguras rígidas em constraints: mínimo/máximo, resize/collapse, overflow discoverable, layout de foco, prioridade vertical em 1366×768.
5. Reduzir wrappers, títulos duplicados e cartões desnecessários; não retirar dividers que separam informação técnica de forma útil.
6. Validar `1366×768`, `1440×900`, `1920×1080`, `2560×1080`, `2560×1440` e ≤1024 em janelas, com 100%, 125% e 200% de escala quando possível.
7. Trocar Comfortable→Compact mantendo legibilidade e rótulos críticos; testar conteúdo extenso e rascunhos sem cortar botões.
8. Verificar ordem/foco de DOM e leitura assistiva onde implementado. Screenshot sozinho não prova navegação por teclado.

## Entregáveis
Mapa de regiões antes/depois; constraints; medidas; capturas comparáveis; eventos de overflow; justificativa de painéis escondidos; correções P0–P3 e pendências.

## Veto
Não “resolver” colisão com font-size 10, não ocultar ações críticas em menus sem acesso, não criar 3 colunas fixas em 1024px.
