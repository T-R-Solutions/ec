---
name: ox-harden
description: "Harden Ox design for uncertain states, long content, errors, concurrency and recovery."
---

# Ox Harden — estados extremos e verdade operacional

## Quando usar
Antes da aprovação de uma superfície com execução, alteração de arquivos, decisões, IA, verificações, dados ausentes ou forte densidade. Adaptação de `harden` do Impeccable.

## Procedimento
1. Ler `DESIGN.md` §§2, 7, 10–12. Listar estados reais do contrato, não inventar novos sucessos.
2. Gerar **matriz de cenários**: empty, loading, failure, unknown, stale, inferred, partial, blocked, waiting, permission-required, cancelled, verification-failed, implemented-only, accepted, failed-to-confirm.
3. Cobrir strings longas, paths profundos, nomes Unicode, 50 abas sintéticas se fixture permitir, eventos simultâneos, network disrupted, arquivo removido e fontes indisponíveis.
4. Comparar requested/received/confirmed e `implemented/verified/accepted`; exibir consequência e prova apropriadas. Uma falha de comando não prova rollback e uma tela de recuperação não o implementa.
5. Para cada estado, produzir indicação por texto/ícone/forma, ação segura quando suportada, espaço para descrição, tooltip e saída de erro.
6. Testar foco, overflow, scroll, resize e comportamento visual de confirmação/Cancel/Apply/OK. Nenhum valor ausente deve ser mostrado como zero.
7. Aplicar correção mínima; executar QA visual e contratos demonstrativos existentes sem alterar fixture sem justificativa.

## Entregáveis
Tabela `component → case → expected label/color/shape → source truth → test → result`, com pendências nativas explicitadas.

## Veto
Não simular êxito, progresso ou recuperação bem-sucedida. Marcar estado como desconhecido se não houver confirmação.
