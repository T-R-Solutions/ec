# Ec

Ec é uma plataforma independente de integração contínua e entrega/implantação contínuas (CI/CD), planejada para configurar, executar e administrar o ciclo de automação de software: projetos, repositórios, pipelines, agentes, resultados, ambientes e entregas, com gestão de pessoas, permissões, integrações e auditoria.

**Estado em 2026-11-04:** pesquisa, normas de produto, governança executável e estrutura documental da aplicação. Ainda não há Ec Server, Ec Agent ou interface de produto executáveis. As funcionalidades abaixo descrevem o produto previsto; os diretórios criados não representam funcionalidades implementadas.

## Funcionalidades previstas

| Área | O que o Ec deverá permitir |
| --- | --- |
| Projetos e repositórios | Administrar projetos/subprojetos, hierarquia, parâmetros, templates, conexões Git e revisões |
| Pipelines e configuração | Definir jobs, etapas, dependências DAG, gatilhos e requisitos de agente; editar o mesmo modelo em Visual, Formulário e YAML |
| Execuções | Acompanhar fila, tentativas, logs, testes e artefatos; solicitar cancelamento e retry sob política explícita |
| Agentes e pools | Gerir inventário, capacidades, slots, manutenção, conectividade e motivos de elegibilidade |
| Pessoas e acesso | Administrar usuários, equipes/grupos, papéis, vínculos e permissões efetivas, com autorização no backend |
| Entregas | Gerir ambientes, promoções, aprovações, releases e deployments; rollback quando houver estratégia suportada |
| Extensões e integrações | Administrar conectores, webhooks, notificações e plugins, com compatibilidade, integridade e isolamento a demonstrar |
| Administração | Consultar saúde, atividade e auditoria; gerir políticas globais, segurança, retenção e diagnósticos |

O fluxo previsto liga **configurar → validar/publicar uma revisão → submeter execução → alocar Agent → executar → consultar resultados → promover/aprovar entrega**. A [visão funcional e técnica](docs/architecture/application-overview.md) detalha atores, responsabilidades, módulos e limites.

## Arquitetura e implementações

O alvo é formado por dois tipos de monólito modular em Rust: **Ec Server**, que centraliza API, autorização, configuração e orquestração; e **Ec Agent**, com múltiplas instâncias para preparar workspaces, executar etapas e reportar resultados. O frontend do Server será uma aplicação **Vue 3 + TypeScript + Pinia**. Ec Agent é um executor de CI/CD; seu nome não implica uso de IA.

| Superfície | Implementação observada neste checkout |
| --- | --- |
| Agent | Quatro domínios e um crate de composição documentados; sem código Rust de produto |
| Backend Server | Oito domínios e um crate de composição documentados; sem código Rust de produto |
| Frontend | Nove domínios, `app` e `shared` documentados; sem código Vue/TypeScript |
| Testes do produto | Diretórios e política de classificação; sem cenários executáveis |
| Governança | Auditor e instalador Python, validador SDD e suíte de testes executáveis |
| Pesquisa | Corpus TeamCity, utilitários Python e modelo Rust de leases; separados da aplicação Ec |

A [organização da aplicação](docs/architecture/application-layout.md) define diretórios e dependências permitidas. Ainda não há manifests Cargo/npm de produto, schemas executáveis, migrations, endpoints HTTP ou contratos de serialização implementados.

## Contratos do produto

Estes são compromissos documentais vigentes, cuja implementação ainda precisa ser demonstrada:

- **Configuração:** YAML é a única fonte canônica da configuração desejada. Visual, Formulário e YAML editam o mesmo modelo, sem perda semântica ou descarte silencioso de campos.
- **Publicação:** alterações persistentes pela UI/API passam pela mesma validação, autorização e revisão. Rascunho, publicado e efetivo são distintos; jobs fixam revisões imutáveis de configuração e código.
- **Estado e comunicação:** PostgreSQL é a autoridade planejada da fila e do estado operacional; HTTP versionado é o transporte estabelecido. Logs, sessões, leases e resultados não são configuração YAML.
- **Execução:** reservas transacionais, leases, fencing, idempotência e retries explícitos são requisitos. Não há garantia de efeitos externos exatamente uma vez.
- **Segurança:** segredos por referência, autorização por ação/recurso no backend e isolamento demonstrado antes de workloads não confiáveis ou plugins externos.
- **Interface:** confirmação real do backend, estados de erro/conflito/desconexão, teclado, responsividade e WCAG 2.2 AA como critério de referência; conformidade ainda não demonstrada.

O [catálogo de contratos](docs/architecture/contracts.md) reúne fontes, responsáveis, rejeições esperadas e lacunas. **gRPC/Protobuf e SQLite local continuam propostas**; a meta de 1.000 agentes e ensaios até 2.000 não constituem capacidade comprovada, defaults ou SLOs.

## Começar pelo repositório

- Para conhecer o produto: [visão funcional e técnica](docs/architecture/application-overview.md), [estado do projeto](sdd/project.md) e [normas e autoridades](docs/constitution.md).
- Para consultar os contratos: [catálogo](docs/architecture/contracts.md) e [índice da documentação](docs/README.md).
- Para contribuir: [AGENTS.md](AGENTS.md), [organização da aplicação](docs/architecture/application-layout.md) e [política de testes](docs/development/testing.md).
- Para implementar: [Agent](application/agents/README.md), [Server](application/server/README.md), [backend](application/server/backend/README.md) e [frontend](application/server/frontend/README.md).
- Para entender a governança: [SDD](sdd/README.md) e [análise das skills](docs/development/skills-analysis.md).

## Mapa do repositório

| Caminho | Responsabilidade |
| --- | --- |
| `application/agents/crates/` | Domínios e composição do Ec Agent em Rust |
| `application/server/backend/crates/` | Domínios e composição do Ec Server em Rust |
| `application/server/frontend/` | Aplicação Vue 3/TypeScript/Pinia organizada por domínios |
| `application/integration/tests/` | Integração e ponta a ponta entre componentes da plataforma |
| `docs/` | Normas, arquitetura, decisões, desenvolvimento e validação |
| `sdd/` | Workflow, contexto, pontes, features e evidências |
| `config/governance/` e `tools/governance/` | Catálogo, fontes, hashes e verificadores |
| `reverse_engineering_teamcity/` | Pesquisa histórica preservada |

A [pesquisa histórica](reverse_engineering_teamcity/ci-platform-research/README.md) e seu protótipo não constituem a aplicação Ec; comandos antigos `rea/` não correspondem ao layout atual.

## Verificações disponíveis

Com Python 3.11+ disponível, execute da raiz:

```bash
python3 tools/governance/validate.py
python3 sdd/tools/validate.py --root .
python3 -m unittest discover -s tools/governance/tests -v
```

São verificações de governança, não testes do produto. Os validadores devem retornar `PASS`; a suíte deve terminar com `OK`. Os testes usam cópias temporárias e precisam de um diretório temporário gravável. Em caso de erro, consulte os caminhos e diagnósticos emitidos; não altere hashes para mascarar divergências. Consulte a [política de testes](docs/development/testing.md) para escopos, limites e verificações adicionais.

Para exigir instalação íntegra das skills e conferir a instalação sem escrever:

```bash
python3 tools/governance/validate.py --require-installed
python3 tools/governance/install_skills.py --check
```

O segundo comando retorna `ALREADY_INSTALLED` quando encontra a instalação atual íntegra. Para exigir aceite e evidência atual da feature de governança:

```bash
python3 sdd/tools/validate.py --root . --require-approved --require-fresh
```

Esse gate deve falhar se houver lacunas ou inputs diferentes dos observados. Não há comando de instalação, build ou execução do produto, toolchain fixada ou ambiente operacional Ec a iniciar.

As 67 skills estão instaladas em `.codex/skills/`, com 594 arquivos conferidos; a preparação local foi preservada para recuperação. Consulte o [procedimento](docs/development/skill-installation.md) e o [relatório da adoção](docs/validation/skills-adoption/report.md).

## Próximos passos e limites

A [ADR-002](docs/decisions/ADR-002-application-layout.md) registra a organização física inicial. Antes de implementar, especificar schemas e interfaces, fronteiras transacionais, revisões e contratos de tentativa/lease; selecionar toolchains, dependências e runners de teste; demonstrar autorização, isolamento, recuperação e acessibilidade nos fluxos pertinentes. A criação das pastas não resolve essas pendências.

Não há release, instalador de produto ou licença própria definida por esta integração. A [auditoria de limpeza](docs/validation/workspace-cleanup-20261103/report.md) preserva o histórico de entradas removidas; a [validação desta estrutura](docs/validation/application-layout-20261103/report.md) registra a observação documental inicial.

A estrutura vigente usa `application/agents/`, `application/server/` e `application/integration/tests/`. A [auditoria dos caminhos](docs/validation/application-path-audit-20261104/report.md) consolida a conferência atual; os relatórios anteriores preservam as observações de cada etapa.

A [análise documental de 2026-11-04](docs/validation/application-analysis-20261104/report.md) registra o inventário, as fontes e as verificações desta revisão. Ao introduzir código, manifests, schemas ou APIs, atualizar o estado e os comandos nestas entradas com evidência correspondente.
