# Adaptação de scripts ao Ec — registro de execução

Estado: execução e reobservação em andamento. Esta versão será substituída pelo
resultado observado desta mesma tarefa; não constitui aceite. Originais e baseline
preservados em previous.zip e baseline-1.log a baseline-5.log.
