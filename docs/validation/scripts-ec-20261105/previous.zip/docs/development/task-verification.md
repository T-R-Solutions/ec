# Verificação antes de encerrar tarefas

Este é o procedimento canônico do Ec, para as duas rotas SDD. Após implementar e
antes de marcar uma tarefa concluída, identifique as superfícies alteradas e seus
consumidores; execute a entrada abaixo e os critérios específicos da feature;
corrija regressões causadas pela alteração, reobserve evidências afetadas e relate
comandos, resultados e lacunas materiais. Instalação ausente nunca significa aprovação.

```bash
python3 scripts/automate.py plan
python3 scripts/automate.py run
```

Da raiz, estes comandos selecionam todas as superfícies conservadoramente. O script
resolve a raiz pela própria localização, mesmo em outro cwd. Para checkout com espaços,
use `python3 "/caminho com espaços/ec/scripts/automate.py" run`. `--root` permite indicar
uma cópia Ec completa. Não depende de Git nem de hooks. Nenhum hook é instalado.

Para escopo conhecido, repita `--surface`; por exemplo:

```bash
python3 scripts/automate.py run --surface docs --surface scripts
python3 scripts/automate.py run --surface server --surface integration
python3 scripts/automate.py run --surface frontend --surface e2e
```

| Superfície | Seleção e verificações reais |
| --- | --- |
| Documentação/governança/skills | `docs`: auditor comum, auditor `--require-installed`, instalador `--check`, SDD e unittest de governança. Governança roda também em todas as demais seleções. Revisar links/prosa e critérios semanticamente. |
| Automação | `scripts`: testes de contratos do runner, incluindo falha, ferramenta ausente, timeout, logs e caminhos. Scripts Python usam stdlib; não há lint fictício. |
| Rust Server | `server`: workspace `application/server/backend`, toolchain do próprio rust-toolchain.toml, fmt check, Clippy workspace/all-targets/all-features com warnings negados, test workspace locked/offline. |
| Rust Agent | `agent`: mesmos checks em `application/agents`, target separado. |
| Frontend Vue/TS/Pinia | `frontend`: npm run typecheck (vue-tsc, inclui .vue), test (Vitest) e build (Vite), package-lock existente. Sem ESLint, cobertura ou budget artificial. |
| Segurança | `security`: Gitleaks 8.30.1 em snapshot das fontes mantidas, regras default, redaction e sem supressões inline. Não certifica dependências, autorização ou isolamento. Mudanças nessas fronteiras exigem seus testes negativos/revisão na feature além do scanner. |
| Integração | `integration`: inclui checks Rust e compila ambos com test-failpoints imediatamente antes dos harnesses; publication_http, orchestration_http, agent_http sequenciais. |
| Ponta a ponta | `e2e`: checks Rust/frontend, builds de failpoints e frontend_firefox com banco/Server/Agent/browser reais. Não dispensa cenários adicionais da feature. |

A seleção é responsabilidade do executor: use consumidores, manifests, contratos,
fixtures e arquivos alterados, não apenas diff Git. Contratos entre componentes,
publicação, migrações, API ou execução do Agent pedem `integration`; jornadas do
browser pedem `e2e`. Escopo desconhecido usa todas as superfícies. Uma seleção parcial
só aprova o que foi executado. Não dispense checks obrigatórios ou ACs silenciosamente.

## Pré-requisitos permanentes

Python 3.11+ (harnesses observados com 3.13), Linux e espaço gravável em `.local/`.
Rustup com o canal já instalado dos dois rust-toolchain.toml (observado 1.99.1),
componentes rustfmt e clippy e linker do host; caches Cargo preparados separadamente
conforme [publicação](publication.md) e [Agent](agent.md). O runner usa `rustup run`,
`--locked --offline`, `RUSTUP_AUTO_INSTALL=0` e nunca instala toolchain/componentes.
`CARGO_HOME` explícito é respeitado; padrão `.local/build/ec-cargo-home`.
Targets são `.local/build/ec-server-clean` e `.local/build/ec-agent-target`, conforme
os harnesses reais. Nenhum build de aplicação é executado na raiz.

Frontend: Node >=22.12 e npm; dependências locais preparadas explicitamente com
`npm --prefix application/server/frontend ci --ignore-scripts`. Verificar o engine
também ao atualizar dependências. Nenhuma biblioteca Vue deve ser instalada globalmente.
O runner usa npm offline, não npx/bunx nem instalação implícita. Build gera dist e
testes podem gerar caches locais; checks não executam formatadores de correção.

Segurança: CLI Gitleaks 8.30.1 no PATH, licença MIT, sem credenciais/rede no scan.
Fonte e distribuição: [repositório oficial](https://github.com/gitleaks/gitleaks),
[versão revisada](https://github.com/gitleaks/gitleaks/releases/tag/v8.30.1).
O snapshot inclui application, scripts, tools, sdd, config, docs/development, AGENTS
e README; exclui .git, .local, .codex, .agents, .aws, node_modules, target, dist,
__pycache__ e config/governance/sources (bundle original). Pesquisa e relatórios
históricos não são analisados. Inventário por hash acompanha o scan. Não há análise
Git histórica, CVEs, SAST ou licença de dependências implementada neste perfil;
exigi-las numa feature demanda configuração e evidência próprias, sem aprovação implícita.

Integração/E2E: Docker com daemon autorizado, Git, container dedicado
`ec-publication-test` em 127.0.0.1:55439 com PostgreSQL 18 e `/usr/bin/firefox` no E2E.
Preparar explicitamente conforme [publicação](publication.md) e [frontend](frontend.md).
O runner verifica daemon, container/porta/readiness e portas livres 58139, 5173,
58282; não cria container, baixa imagem, instala browser ou altera o host.
Banco UUID é descartável e removido pelo harness. Nunca rodar harnesses avulsos em
paralelo com o runner; o lock só coordena executores desta entrada.

## Resultado e evidências

Runs em `.local/automation/runs/run-*/`: plano, inputs por hash antes/depois,
results.json e stdout/stderr brutos por comando, em arquivos 0600/diretórios privados.
Não existe limpeza automática de runs; revisar dados sensíveis antes de compartilhar.
O E2E guarda imagens/resultados no run e não sobrescreve observações anteriores.
HOME/PATH confiáveis do operador são usados para ferramentas locais; tokens e
NODE_OPTIONS não são herdados. O supervisor não é sandbox de segurança.

Exit agregado: 0 checks selecionados aprovados; 1 achados de segredos; 2 falha de
comando/configuração/timeout/log acima de 8MiB ou inputs alterados; 3 ferramenta ou
pré-requisito ausente/dependência bloqueada. Prioridade 2 > 3 > 1 > 0. Cada tarefa
preserva exit bruto, motivo e diagnóstico. Não interpreta palavras em stdout como
aprovação. Limite por comando 900s; cancelamento encerra grupo cooperante e preserva
logs parciais. Processos que escapem com setsid exigem contenção externa.

O SDD comum verifica evidência e rejeita drift, mas não exige aprovação agregada.
Depois de reobservar inputs afetados, execute também:

```bash
python3 sdd/tools/validate.py --root . --require-approved --require-fresh
```

Gate obrigatório para declaração de aceite das features; falhas de outra feature
são relatadas separadamente, nunca contornadas por renovar hashes antigos, mover
features ou enfraquecer critérios. O sucesso do runner parcial não representa esse
aceite. Na rota local sem feature, registrar objetivo/inputs/método/resultado/limites
no artefato de revisão já usado. Templates e skills remetem a esta política.
