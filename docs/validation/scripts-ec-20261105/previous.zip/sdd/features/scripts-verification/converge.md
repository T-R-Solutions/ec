# Convergência — scripts Ec

AC-01 a AC-03: revisão/testes em andamento, resultados finais em evidence.json e
report.md. AC-04 UNVERIFIED enquanto faltar scanner obrigatório. Preparar Gitleaks
8.30.1 explicitamente e repetir security; não substituir por aprovação parcial.
Bloqueios AC-01/AC-07 da primeira jornada são independentes desta automação.
