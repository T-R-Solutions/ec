# Ec

Plataforma independente de integração e entrega contínuas (CI/CD), planejada para administrar projetos, pipelines, execuções, agentes e entregas de software.

**Em 2026-11-04: pesquisa e preparação documental.** Este checkout contém normas, arquitetura, estrutura da aplicação e ferramentas de governança executáveis. Ec Server, Ec Agent e interface ainda não têm código de produto, manifests, instalador ou release.

## Comece aqui

| Quero… | Leia |
| --- | --- |
| Entender o produto e suas funcionalidades | [Visão funcional e técnica](docs/architecture/application-overview.md) |
| Saber o que existe e o que está pendente | [Estado do projeto](sdd/project.md) |
| Localizar código futuro e responsabilidades | [Mapa da aplicação](application/README.md) |
| Contribuir e verificar uma mudança | [Guia de contribuição](docs/development/contributing.md) |
| Consultar decisões e contratos | [Índice da documentação](docs/README.md) |

## Produto planejado

O Ec deverá oferecer gestão de projetos e repositórios; autoria de pipelines em Visual, Formulário e YAML; fila e acompanhamento de execuções; logs, testes e artefatos; agentes e pools; pessoas e permissões; ambientes, aprovações e deployments; integrações, plugins e auditoria.

O fluxo previsto é **configurar → publicar revisão → submeter execução → alocar Agent → executar → consultar resultados → promover entrega**. Funcionalidades, públicos e responsabilidades estão detalhados na [visão do produto](docs/architecture/application-overview.md).

| Componente | Tecnologia alvo | Responsabilidade |
| --- | --- | --- |
| Ec Server | Monólito modular Rust | API, configuração, autorização, fila e orquestração |
| Frontend do Server | Vue 3 + TypeScript + Pinia | Autoria, administração e operação |
| Ec Agent | Monólito modular Rust, múltiplas instâncias possíveis | Preparação, execução e envio de resultados |

Ec Agent é um executor de CI/CD; o nome não implica IA. A [arquitetura alvo](docs/architecture/application-overview.md#arquitetura-alvo) explica os limites e as relações entre componentes.

## Contratos e decisões

- **YAML canônico:** Visual, Formulário e YAML preservam a mesma semântica de configuração desejada.
- **Estado operacional:** PostgreSQL é a autoridade planejada de fila e estado; HTTP versionado é o transporte vigente.
- **Revisões e execução:** validação, autorização, revisões imutáveis, leases/fencing e retries explícitos são requisitos a implementar.
- **Segurança e interface:** autorização no backend, segredos por referência, isolamento demonstrado e WCAG 2.2 AA como critério; ainda sem comprovação de produto.

O [catálogo de contratos](docs/architecture/contracts.md) registra fontes e lacunas. gRPC/Protobuf e SQLite local permanecem propostas. Metas de 1.000/2.000 agentes não são capacidade comprovada; não há garantia de efeitos externos exatamente uma vez.

## Verificar o checkout

Pré-requisitos: **Python 3.11+**, biblioteca padrão e diretório temporário gravável. A partir da raiz do repositório:

```bash
python3 tools/governance/validate.py
python3 sdd/tools/validate.py --root .
python3 -m unittest discover -s tools/governance/tests -v
```

Os validadores devem informar `PASS` e a suíte terminar com `OK`. Esses comandos verificam governança e evidências; não iniciam nem testam a aplicação Ec. Para diagnóstico de falhas, integridade das skills e aceite com evidências atuais, consulte o [guia de contribuição](docs/development/contributing.md#verificar-a-mudança).

## Organização

| Caminho | Conteúdo |
| --- | --- |
| [application/](application/README.md) | Estrutura documental de Agent, Server e testes entre componentes |
| [docs/](docs/README.md) | Produto, arquitetura, normas, decisões e guias |
| [sdd/](sdd/README.md) | Workflow, contexto, pontes e evidências |
| [tools/governance/](tools/governance/README.md) | Auditor, instalador e testes Python |
| `config/governance/` | Catálogo, hashes e fontes preservadas |
| [reverse_engineering_teamcity/](reverse_engineering_teamcity/README.md) | Pesquisa histórica e protótipo, separados do produto |

As 67 skills selecionadas estão instaladas em `.codex/skills/`; a baseline de recuperação fica em `.local/skill-installation/skills/`. O [procedimento de instalação](docs/development/skill-installation.md) distingue integridade, instalação e limites de validação.

Antes de implementar, faltam schemas e interfaces concretas, toolchains, runners e evidências de autorização, isolamento, recuperação e acessibilidade. Consulte as [autoridades](docs/constitution.md) e a [ADR-002](docs/decisions/ADR-002-application-layout.md). Não há licença própria ou canal de suporte de produto definido por esta integração.
