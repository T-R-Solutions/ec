# Integração da interface

Estado: diretório reservado; não há cenários executáveis.

Reservado a composição de domínios, rotas, sessão e elementos compartilhados. Testes internos de um único domínio ficam no tests/ desse domínio. Declarar quando o backend for simulado e quais contratos a simulação representa.

Runner, fixtures, dependências de ambiente, descoberta e comandos permanecem pendentes. Não criar testes vazios para preencher este diretório.

[Política de testes](../../../../../docs/development/testing.md) · [Organização](../../../../../docs/architecture/application-layout.md).

[Voltar à organização dos testes](../../README.md)
