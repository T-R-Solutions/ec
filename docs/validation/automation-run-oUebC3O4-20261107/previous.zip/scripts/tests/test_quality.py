"""Oráculos dos gates padrão; fixtures não certificam os motores reais."""
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]


class QualityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ec quality with spaces ')
        self.root = Path(self.temp.name)
        self.env = dict(os.environ, EC_ROOT=str(self.root), EC_TASK_DIR=str(self.root / 'task'))
        (self.root / 'task').mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def write(self, path, content):
        target = self.root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)
        return target

    def document(self, path, value):
        return self.write(path, json.dumps(value))

    def run_shell(self, script, *args):
        return subprocess.run(  # noqa: S603, S607 — Bash confiável, script versionado e argumentos separados, sem shell=True.
            ['bash', str(ROOT / 'scripts' / script), *map(str, args)],
            cwd=self.root, env=self.env, capture_output=True, timeout=30,
        )

    def library(self, program, *args):
        # O programa é literal de cada teste; paths/valores não viram código shell.
        harness = '''set -euo pipefail
CODE=$1 ROOT=$2 TASK_DIR=$2/task
shift 2
source "$CODE/scripts/lib/common.sh"
source "$CODE/scripts/lib/inputs.sh"
source "$CODE/scripts/security/native.sh"
''' + program
        return subprocess.run(  # noqa: S603, S607 — Programa fixture literal; valores passam em parâmetros posicionais.
            ['bash', '-c', harness, 'fixture', str(ROOT), str(self.root), *map(str, args)],
            cwd=self.root, env=self.env, capture_output=True, timeout=30,
        )

    def lcov(self, hit=80, total=100, source='a.rs'):
        return f'SF:{source}\nLF:{total}\nLH:{hit}\nFNF:0\nFNH:0\nend_of_record\n'

    def test_default_and_selected_catalog_keep_new_checks_once(self):
        expected = {('server', 'geiger'), ('agent', 'geiger'), ('server', 'coverage'),
                    ('agent', 'coverage'), ('frontend', 'coverage'),
                    ('security', 'trivy'), ('security', 'codeql')}
        result = self.run_shell('automate.sh', 'plan')
        self.assertEqual(result.returncode, 0, result.stderr)
        tasks = json.loads(result.stdout)['tasks']
        keys = [(task['project'], task['name']) for task in tasks]
        self.assertTrue(expected <= set(keys))
        self.assertEqual(len(keys), len(set(keys)))
        for project in ('server', 'agent'):
            self.assertLess(keys.index((project, 'coverage')), keys.index((project, 'harness-build')))
        for project, check in sorted(expected):
            result = self.run_shell('automate.sh', 'plan', '--surface', project,
                                    '--check', check, '--check', check)
            self.assertEqual(result.returncode, 0, result.stderr)
            selected = json.loads(result.stdout)['tasks']
            self.assertEqual([(t['project'], t['name']) for t in selected if t['project'] != 'docs'],
                             [(project, check)])
        self.assertFalse((self.root / '.local').exists())

    def test_coverage_threshold_has_no_rounding_or_cross_component_average(self):
        policy = self.document('coverage.json', {
            'format': 'lcov', 'report': 'coverage.lcov', 'minimum': {'lines': 80},
        })
        for hit, expected in ((7999, 1), (8000, 0), (8001, 0)):
            with self.subTest(hit=hit):
                self.write('coverage.lcov', self.lcov(hit, 10000))
                result = self.run_shell('metrics/check.sh', 'coverage', policy)
                self.assertEqual(result.returncode, expected, result.stderr)
                metric = json.loads(result.stdout)['metrics']['lines']
                self.assertEqual((metric['covered'], metric['total']), (hit, 10000))

    def test_coverage_invalid_duplicate_empty_and_missing_reports_fail(self):
        policy = self.document('coverage.json', {
            'format': 'lcov', 'report': 'coverage.lcov', 'minimum': {'lines': 80},
        })
        self.assertEqual(self.run_shell('metrics/check.sh', 'coverage', policy).returncode, 3)
        for report in ('', 'SF:a.rs\nLF:100\n', self.lcov(101),
                       self.lcov(0, 0), self.lcov() + self.lcov()):
            with self.subTest(report=report):
                self.write('coverage.lcov', report)
                self.assertEqual(self.run_shell('metrics/check.sh', 'coverage', policy).returncode, 2)

    def test_coverage_inventory_rejects_omitted_unexercised_file(self):
        first = str(self.root / 'a.rs')
        second = str(self.root / 'never-exercised.rs')
        self.document('sources.json', [first, second])
        self.write('coverage.lcov', self.lcov(100, source=first))
        policy = self.document('coverage.json', {
            'format': 'lcov', 'report': 'coverage.lcov', 'sources': 'sources.json',
            'minimum': {'lines': 80},
        })
        self.assertEqual(self.run_shell('metrics/check.sh', 'coverage', policy).returncode, 2)
        self.write('coverage.lcov', self.lcov(100, source=first) + self.lcov(0, source=second))
        self.assertEqual(self.run_shell('metrics/check.sh', 'coverage', policy).returncode, 1)

    def test_coverage_never_reuses_previous_report(self):
        self.document('config/quality/coverage.json', {'format': 'lcov', 'minimum': {'lines': 80}})
        self.write('src/a.ts', 'export const a = 1\n')
        self.write('task/coverage-old/coverage.lcov', self.lcov(100))
        result = self.library('source "$CODE/scripts/metrics/coverage.sh"\ncoverage_begin\ncoverage_finish\n')
        self.assertEqual(result.returncode, 3, result.stderr)
        self.assertTrue((self.root / 'task/coverage-old/coverage.lcov').exists())

    def test_coverage_rejects_weakened_policy_and_input_mutation(self):
        self.document('config/quality/coverage.json', {'format': 'lcov', 'minimum': {'lines': 79}})
        self.write('application/server/frontend/src/a.ts', 'export const a = 1\n')
        prefix = 'source "$CODE/scripts/metrics/coverage.sh"\ncd "$ROOT/application/server/frontend"\ncoverage_begin\n'
        self.assertEqual(self.library(prefix).returncode, 2)
        self.document('config/quality/coverage.json', {'format': 'lcov', 'minimum': {'lines': 80}})
        result = self.library(prefix + 'echo changed >> src/a.ts\ncoverage_finish\n')
        self.assertEqual(result.returncode, 2, result.stderr)

    def test_offline_adapter_has_no_network_fallback(self):
        # Fixture bwrap registra argv e falha: nenhum segundo lançamento é permitido.
        tool = self.write('bin/bwrap', '#!/bin/bash\nprintf "%s\\n" "$@" > "$FIXTURE_ARGS"\nexit 17\n')
        tool.chmod(0o700)
        self.env.update(PATH=str(self.root / 'bin') + os.pathsep + os.environ['PATH'],
                        FIXTURE_ARGS=str(self.root / 'offline-argv.txt'))
        result = self.library('native_offline ec-fixture-scanner\n')
        self.assertEqual(result.returncode, 17, result.stderr)
        args = (self.root / 'offline-argv.txt').read_text().splitlines()
        self.assertIn('--unshare-net', args)
        self.assertIn('-i', args)
        self.assertEqual(args.count('ec-fixture-scanner'), 1)
        self.assertFalse(any(arg.startswith(('GITHUB_TOKEN=', 'TRIVY_TOKEN=')) for arg in args))

    def sarif(self):
        return {'version': '2.1.0', 'runs': [{
            'tool': {'driver': {'name': 'CodeQL', 'rules': [{'id': 'fixture'}]}},
            'results': [], 'invocations': [{'executionSuccessful': True}],
        }]}

    def parse(self, kind, report, code=0, inputs=None):
        path = self.document('report.json', report)
        args = [kind, path, code]
        if inputs is not None:
            args.extend([self.document('inputs.json', inputs), '/snapshot'])
        return self.run_shell('security/analyzers/check-report.sh', *args)

    def test_codeql_zero_exit_with_results_is_findings(self):
        report = self.sarif()
        report['runs'][0]['results'] = [{'ruleId': 'fixture'}]
        result = self.parse('sarif', report)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), {'state': 'findings', 'finding_count': 1})
        self.assertEqual(self.parse('sarif', report, 1).returncode, 2)

    def test_codeql_rejects_partial_diagnostics_suppressions_and_empty_suite(self):
        self.assertEqual(self.parse('sarif', self.sarif()).returncode, 0)
        for change in ('execution', 'diagnostic', 'configuration', 'suppression', 'rules'):
            report = self.sarif()
            run = report['runs'][0]
            if change == 'execution':
                run['invocations'][0]['executionSuccessful'] = False
            elif change in ('diagnostic', 'configuration'):
                key = 'toolExecutionNotifications' if change == 'diagnostic' else 'toolConfigurationNotifications'
                run['invocations'][0][key] = [{'level': 'warning'}]
            elif change == 'suppression':
                run['results'] = [{'ruleId': 'fixture', 'suppressions': [{'status': 'accepted'}]}]
            else:
                run['tool']['driver']['rules'] = []
            with self.subTest(change=change):
                self.assertEqual(self.parse('sarif', report).returncode, 2)

    def test_trivy_requires_all_lockfiles_and_counts_all_finding_types(self):
        locks = ['application/agents/Cargo.lock', 'application/server/backend/Cargo.lock',
                 'application/server/frontend/package-lock.json']
        report = {'SchemaVersion': 2, 'ArtifactName': 'snapshot', 'Results': [
            {'Target': '/snapshot/' + path, 'Packages': [{'Name': 'fixture'}]} for path in locks
        ]}
        inputs = dict.fromkeys(locks, 'hash')
        self.assertEqual(self.parse('trivy', report, inputs=inputs).returncode, 0)
        incomplete = copy.deepcopy(report)
        incomplete['Results'].pop()
        self.assertEqual(self.parse('trivy', incomplete, inputs=inputs).returncode, 2)
        report['Results'][0].update(Vulnerabilities=[{'VulnerabilityID': 'fixture'}],
                                    Secrets=[{'RuleID': 'fixture'}],
                                    Misconfigurations=[{'ID': 'fixture', 'Status': 'FAIL'}])
        result = self.parse('trivy', report, 1, inputs)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['finding_count'], 3)
        self.assertEqual(self.parse('trivy', report, 0, inputs).returncode, 2)
        self.assertEqual(self.parse('trivy', report, 7, inputs).returncode, 2)

    def test_trivy_redaction_preserves_count_without_secret_values(self):
        report = {'ArtifactName': 'fixture', 'Results': [{'Target': 'fixture', 'Secrets': [{
            'RuleID': 'fixture', 'Match': 'sensitive-fixture-value',
            'Code': {'Lines': [{'Content': 'sensitive-fixture-value'}]},
            'Severity': 'HIGH', 'StartLine': 1, 'EndLine': 1,
        }]}]}
        result = subprocess.run(  # noqa: S603, S607 — jq confiável e filtro versionado; JSON fixture em stdin.
            ['jq', '-f', str(ROOT / 'scripts/security/analyzers/redact-trivy.jq')],
            input=json.dumps(report).encode(), capture_output=True, timeout=10,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertNotIn(b'sensitive-fixture-value', result.stdout)
        redacted = json.loads(result.stdout)
        parsed = self.parse('trivy', redacted, 1)
        self.assertEqual(parsed.returncode, 0, parsed.stderr)
        self.assertEqual(json.loads(parsed.stdout)['finding_count'], 1)

    def native_policy(self):
        policy = json.loads((ROOT / 'config/quality/native-scanners.json').read_text())
        self.document('config/quality/native-scanners.json', policy)
        return policy

    def test_trivy_database_missing_tampered_and_upstream_expiry(self):
        self.native_policy()
        program = 'native_policy\ntrivy_database\n'
        self.assertEqual(self.library(program).returncode, 3)
        now = dt.datetime.now(dt.timezone.utc)
        data = self.write('.local/security/trivy/db/trivy.db', 'fixture')
        for updated, next_update, expected in (
            (now - dt.timedelta(hours=1), now + dt.timedelta(hours=1), 0),
            (now - dt.timedelta(hours=25), now + dt.timedelta(hours=1), 3),
            (now, now - dt.timedelta(seconds=1), 3),
            (now + dt.timedelta(hours=1), now + dt.timedelta(hours=2), 3),
        ):
            metadata = self.document('.local/security/trivy/db/metadata.json', {
                'Version': 2, 'UpdatedAt': updated.isoformat(), 'NextUpdate': next_update.isoformat(),
            })
            self.document('.local/security/trivy/manifest.json', {
                'schema': 1, 'version': '0.61.1', 'files': {
                    'metadata.json': hashlib.sha256(metadata.read_bytes()).hexdigest(),
                    'trivy.db': hashlib.sha256(data.read_bytes()).hexdigest(),
                },
            })
            result = self.library(program)
            self.assertEqual(result.returncode, expected, result.stderr)
        data.write_text('tampered')
        self.assertEqual(self.library(program).returncode, 2)

    def test_missing_codeql_bundle_and_pack_block(self):
        self.native_policy()
        self.assertEqual(self.library('native_policy\ncodeql_bundle\n').returncode, 3)
        program = 'native_policy\nCODEQL_BUNDLE=$ROOT/bundle\ncodeql_packs\n'
        self.assertEqual(self.library(program).returncode, 3)
        self.assertEqual(self.library('native_version ec-tool-that-does-not-exist 1.0.0\n').returncode, 3)

    def test_codeql_database_bound_to_sources_and_configuration(self):
        self.native_policy()
        self.write('application/server/backend/src/lib.rs', 'pub fn a() {}\n')
        self.write('config/quality/codeql-rust.qls', '# fixture\n')
        self.write('task/bundle-files.json', '{}\n')
        self.write('task/codeql', 'fixture')
        self.write('.local/security/codeql/server/database/data', 'database')
        program = '''native_policy
CODEQL=$TASK_DIR/codeql
native_workspace_inputs server "$TASK_DIR/current.json"
native_tree "$ROOT/.local/security/codeql/server/database" "$TASK_DIR/files.json"
jq -n --arg cli "$(hash "$CODEQL")" --arg policy "$(hash "$NATIVE_POLICY")" --arg bundle "$(hash "$TASK_DIR/bundle-files.json")" --slurpfile inputs "$TASK_DIR/current.json" --slurpfile files "$TASK_DIR/files.json" '{schema:1,project:"server",cli_sha256:$cli,policy_sha256:$policy,bundle_sha256:$bundle,inputs:$inputs[0],files:$files[0]}' > "$ROOT/.local/security/codeql/server/manifest.json"
codeql_database server
'''
        result = self.library(program)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.write('application/server/backend/src/lib.rs', 'pub fn changed() {}\n')
        result = self.library('native_policy\nCODEQL=$TASK_DIR/codeql\ncodeql_database server\n')
        self.assertEqual(result.returncode, 3, result.stderr)
        self.write('application/server/backend/src/lib.rs', 'pub fn a() {}\n')
        self.write('.local/security/codeql/server/database/data', 'tampered')
        result = self.library('native_policy\nCODEQL=$TASK_DIR/codeql\ncodeql_database server\n')
        self.assertEqual(result.returncode, 2, result.stderr)


if __name__ == '__main__':
    unittest.main()
