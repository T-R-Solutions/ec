# Scanners nativos e cobertura padrão

Atualização de 2026-11-07: Geiger, Coverage, Trivy e CodeQL integram o catálogo
padrão. Esta configuração foi implementada e inspecionada; os novos contratos
e motores ainda não foram executados nesta alteração. O acionamento de verificações
segue [a política canônica](../../docs/development/task-verification.md).

## Cobertura e Geiger

`config/quality/coverage.json` estabelece cobertura de **linhas >=80%**, por
workspace Server, workspace Agent e pacote frontend. Não há média entre eles nem
arredondamento para aprovar. O avaliador usa contadores inteiros e registra
`covered`, `total`, `actual`, `minimum` e `passed` no `coverage.json` da tarefa,
também anexado ao results.json do run. Cobertura insuficiente retorna 1 no check;
o supervisor mantém o contrato de classificar falhas de qualidade como error (2).

Rust usa cargo-llvm-cov, todos os targets/features e toolchain do workspace;
llvm-tools-preview deve estar instalado previamente. Cada execução usa target
privado novo, sem compartilhar instrumentação com os harnesses. São incluídas as
fontes `.rs` em `crates/*/src`, com exclusão dos arquivos/diretórios de testes
externos reconhecidos pelo cargo-llvm-cov. Testes inline não são subtraídos
artificialmente. Dependências, target, exemplos/benches externos e fontes geradas
fora do src não integram o inventário. Arquivos de produção ausentes do LCOV
reprovam a completude, inclusive se não foram exercitados ou compilados.

Frontend usa Vitest e @vitest/coverage-v8 **4.1.12**, com fontes `src/**/*.ts` e
`src/**/*.vue` incluídas mesmo sem importação por testes; exclui apenas declarações
`.d.ts` e testes `.test.ts`/`.spec.ts`. O LCOV deve corresponder ao inventário.
Módulos sem instruções executáveis podem exigir investigação do relatório real;
isso não autoriza remover arquivos para atingir 80%. HTML/CSS não são métricas
de linhas executáveis neste gate. O provider foi acrescentado ao lockfile; preparar
dependências com o fluxo npm explícito documentado no projeto.

Geração e avaliação ocorrem em diretório novo do mesmo run, com hashes dos inputs
antes/depois; nenhum relatório anterior é fallback. Relatório ausente bloqueia;
truncamento, duplicação, inventário divergente, falha do produtor e denominador vazio
reprovam. O parser LCOV continua disponível para políticas próprias de outras métricas.

Geiger preserva o inventário nativo em `geiger.txt`, exit e versão/hash do plugin,
e `workspace.json` identifica os membros próprios para distinguir dependências.
Não impõe zero unsafe. Não mede segurança semântica nem prova vulnerabilidades.

## Trivy 0.61.1

Mantém-se a versão já fixada pelo Ec para evitar migração silenciosa do contrato.
Ela não é declarada a versão mais recente ou uma certificação empresarial.
`native-scanners.json` e `trivy.yaml` tornam explícitas as decisões:

- `vuln`, `misconfig` e `secret`, todas as severidades, dependências de desenvolvimento
  incluídas, sem ignorar vulnerabilidades sem correção ou status específicos;
- snapshot de `application/` e `config/quality/`, preservando caminhos, incluindo
  os dois Cargo.lock e package-lock.json; caches, dependências instaladas, outputs,
  histórico Git e pesquisa histórica ficam fora;
- verificações de configuração somente nos formatos reconhecidos pelo Trivy;
  YAML Ec arbitrário não equivale a uma política IaC suportada;
- arquivo de ignore vazio e configuração de segredos vazia explícitos; regras
  embutidas da versão continuam vigentes, incluindo suas limitações e allow rules;
  marcadores inline Trivy/AVD/tfsec são rejeitados antes do scan;
- VEX e fontes SBOM remotas desabilitados, sem atualizações de DB/checks no scan;
  checks de misconfiguração são os embutidos no executável, identificados pelo seu hash;
- bwrap desabilita a rede independentemente de telemetria/consultas internas.

O parser exige inventário de pacotes nos três lockfiles e conta vulnerabilidades,
segredos e configurações com status FAIL. Status/supressões não aceitos, relatório
incompleto ou exit inconsistente reprovam. Os valores/trechos de segredos são
removidos no pipe JSON antes de persistir o relatório; não se habilita debug ou
traces HTTP. O snapshot privado contém as fontes originais e deve ser protegido
antes de compartilhar evidências.

Preparo explícito, fora do scan:

```bash
bash scripts/prepare.sh native trivy-db
```

A CLI precisa estar previamente instalada pelo operador a partir da release oficial,
com integridade/procedência conferidas. O preparo baixa somente a base oficial
`ghcr.io/aquasecurity/trivy-db:2`, em diretório novo, e publica com manifesto de hashes;
uma base anterior permanece no diretório privado de preparo. Não há comando de
revalidação que apenas renove um timestamp.

Frescor: schema 2, UpdatedAt upstream não futuro e com até **24h**, e NextUpdate
upstream ainda não vencido. O prazo de 24h é uma decisão operacional conservadora
coerente com o snapshot OSV do Ec; não é garantia do fornecedor. Data local de
download não substitui esses metadados. O scan copia a DB e verifica seus hashes
antes/depois. Hash local detecta alteração, mas não autentica o editor da base.

## CodeQL 2.27.3

CLI e packs provêm do mesmo bundle oficial: `codeql/rust-queries@0.1.45` e
`codeql/javascript-queries@2.4.8`, com suas dependências transitivas incluídas no
manifesto de hashes do bundle. Suites security-extended são fixadas nos dois `.qls`.
Essa suite amplia as consultas de segurança e pode produzir mais falsos positivos;
não são aplicadas exclusões para aprovar o gate.

O operador deve verificar elegibilidade/licença conforme os termos oficiais antes
de obter/usar o bundle. Repositórios privados não ganham elegibilidade por executar
a CLI localmente. Não há contratação, login, uso de tokens ou upload automático.

Obtenha a release `codeql-bundle-v2.27.3` para a plataforma do host a partir das
releases oficiais de codeql-action. Confira os hashes/procedência publicados antes
de extrair o diretório `codeql` como `.local/security/codeql/bundle`, contendo
`codeql` e `qlpacks`. O registro abaixo identifica os bytes locais; ele próprio não
verifica assinatura nem torna confiável um arquivo de origem desconhecida.

```bash
bash scripts/prepare.sh native codeql-bundle
bash scripts/prepare.sh native codeql-db server
bash scripts/prepare.sh native codeql-db agent
bash scripts/prepare.sh native codeql-db frontend
```

O preparo compartilha o lock do runner e extrai bancos novos em diretórios privados,
sem rede, a partir de snapshots com hashes. Rust usa o extractor da versão fixada,
que declara `build_modes: [none]`; ainda pode executar build.rs/proc-macros por
rust-analyzer. Exige rustup/cargo/toolchain/caches previamente preparados; o cache
Cargo é copiado para a área privada para evitar alterações no original. TypeScript
usa o extractor JavaScript, exige Node e inclui suporte a arquivos Vue. Suporte ao
formato não implica modelagem completa de todo framework ou dependência.

Cada banco finalizado tem `manifest.json` vinculando fontes, manifests/locks,
configurações de qualidade, CLI, bundle e arquivos do banco. Divergência exige
recriação explícita. Todos os bancos são conferidos antes da análise e copiados
para o run; somente a cópia pode receber caches/resultados do CodeQL.

O scan usa bwrap sem rede, HOME/config/cache privados e somente a tarefa gravável;
não há pack download. É um controle de rede/escrita para ferramentas confiáveis,
não uma garantia de isolamento para código hostil. bwrap indisponível bloqueia;
namespace negado pelo host é erro operacional, sem fallback com rede.

Há SARIF separado por componente, sem conteúdo/snippets de arquivos. Exit zero da
CLI com resultados vira findings. Qualquer não zero da CLI é erro operacional.
SARIF sem invocação bem-sucedida, sem regras, com supressões ou com notificações
de erro/aviso reprova, inclusive se houver resultados parciais. A decisão é
conservadora: investigar avisos reais antes de flexibilizar qualquer diagnóstico.
Resultados não demonstram completude semântica absoluta da extração.

O limite do supervisor permanece 900s por tarefa; CodeQL analisa os três bancos
sequencialmente dentro dele. Tamanho dos bancos/bundle, disco, RAM e duração reais
precisam ser observados no ambiente autorizado. Preparos e evidências não têm
limpeza automática.

## Fontes oficiais consultadas em 2026-11-07

- Trivy: [configuração 0.61](https://trivy.dev/v0.61/docs/references/configuration/config-file/),
  [flags VEX/ignore na fonte 0.61.1](https://github.com/aquasecurity/trivy/blob/v0.61.1/pkg/flag/vulnerability_flags.go),
  [conectividade](https://trivy.dev/docs/latest/guide/advanced/air-gap/).
  Flags de telemetria de versões posteriores não são presumidas na 0.61.1;
  o bloqueio de rede é externo à ferramenta.
- CodeQL: [release 2.27.3](https://github.com/github/codeql-cli-binaries/releases/tag/v2.27.3),
  [bundle oficial](https://github.com/github/codeql-action/releases/tag/codeql-bundle-v2.27.3),
  [CLI e elegibilidade](https://docs.github.com/en/code-security/concepts/code-scanning/codeql/codeql-cli),
  [suites](https://docs.github.com/en/code-security/concepts/code-scanning/codeql/codeql-query-suites),
  [criação de suites](https://docs.github.com/en/code-security/tutorials/customize-code-scanning/create-query-suites),
  [extração](https://docs.github.com/en/code-security/tutorials/customize-code-scanning/prepare-code-for-analysis),
  [database analyze](https://docs.github.com/en/code-security/reference/code-scanning/codeql/codeql-cli-manual/database-analyze).
- Contratos versionados do bundle: [extractor Rust](https://github.com/github/codeql/blob/codeql-cli/v2.27.3/rust/codeql-extractor.yml),
  [pack Rust](https://github.com/github/codeql/blob/codeql-cli/v2.27.3/rust/ql/src/qlpack.yml),
  [pack JavaScript](https://github.com/github/codeql/blob/codeql-cli/v2.27.3/javascript/ql/src/qlpack.yml).
  A referência genérica de database create consultada omite Rust em sua lista de
  build-mode none; o extractor versionado e o guia de extração o incluem.
- Cobertura: [cargo-llvm-cov](https://github.com/taiki-e/cargo-llvm-cov),
  [Vitest coverage/include](https://vitest.dev/config/coverage),
  [Geiger](https://github.com/geiger-rs/cargo-geiger).
