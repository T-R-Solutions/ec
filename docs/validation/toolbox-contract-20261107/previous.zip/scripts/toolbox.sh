#!/usr/bin/env bash
set -euo pipefail
umask 077
CODE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
source "$CODE/scripts/lib/common.sh"
source "$CODE/scripts/lib/inputs.sh"
source "$CODE/scripts/lib/toolbox.sh"
[[ $# -ge 1 && $# -le 2 ]] || fail 'uso: toolbox.sh ruff|shellcheck|playwright|gitleaks|opengrep|osv-scanner|trivy'
case $1 in ruff|shellcheck|playwright|gitleaks|opengrep|osv-scanner|trivy) ;; *) fail 'ferramenta desconhecida';; esac
ROOT=${EC_ROOT:-$CODE}
TASK_DIR=${EC_TASK_DIR:?executar por scripts/automate.sh}
toolbox_run "$1" "${2:-scan}"
