#!/usr/bin/env bash
set -euo pipefail
umask 077
CODE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)
source "$CODE/scripts/lib/common.sh"
source "$CODE/scripts/lib/inputs.sh"
[[ $# == 1 ]] || fail 'uso: check.sh secrets|sast-rules|sast|dependencies|trivy|codeql'
check=$1
ROOT=${EC_ROOT:-$CODE}
if [[ -z ${EC_TASK_DIR:-} ]]; then
    exec bash "$CODE/scripts/automate.sh" run --surface security --check "$check"
fi
TASK_DIR=$EC_TASK_DIR
export SEMGREP_SEND_METRICS=off SEMGREP_ENABLE_VERSION_CHECK=0 OPENGREP_ENABLE_VERSION_CHECK=0 SEMGREP_SETTINGS_FILE=$TASK_DIR/settings.yml
source "$CODE/scripts/security/lib.sh"
source "$CODE/scripts/lib/toolbox.sh"
case $check in
    secrets) exec bash "$CODE/scripts/toolbox.sh" gitleaks;;
    sast-rules) exec bash "$CODE/scripts/toolbox.sh" opengrep test;;
    sast) exec bash "$CODE/scripts/toolbox.sh" opengrep;;
    dependencies) exec bash "$CODE/scripts/toolbox.sh" osv-scanner;;
esac
source "$CODE/scripts/security/native.sh"
native_policy
need bwrap
mkdir -p "$TASK_DIR/home"
case $check in
    trivy)
        native_version trivy "$(jq -r .trivy.version "$NATIVE_POLICY")"
        trivy_database
        observe_inputs trivy "$TASK_DIR/source-inputs.json" "$TASK_DIR/source"
        # Supressões inline não podem transformar omissões em ausência de achados.
        need rg
        if rg -l 'trivy:ignore|avd:ignore|tfsec:ignore' "$TASK_DIR/source" > "$TASK_DIR/suppression-paths.txt"; then
            fail 'supressão inline Trivy proibida; consultar suppression-paths.txt'
        else
            rc=$?
            (( rc == 1 )) || fail 'inspeção de supressões Trivy falhou'
        fi
        mkdir -p "$TASK_DIR/cache"
        cp -R "$ROOT/.local/security/trivy/db" "$TASK_DIR/cache/db"
        : > "$TASK_DIR/empty-trivyignore"
        printf '{}\n' > "$TASK_DIR/secret.yaml"
        argv=(trivy fs --config "$ROOT/config/quality/trivy.yaml" --cache-dir "$TASK_DIR/cache" --ignorefile "$TASK_DIR/empty-trivyignore" --secret-config "$TASK_DIR/secret.yaml" --offline-scan --skip-db-update --skip-java-db-update --skip-check-update --skip-vex-repo-update --exit-code 1 --format json "$TASK_DIR/source")
        # Redigir no pipe: valores de segredos não são gravados no relatório bruto.
        statuses=()
        if native_offline "${argv[@]}" | jq -f "$CODE/scripts/security/analyzers/redact-trivy.jq" > "$TASK_DIR/report.json"; then
            statuses=("${PIPESTATUS[@]}")
        else
            statuses=("${PIPESTATUS[@]}")
        fi
        printf '%s\n' "${statuses[0]}" > "$TASK_DIR/scanner-exit.txt"
        (( statuses[1] == 0 )) || fail 'relatório Trivy inválido na redação'
        bash "$CODE/scripts/security/analyzers/check-report.sh" trivy "$TASK_DIR/report.json" "${statuses[0]}" "$TASK_DIR/source-inputs.json" "$TASK_DIR/source" > "$TASK_DIR/classification.json"
        native_tree "$TASK_DIR/cache/db" "$TASK_DIR/database-after.json"
        cmp -s "$TASK_DIR/database-files.json" "$TASK_DIR/database-after.json" || fail 'base Trivy alterada durante scan';;
    codeql)
        codeql_bundle
        # Preflight dos três bancos antes de executar qualquer análise.
        for project in server agent frontend; do codeql_database "$project"; done
        for project in server agent frontend; do
            suite=$(jq -r --arg project "$project" '.codeql.projects[$project].suite' "$NATIVE_POLICY")
            rc=0
            native_offline "$CODEQL" database analyze "$TASK_DIR/$project-database" "$ROOT/$suite" \
                --search-path="$CODEQL_BUNDLE/qlpacks" --format=sarifv2.1.0 \
                --rerun --threads=2 --ram=4096 --no-sarif-add-snippets --no-sarif-add-file-contents \
                --output="$TASK_DIR/$project.sarif" || rc=$?
            printf '%s\n' "$rc" > "$TASK_DIR/$project-exit.txt"
            bash "$CODE/scripts/security/analyzers/check-report.sh" sarif "$TASK_DIR/$project.sarif" "$rc" > "$TASK_DIR/$project-classification.json"
            native_workspace_inputs "$project" "$TASK_DIR/$project-inputs-after.json"
            cmp -s "$TASK_DIR/$project-inputs.json" "$TASK_DIR/$project-inputs-after.json" || fail 'fontes/configurações alteradas durante análise CodeQL'
        done
        native_tree "$CODEQL_BUNDLE" "$TASK_DIR/bundle-after.json"
        cmp -s "$TASK_DIR/bundle-files.json" "$TASK_DIR/bundle-after.json" || fail 'bundle CodeQL alterado durante análise'
        jq -s '{state:(if any(.[];.state=="findings") then "findings" else "passed" end),finding_count:([.[].finding_count]|add)}' \
            "$TASK_DIR/server-classification.json" "$TASK_DIR/agent-classification.json" "$TASK_DIR/frontend-classification.json" > "$TASK_DIR/classification.json";;
    *) fail "check desconhecido: $check";;
esac
jq -e '.state=="passed"' "$TASK_DIR/classification.json" >/dev/null || exit 1
