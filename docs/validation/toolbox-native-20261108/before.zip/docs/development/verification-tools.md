# Ferramentas de verificação

A integração vigente segue o [contrato STIC do Ec](../../scripts/README.md).
Configuração canônica em `scripts/config/`; tarefas próprias em `scripts/stacks/`.
O wrapper comum usa exclusivamente `TOOLBOX_BIN`/PATH e CLI pública. Não há imports
internos da Toolbox, fallback de scanner nem instalador local.

A [migração de 08/11/2026](../validation/scripts-stic-20261108/report.md) removeu
ferramentas baixadas dentro do Ec por pedido explícito. Preservou regras, políticas,
locks e evidências. Cargo/npm e suas dependências de aplicação continuam próprios;
plugins de verificação Cargo e base RustSec devem ser preparados externamente.
Nenhuma análise ou preparo foi executado nesta tarefa.

A configuração exige capacidades da plataforma ainda não implementadas: política
estrita de supressões, layout 2, export e staging com manifesto. Os gates do Ec
ficam bloqueados até integração e homologação dessas APIs. CodeQL não tem adapter;
Trivy exige paridade vuln/misconfig/secret; YARA-X continua indisponível. O catálogo
não omite esses requisitos nem classifica medição Syft como aprovação.

O lock anterior foi movido sem alteração de bytes. Presença de lock não comprova
imagem, adapter compatível ou DB fresca. Preparo e update-db são operações
explícitas na plataforma, com autorização específica para downloads. O ID de uma
base atualizada exige revisão e adoção separada; não aumentar idade máxima nem
inventar identidades para contornar bloqueios.

Comandos e localização das configurações estão em [scripts/](../../scripts/README.md).
O acionamento de verificações segue exclusivamente a
[política canônica](task-verification.md).
