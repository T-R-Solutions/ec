#!/usr/bin/env bash
# Shared consumer wrapper 1.0.0. Bash, not POSIX sh. No product-specific logic.
set -euo pipefail
if (( BASH_VERSINFO[0] < 4 || (BASH_VERSINFO[0] == 4 && BASH_VERSINFO[1] < 4) )); then
    printf 'Toolbox requires Bash 4.4 or newer.\n' >&2
    exit 2
fi
if [[ ${TOOLBOX_BIN+x} ]]; then
    toolbox_bin=$TOOLBOX_BIN
else
    toolbox_bin=$(type -P toolbox) || {
        printf 'Toolbox unavailable: set TOOLBOX_BIN or add toolbox to PATH.\n' >&2
        exit 2
    }
fi
if [[ ! -f $toolbox_bin || ! -x $toolbox_bin ]]; then
    printf 'TOOLBOX_BIN must identify an executable file.\n' >&2
    exit 2
fi
toolbox_bin=$(cd -- "$(dirname -- "$toolbox_bin")" && pwd -P)/$(basename -- "$toolbox_bin")
script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
exec "$toolbox_bin" consumer --integration "$script_dir/config/integration.json" -- "$@"
