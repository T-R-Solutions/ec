"""Contrato público e rejeições; mocks não homologam scanners nem capacidades."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]


class ConsumerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ec consumer with spaces ')
        self.directory = Path(self.temp.name)
        self.env = dict(os.environ)
        self.env.pop('TOOLBOX_BIN', None)
        self.env.pop('EC_TOOLBOX_BIN', None)

    def tearDown(self):
        self.temp.cleanup()

    def invoke(self, *arguments):
        return subprocess.run(  # noqa: S603 — Wrapper versionado, argv separado.
            ['bash', str(ROOT / 'scripts/toolbox.sh'), *arguments],  # noqa: S607 — Bash do ambiente de testes.
            cwd=self.directory, env=self.env, capture_output=True, timeout=10,
        )

    def test_invalid_explicit_binary_never_falls_back(self):
        self.env['TOOLBOX_BIN'] = str(self.directory / 'missing')
        self.assertEqual(self.invoke('run').returncode, 2)
        self.env['TOOLBOX_BIN'] = ''
        self.assertEqual(self.invoke('help').returncode, 2)

    def test_argv_and_raw_exits_from_unrelated_cwd(self):
        binary = self.directory / 'toolbox fixture'
        capture = self.directory / 'argv'
        binary.write_text('#!/bin/bash\nprintf "%s\\0" "$@" > "$CAPTURE"\nexit "$CODE"\n')
        binary.chmod(0o700)
        self.env.update(TOOLBOX_BIN=str(binary), CAPTURE=str(capture))
        for code in (0, 1, 2, 3, 17):
            self.env['CODE'] = str(code)
            argument = 'tool with spaces;$(touch forbidden)'
            result = self.invoke('run', '--only', argument)
            self.assertEqual(result.returncode, code, result.stderr)
            args = capture.read_bytes().split(b'\0')[:-1]
            self.assertEqual(args, [b'consumer', b'--integration',
                str(ROOT / 'scripts/config/integration.json').encode(),
                b'--', b'run', b'--only', argument.encode()])
            self.assertFalse((self.directory / 'forbidden').exists())

    def test_required_capabilities_are_not_removed_for_green(self):
        integration = json.loads((ROOT / 'scripts/config/integration.json').read_text())
        self.assertEqual(integration['toolbox_config'], 'toolbox.json')
        self.assertTrue({'suppression-policy-v2', 'layout-v2', 'export',
                         'staging-manifest-v1'} <= set(integration['required_capabilities']))

    def test_scanner_gates_never_approve_without_equivalence(self):
        for check in ('ruff', 'shellcheck', 'playwright', 'secrets', 'secrets-rules',
                      'sast', 'sast-rules', 'dependencies', 'trivy', 'codeql',
                      'trivy-toolbox', 'grype', 'bandit', 'syft', 'yara-x'):
            result = subprocess.run(  # noqa: S603 — Gate versionado e enumeração fixa.
                ['bash', str(ROOT / 'scripts/stacks/ec/scanner-gate.sh'), check],  # noqa: S607 — Bash do ambiente de testes.
                cwd=self.directory, env=self.env, capture_output=True, timeout=10,
            )
            self.assertEqual(result.returncode, 3, (check, result.stderr))
            self.assertIn(b'blocked:', result.stderr)
        self.assertFalse((self.directory / '.local').exists())

    def test_selection_and_paths_match_current_tree(self):
        config = json.loads((ROOT / 'scripts/config/toolbox.json').read_text())
        self.assertEqual((ROOT / 'scripts/config' / config['root']).resolve(), ROOT)
        expected = sorted(str(p.relative_to(ROOT)) for p in (ROOT / 'scripts').rglob('*.sh'))
        self.assertEqual(config['tools']['shellcheck']['paths'], expected)
        for tool in config['tools'].values():
            if 'config' in tool:
                self.assertTrue((ROOT / tool['config']).exists(), tool['config'])
        self.assertFalse((ROOT / 'tools/toolbox_consumer').exists())
        self.assertFalse((ROOT / 'toolbox.json').exists())
        self.assertFalse((ROOT / 'scripts/toolbox-local.sh').exists())


if __name__ == '__main__':
    unittest.main()
