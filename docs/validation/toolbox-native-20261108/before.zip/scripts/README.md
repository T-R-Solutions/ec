# Automação do Ec e integração STIC

Atualização: 08/11/2026. `scripts/toolbox.sh` é o wrapper comum **1.0.0**, copiado
sem alterações da Shared Toolbox. A estrutura foi migrada para STIC 1.0, mas a
integração operacional permanece **bloqueada** por capacidades ausentes da plataforma.
A limpeza solicitada removeu os downloads locais; não houve preparo nem execução.

Fonte normativa consultada:
`/home/rodrigo/Projetos/dev_audit/shared-toolbox/docs/doc.md`.
Esse caminho identifica o documento consultado; não é usado para descobrir a CLI.
O [relatório da migração](../docs/validation/scripts-stic-20261108/report.md)
registra identidades, remoções, alterações e limites.

## Organização e responsabilidades

| Caminho | Responsabilidade |
| --- | --- |
| `toolbox.sh` | Descoberta e encaminhamento à CLI pública `consumer`; nenhum adapter local |
| `config/integration.json` | Contrato, stacks Rust/frontend/Python e capacidades exigidas |
| `config/toolbox.json` | Seleção explícita das ferramentas; root `../..`, relativo à config |
| `config/toolbox.images.lock.json` | Lock anterior preservado; requer preparo/revalidação externa |
| `config/native/` | Configurações específicas realmente selecionadas |
| `rules/opengrep/` | Regras Rust/TypeScript/Vue e fixtures de eficácia |
| `rules/codeql/` | Suites requeridas; execução bloqueada até adapter equivalente |
| `stacks/rust/`, `stacks/frontend/` | Tarefas Cargo/npm do produto |
| `stacks/ec/` | Catálogo, supervisão, inputs, integração, cobertura e critérios do Ec |
| `tests/` | Contratos do consumidor e tarefas locais; execução pela suíte autorizada |
| `automate.sh`, `check.sh` | Entrada de verificação do Ec e sintaxe shell da suíte |

Não existem `scripts/lib/`, bridge Python, downloader de scanners, backend nativo
Trivy/CodeQL nem config Toolbox na raiz. Os parsers em `stacks/ec/security/`
conservam critérios do produto e seus testes; não executam scanners nem constituem
uma implementação alternativa da plataforma.

## Interface pública

O operador fornece `TOOLBOX_BIN` com um executável confiável, ou disponibiliza
`toolbox` no PATH. Override inválido falha; não existe descoberta em pastas pessoais,
uso de `EC_TOOLBOX_BIN` ou fallback para scanner nativo. Bash 4.4+ é obrigatório.
Os argumentos são encaminhados sem `eval`; config independe do cwd do chamador.

```bash
bash scripts/toolbox.sh help
bash scripts/toolbox.sh doctor
bash scripts/toolbox.sh catalog
bash scripts/toolbox.sh validate
bash scripts/toolbox.sh plan --only shellcheck
bash scripts/toolbox.sh versions
bash scripts/toolbox.sh run --only ruff
bash scripts/toolbox.sh results --project ec
```

Esses exemplos descrevem a interface, não autorizam executar checks fora da
[política de verificação](../docs/development/task-verification.md). `help` explica
a CLI; os demais comandos negociam capacidades e a plataforma atual rejeita as
capacidades exigidas pelo Ec. A presença de JSON e locks não certifica prontidão.
`export` ainda não é implementado pela plataforma e não é simulado pelo consumidor.

Manutenção explícita, somente com autorização específica para downloads:

```bash
bash scripts/toolbox.sh prepare --only shellcheck
bash scripts/toolbox.sh prepare --all
bash scripts/toolbox.sh update-db --only osv-scanner
```

`--all` seleciona somente as ferramentas declaradas. `update-db` não adota
automaticamente o ID retornado na config. O lock é produzido pela plataforma;
nunca corrigir incompatibilidades editando apenas hashes de adapters. Não houve
nenhuma dessas operações nesta migração.

## Critérios preservados e bloqueios

`config/integration.json` exige `suppression-policy-v2`, `layout-v2`, `export` e
`staging-manifest-v1`, ainda ausentes na plataforma consultada. A negociação recusa
a configuração antes de criar runs ou alterar locks. Não retirar esses requisitos
para obter sucesso. Após disponibilização, ainda é necessário integrar os gates
à API pública de staging/export e homologar a equivalência; não há ativação automática.

| Critério | Situação após migração |
| --- | --- |
| Ruff/ShellCheck, Gitleaks, Opengrep, OSV e Playwright | Gates Ec bloqueados até integração pública completa, preservando seleção e regras |
| Testes reais Gitleaks/Opengrep | Bloqueados até transporte público de fixtures; não substituídos por mocks |
| Trivy obrigatório | Exige vuln/misconfig/secret; adapter atual cobre somente vuln |
| CodeQL obrigatório | Sem adapter; exige análise Server/Agent Rust e frontend JS/TS |
| Trivy Toolbox, Grype, Bandit, Syft e YARA-X | Permanecem adicionais; YARA-X sem adapter/regras e demais dependem da integração |
| Syft | Medição SBOM, nunca aprovação de segurança; conversão de resultados pendente |
| Supressões | Política estrita permanece exigida; Bandit YAML sozinho não impõe ignore-nosec |
| Locks e bases | Playwright/Opengrep/OSV incompatíveis com adapters observados; ferramentas adicionais sem lock; OSV vencida, Trivy/Grype sem base selecionada |

`stacks/ec/scanner-gate.sh` retorna 3 com diagnóstico para esses critérios. O
catálogo continua incluindo os gates obrigatórios, portanto uma suíte incompleta
não aprova. A configuração Trivy `native/` é a do adapter vuln adicional, não
alegação de equivalência com o gate completo.

## Estado, armazenamento e limpeza

Volumes de ferramentas pertencem à plataforma em `tools/<tool>/volume/`.
`TOOLBOX_STATE` é configuração operacional de índices externos, não mecanismo para
mover volumes ao Ec. Não apontá-lo para as fontes ou para `.local/verification/`.
A restrição documental anterior de volumes exclusivamente dentro do Ec é superada
pelo pedido atual de adequação; permissões reais do ambiente continuam obrigatórias.
Nenhum arquivo da plataforma externa foi alterado nesta tarefa.

No Ec, `.local/verification/staging/` e `exports/` são reservados para snapshots e
exportações explícitas quando houver API pública. Não são caches de scanners.
O supervisor de **tarefas do produto** conserva `.local/automation/runs/`, logs
brutos e resultados schema 1, sem rotulá-los como layout 2 da Toolbox. Não reescreve
runs antigos. Índices e recibos remanescentes de `.local/toolbox/` são históricos;
a ponte foi removida e bases antigas excluídas por pedido explícito do usuário.

Foram removidos CodeQL/bundle/pacote, cargo-deny/cargo-machete e cópias de download,
RustSec local/advisory-dbs, bases OSV e payloads de imagens da ponte
(Gitleaks, Opengrep, OSV, Node/Playwright, Ruff e ShellCheck). Relatórios, recibos, fontes, skills,
dependências Cargo/npm da aplicação e ferramentas externas permanecem. A lista
por arquivo e SHA256 está no relatório. Não há cópia oculta dos downloads no Ec;
reinstalação exige preparo externo explícito.

## Tarefas locais do produto

`automate.sh` conserva superfícies docs/scripts/server/agent/frontend/security/
integration/e2e, seleção, locks, timeouts, logs e detecção de drift. Cargo usa
workspace/toolchain reais, locked/offline, fmt, Clippy, testes e cobertura >=80%.
Plugins Cargo são pré-requisitos externos no PATH/`EC_CARGO_BIN`; nenhum instalador
local permanece. cargo-audit exige `EC_RUSTSEC_DB` preparado externamente, fresco e
sem fetch. cargo-deny exige base externa previamente preparada no Cargo home usado.
Frontend usa npm e lockfile do projeto; Playwright aponta às fixtures autocontidas
com API simulada e build prévio, sem alegar jornada real completa.

Execute a suíte somente após pedido de commit e escolha conforme a política.
Testes atualizados nesta migração **não foram executados**. Os bloqueios acima
impedem declarar homologação ou sucesso da suíte.
