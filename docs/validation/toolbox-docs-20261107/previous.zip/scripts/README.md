# Scripts do Ec

Scripts operacionais em **Bash 5+**; Python em `tests/` serve exclusivamente para
exercitar os scripts shell. Python de `tools/`, `sdd/` e dos harnesses da aplicação
permanece fora desta pasta e pode ser chamado pelos checks correspondentes.
Linux, jq 1.6+, GNU coreutils, findutils, gzip, awk e util-linux são pré-requisitos.
Não há instalação implícita de executáveis, pacotes, bases ou toolchains.

```bash
bash scripts/automate.sh plan
bash scripts/automate.sh run
bash scripts/automate.sh run --surface docs --surface scripts
bash scripts/automate.sh run --surface server --check machete
bash scripts/automate.sh run --surface frontend --check coverage
bash scripts/automate.sh run --check sast
python3 -m unittest discover -s scripts/tests -v
bash scripts/reports/summarize.sh .local/automation/runs/RUN/results.json
```

O padrão cobre as oito superfícies da [política canônica](../docs/development/task-verification.md).
Geiger e cobertura Rust/frontend, Trivy e CodeQL fazem parte do padrão.
Checks adicionais são explícitos: não substituem o conjunto obrigatório.
`--check` pode ser repetido, sempre conserva governança e rejeita seleção incompatível.
`--root` aceita uma cópia completa, inclusive com espaços. `plan` não executa tarefas.

| Pasta/entrada | Responsabilidade |
| --- | --- |
| `automate.sh` | CLI, seleção e composição do plano |
| `lib/common.sh` | Falhas, paths, hashes e JSON |
| `lib/catalog.sh` | Única definição das tarefas/superfícies |
| `lib/inputs.sh` | Inventário e snapshots das fontes |
| `lib/runtime.sh` | Lock, ambiente restrito, grupos, timeout, logs, estados e evidências |
| `lib/integration.sh` | Pré-requisitos dos harnesses PostgreSQL/HTTP/browser |
| `rust/check.sh` | fmt, clippy, test, harness-build, machete, deny, geiger, audit e coverage |
| `frontend/check.sh` | typecheck, test, build, dev, setup, lint, coverage, build-budget e performance |
| `frontend/eslint-ratchet.sh` | Comparação de relatório ESLint com baseline explícita |
| `security/check.sh` | Gitleaks, Opengrep, OSV, Trivy e CodeQL |
| `security/lib.sh`, `record-osv-db.sh` | Verificação e registro explícito das bases OSV |
| `security/analyzers/` | Relatórios e metadados de exceções; não suprime achados |
| `security/rules/` | Regras e fixtures locais Ec |
| `metrics/coverage.sh` | Geração/avaliação de cobertura por run e inventário de fontes |
| `security/native.sh`, `security/prepare-native.sh` | Integridade e preparo explícito dos scanners nativos |
| `metrics/check.sh` | LCOV, tamanho bruto/gzip do build e p95/máximo |
| `reports/summarize.sh` | Visualização Markdown de resultados já observados |
| `check.sh`, `tests/` | Sintaxe Bash, ShellCheck obrigatório via toolbox e regressões por subprocessos |

As entradas Rust/frontend também podem ser chamadas no diretório do workspace/pacote.
Para logs, ambiente e lock, preferir `automate.sh run`.
Checks sem ferramenta/configuração retornam blocked (3); erros retornam 2;
métricas fora do limite retornam 1; aprovação retorna 0. O runner trata falhas de
qualidade como error; findings é reservado à classificação de scanners.
Prioridade agregada: error (2), blocked (3), findings (1), passed (0).

## Capacidades adicionais e preparo

- Rust: cargo-machete, cargo-deny com `config/quality/deny.toml`,
  cargo-geiger, cargo-audit com base RustSec local em `.local/security/rustsec` (ou `EC_RUSTSEC_DB`),
  cargo-llvm-cov com llvm-tools-preview já instalado no canal versionado.
  `geiger` inventaria unsafe; não impõe proibição. Coverage gera LCOV em target privado do run e aplica `config/quality/coverage.json`: 
  cobertura de linhas >=80%, separadamente por workspace.
- Frontend: `coverage` usa Vitest/provider V8 4.1.12, inclui fontes não importadas e
  aplica o mesmo gate de 80%. `lint` exige script próprio. `setup`
  executa npm ci --ignore-scripts offline, somente por seleção explícita.
  `dev` permanece interativo/contínuo e recebe o timeout do runner.
- Budget: `quality/build-budget.json` no frontend, por exemplo
  `{"directory":"dist","maximum_bytes":123456}`. O número deve ser decidido pelo
  projeto. Build precede medição e diretórios vazios/symlinks falham.
- Performance: script npm `performance` que produz amostras atuais e
  `quality/performance.json` com `report`, `p95_limit`, `maximum`, todos na mesma
  unidade definida pelo produtor. O parser usa p95 por posto mais próximo.
- LCOV: política com `format:"lcov"`, `report` e `minimum` (`lines`/`functions`,
  percentual 0–100). Relatório completo com contadores é obrigatório.
- ESLint ratchet: recebe relatório JSON e baseline `[{"file":"caminho exato",
  "rule":"regra","maximum":0}]`. Novos avisos e qualquer erro reprovam.
- Trivy/CodeQL: checks nativos padrão, rede desabilitada por bwrap, bases/bancos
  preparados explicitamente. [Versões, escopos e preparo](security/native-scanners.md).

A política de licenças/origens está em `config/quality/deny.toml`. Cobertura mínima de linhas é 80%; políticas numéricas de performance
continuam dependentes dos requisitos da aplicação. Falta de política é bloqueio explícito, nunca aprovação do check.

[Segurança](security/README.md) · [Inventário anterior e evolução](../docs/development/scripts-inventory.md)
· [Migração shell e evidências](../docs/validation/scripts-shell-20261106/report.md).
`LICENSE` preserva a licença do componente importado; não relicencia terceiros.

## Integração nativa e toolbox — 2026-11-06

[Configurações, fontes oficiais, preparo e limitações](../docs/development/verification-tools.md).
Plugins Cargo são descobertos no PATH e bins globais, independentemente do cache Ec.
Machete/deny/audit fazem parte do perfil Rust padrão; Ruff/ShellCheck do perfil scripts.
Gitleaks usa a imagem 8.24.3 do catálogo e teste de regras real; Opengrep/OSV mantêm
contratos nativos revisados porque os adapters compartilhados estão bloqueados.
Playwright/Chromium autocontido entra no E2E, além do Firefox real existente.
`bash scripts/prepare.sh tools FERRAMENTA...` e `bash scripts/prepare.sh rustsec` são
operações explícitas com rede. Nenhum scan faz preparo automaticamente.
