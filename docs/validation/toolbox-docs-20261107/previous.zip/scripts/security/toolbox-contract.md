# Responsabilidades entre Toolbox e Ec

Configuração de 2026-11-07, inspecionada sem executar scanners ou preparar imagens.
`toolbox.json` pertence ao Ec; a Toolbox compartilhada constrói imagens Docker e
prepara os dados. Não há instalação de scanners no host pelo wrapper Ec.

| Ferramenta | Imagem e dados sob responsabilidade da Toolbox | Entrada e política do Ec |
| --- | --- | --- |
| Trivy 0.76.2 | Executável, DB de vulnerabilidades e Java DB versionados por snapshot | `application`, `trivy-toolbox.yaml`, severidades completas, dependências dev, validade de 24h; adapter atual limitado a filesystem/vuln |
| OSV-Scanner 2.7.0 | Archives offline crates.io e npm no layout nativo e cache SCALIBR | Dois Cargo.lock e package-lock.json explícitos, `osv-scanner.toml`, snapshot por hash e validade de 24h |
| Grype 0.119.0 | Executável e snapshot nativo da DB | Diretório `application`, `grype.yaml`, snapshot escolhido e idade nativa máxima de 24h; todos os matches são achados |
| Gitleaks 8.24.3 | Executável, Git e regras embutidas | Fontes atuais, regras/exceções em `gitleaks.toml`; modo files explícito |
| Opengrep 1.33.1 | Executável e ambiente | Regras locais em `scripts/security/rules/opengrep`, fixtures e fontes Rust/TS/Vue; sem registry remoto |
| YARA-X 1.0.0 | Deve garantir execução e compatibilidade das regras; adapter ainda ausente | Deve fornecer regras e significado dos matches; nenhum conjunto foi inventado |
| Bandit 1.8.3 | Python e dependências fixadas do scanner dentro da imagem | Harnesses/tests Python e ferramentas locais, `bandit.yaml`, sem skips globais; adapter ignora nosec |
| Ruff / ShellCheck | Executáveis e regras incorporadas, sem DB externa | Paths explícitos, `ruff.toml`, `.shellcheckrc` e exceções locais existentes |
| Syft 1.23.1 | Executável e ambiente; não requer DB de vulnerabilidades | Diretório `application`; `sbom.json` preservado como medição, sem decisão de vulnerabilidades |
| Playwright 1.56.1 | Node, pacote Playwright, Chromium e bibliotecas da variante | Testes, `playwright.config.mjs`, build frontend e servidor interno; rede none com API simulada |

Os dados separados do executável são requisitos reais: o modo offline OSV usa
[bases locais por ecossistema](https://google.github.io/osv-scanner/usage/offline-mode/);
o Trivy distingue [DB, Java DB, checks e acesso remoto](https://trivy.dev/docs/latest/advanced/air-gap/).
O contrato efetivo das versões vem também dos adapters locais da Toolbox, lidos
nesta alteração; documentação de outra versão não amplia seu escopo.

## Preparo separado da análise

Interfaces de preparo, para execução explícita com downloads previamente autorizados:

```bash
bash scripts/prepare.sh tools trivy osv-scanner grype bandit syft
bash scripts/prepare.sh database trivy
bash scripts/prepare.sh database osv-scanner
bash scripts/prepare.sh database grype
```

`tools` delega o preparo de imagens/ambiente à Toolbox. Para Trivy, OSV e Grype,
a Toolbox também prepara/reutiliza snapshots; o lock registra a identidade real.
`database` solicita atualização explícita e grava o SHA256 retornado no campo
`database` da ferramenta em `toolbox.json`. `osv-db` permanece como alias compatível.
O campo explícito prevalece sobre o snapshot do lock. Nenhum hash foi inventado:
novos snapshots e imagens somente terão registro após preparo real. Os demais
scanners não recebem comando de atualização de DB.

`run` não atualiza bases, instala pacotes, baixa regras ou busca imagens. Usa fontes
em snapshot e rede none. Base ausente, alterada, futura ou vencida bloqueia/falha
conforme o diagnóstico da Toolbox. A idade do Trivy/OSV refere-se ao preparo no
contrato atual; Grype usa a idade nativa da base. Integridade e idade não comprovam
atualidade dos advisories upstream. Os snapshots ficam nos volumes da Toolbox e
precisam acompanhar imagens/configuração/lock em backup ou transporte.

## Seleção no runner e compatibilidade

O catálogo padrão existente continua vigente. Os checks adicionais selecionáveis
são `trivy-toolbox`, `grype`, `bandit`, `syft` e `yara-x`, na superfície security.
Sua execução segue a [política canônica](../../docs/development/task-verification.md):
não executar isoladamente para encerrar tarefas nem substituir a suíte completa
autorizada por filtros. A seleção adicional não significa cobertura pelo run padrão.

`trivy` padrão continua sendo o gate nativo **0.61.1**, com vuln/misconfig/secret e
preparo próprio documentado em [native-scanners.md](native-scanners.md).
`trivy-toolbox` usa **0.76.2**, o adapter disponível na Toolbox, com vuln e
inventário obrigatório dos três lockfiles. Ele não substitui as outras análises.
Cada versão possui configuração própria; migrar todo o gate exigirá estender e
validar o adapter para preservar a cobertura anterior. Checks de misconfiguração
não são baixados pelo adapter atual.

Gitleaks history é rejeitado antes do scan: os snapshots Ec não incluem `.git` e
não há histórico disponível nesta integração. Para habilitá-lo, será necessário
fornecer uma fonte com o histórico pretendido e validar esse contrato; Git na
imagem sozinho não fornece commits. O scan atual permanece em files.

YARA-X permanece **bloqueado**, sem omissão convertida em aprovação: faltam adapter
compartilhado e regras do consumidor. Regras compiladas, quando suportadas, também
precisarão de identidade e compatibilidade de compilador/runtime verificadas.

O Syft mantém o exit Toolbox 3 e status measurement no resultado bruto. No Ec,
o check confirma somente a geração de um SBOM válido e não vazio, preserva
`measurement:true` na classificação e não fornece `finding_count`. Esse sucesso
não aprova segurança nem indica ausência de vulnerabilidades.

Nenhuma configuração da aplicação sobe banco, API ou serviços por conta da Toolbox.
Playwright continua autocontido; testes contra sistema externo exigirão URL e rede
acessível explícitas, além do sistema previamente iniciado pelo consumidor.
