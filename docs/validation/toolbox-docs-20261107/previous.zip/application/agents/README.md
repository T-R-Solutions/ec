# Ec Agent

Workspace Rust 1.99.1/edition 2024 com cinco crates. T005 executa jobs locais Linux confiáveis, admitidos sem credenciais externas. [Operação, build, contratos e recuperação](../../docs/development/agent.md); [evidências](../../docs/validation/agent-20261105/report.md). Não há isolamento de jobs hostis nem exatamente uma vez de efeitos externos.
