> Atualização de 2026-11-07: [contrato Toolbox/Ec](../../scripts/security/toolbox-contract.md)
> registra as dez famílias de ferramentas, preparo de bases e checks adicionais
> Trivy Docker, Grype, Bandit e Syft. YARA-X permanece bloqueado. O gate Trivy nativo
> padrão é preservado; as referências nativas abaixo continuam aplicáveis a ele.

# Configurações de verificação do Ec

As configurações desta aplicação pertencem ao Ec. `.local/usage.md` descreve o
executor compartilhado, cujas integrações candidatas podem falhar no preparo real.
`toolbox.json` seleciona versões exatas e `toolbox.images.lock.json` registra imagens
locais imutáveis, receitas, checksums e versões observadas. Um lock não comprova scan.

## Execução e preparo

```bash
bash scripts/automate.sh plan
bash scripts/automate.sh run
bash scripts/automate.sh run --check ruff --check shellcheck
bash scripts/automate.sh run --check playwright
bash scripts/automate.sh run --check secrets
bash scripts/prepare.sh tools ruff shellcheck gitleaks playwright opengrep osv-scanner
bash scripts/prepare.sh osv-db
bash scripts/prepare.sh cargo-tools
bash scripts/prepare.sh deny-db
bash scripts/prepare.sh rustsec
```

O preparo compartilha o lock do runner para não alterar imagens/bases durante scans. Usa rede explicitamente; o runner não instala ferramentas, imagens ou
bases. Antes do primeiro preparo, o toolbox exige `bin/toolbox lock-base` em sua
própria raiz. Essa operação modifica a configuração compartilhada, não o Ec.
`EC_TOOLBOX_BIN` permite selecionar a CLI instalada; o padrão segue `.local/usage.md`.
Não chamar o toolbox diretamente sobre a raiz inteira do Ec para scans: a ponte
cria snapshot sem caches, histórico, credenciais locais ou runs anteriores.

Em SELinux enforcing, a ponte habilita `TOOLBOX_SELINUX_LABEL=private`: fonte somente
leitura e saída dedicada recebem rótulo `Z`. Isso exige a correção do toolbox
registrada no relatório desta alteração; não desabilita SELinux nem usa privileged.
Os snapshots e outputs podem ser relabelados; o checkout original não é montado.
O Docker daemon continua sendo uma capacidade privilegiada do operador.

## Ferramentas e fontes oficiais consultadas em 2026-11-06

| Solução | Configuração e contrato Ec | Fonte oficial |
| --- | --- | --- |
| Cargo/rustup | Canal de cada workspace, cache separado e plugins globais no PATH e fallback local em `.local/tools/bin`; registra versão/hash do plugin efetivamente chamado | [Subcomandos](https://doc.rust-lang.org/cargo/reference/external-tools.html), [Cargo home](https://doc.rust-lang.org/cargo/guide/cargo-home.html) |
| rustfmt/Clippy/test | Sem auto-fix; todos os targets/features no Clippy; lockfile e execução offline | [rustfmt](https://github.com/rust-lang/rustfmt), [Clippy](https://doc.rust-lang.org/clippy/usage.html), [cargo test](https://doc.rust-lang.org/cargo/commands/cargo-test.html) |
| cargo-machete | Workspace atual; sem lista de dependências ignoradas | [CLI e metadata](https://github.com/est31/cargo-machete) |
| cargo-deny | `config/quality/deny.toml` explícito: origens desconhecidas negadas, licenças permitidas enumeradas, advisories sem ignores de advisories, yanked negado, base com até sete dias; versões duplicadas geram aviso | [Configuração](https://embarkstudios.github.io/cargo-deny/checks/cfg.html), [advisories](https://embarkstudios.github.io/cargo-deny/checks/advisories/cfg.html), [check](https://embarkstudios.github.io/cargo-deny/cli/check.html) |
| cargo-audit | `config/quality/audit.toml` copiado para diretório dedicado `.cargo`; lockfile explícito, no-fetch, warnings negados, JSON; não herda configuração pessoal de ignores | [Config](https://github.com/rustsec/rustsec/blob/main/cargo-audit/audit.toml.example), [uso](https://github.com/rustsec/rustsec/blob/main/cargo-audit/README.md) |
| cargo-geiger | Inventário unsafe, locked/offline; medição não equivale a vulnerabilidade ou proibição de unsafe | [Uso](https://github.com/geiger-rs/cargo-geiger) |
| cargo-llvm-cov | LCOV por run, target privado e gate de linhas >=80% por workspace; precisa llvm-tools-preview do canal | [CLI](https://github.com/taiki-e/cargo-llvm-cov) |
| Ruff 0.11.13 | `ruff.toml`: erros de sintaxe/referências e regras S; sem fix/cache; S101 dispensada somente em testes porque assert é oráculo | [Configuração](https://docs.astral.sh/ruff/configuration/), [regras](https://docs.astral.sh/ruff/rules/) |
| ShellCheck 0.11.0 | `.shellcheckrc`, lista explícita de scripts, JSON; tarefa obrigatória mesmo sem binário nativo | [Manual por versão](https://github.com/koalaman/shellcheck/blob/v0.11.0/shellcheck.1.md) |
| Gitleaks 8.24.3 | Defaults em `scripts/security/rules/gitleaks.toml`, arquivos atuais, redaction; snapshot sem ignore file, exceção estrutural de hashes validada por teste com credencial sintética no mesmo arquivo e preflight rejeita marcadores inline de supressão | [Config e CLI por versão](https://github.com/gitleaks/gitleaks/blob/v8.24.3/README.md) |
| Opengrep | Adapter 1.33.1 no toolbox: testes de regras e inventário estrito; versão antiga 1.31.0 preservada | [Projeto/CLI](https://github.com/opengrep/opengrep), [fonte por versão](https://github.com/opengrep/opengrep/blob/v1.33.1/src/osemgrep/cli_scan/Scan_CLI.ml) |
| OSV | Adapter 2.7.0 no toolbox: três locks e bases crates.io/npm offline; snapshot imutável expira em 24h | [Config](https://google.github.io/osv-scanner/configuration/), [offline por versão](https://github.com/google/osv-scanner/blob/v2.7.0/docs/offline-mode.md) |
| Trivy | `config/quality/trivy.yaml`: vuln, misconfig e secret, todas as severidades, sem ignorar unfixed; parser conta os três tipos; CLI nativa 0.61.1, DB schema 2 íntegra/fresca e checks embutidos; rede desabilitada por bwrap | [Arquivo de configuração 0.61](https://trivy.dev/v0.61/docs/references/configuration/config-file/) |
| CodeQL | `codeql.qls`/`codeql-rust.qls`: security-extended para frontend/Server/Agent; CLI 2.27.3, packs fixos e bancos vinculados por hash; sem preparo no scan | [Suites](https://docs.github.com/en/code-security/tutorials/customize-code-scanning/create-query-suites) |
| Playwright 1.56.1 | `playwright.config.mjs`: Chromium, rede none, servidor estático interno, sem only/retry, zero skips/flaky, JSON obrigatório, sem traces/screenshots/estado de sessão | [Configuração](https://playwright.dev/docs/test-configuration), [Docker](https://playwright.dev/docs/docker) |
| Docker/Debian | Imagens por digest, readonly/UID/cap-drop/no-new-privileges; snapshot APT compatível com a base | [SELinux/mounts](https://docs.docker.com/engine/storage/bind-mounts/), [Snapshots](https://snapshot.debian.org/) |

Geiger, coverage, Trivy e CodeQL são padrão desde 2026-11-07. Cobertura de linhas
exige >=80% por componente, conforme pedido explícito do usuário; frontend usa
Vitest/provider V8 4.1.12 e inventário TS/Vue. ESLint, performance e build-budget
continuam adicionais; performance exige um produtor real de amostras.
[Contrato nativo, versões, preparo e fontes](../../scripts/security/native-scanners.md).
A lista de licenças é uma política técnica inicial conservadora, não parecer jurídico.
Ruff tem exceções S603/S607 por ocorrência, com justificativa e triagem dos 102 alertas em `docs/validation/tooling-remediation-20261106/ruff-triage.json`. SQL usa variáveis psql quoted; HTTP do harness tem destino fixo e não segue redirects. A exceção Gitleaks exige o caminho exato do perfil e linha de mapa de recurso para SHA256; o teste real garante que uma credencial no mesmo arquivo continue detectada.

## Segurança, falhas e limites

O perfil Rust padrão acrescenta machete/deny/audit; scripts acrescenta Ruff e
ShellCheck. Segurança mantém Gitleaks, teste de regras, SAST e OSV obrigatórios.
Opengrep/OSV têm adapters versionados, relatórios estritos e execução sem rede.
Trivy/CodeQL nativos exigem bwrap e pré-requisitos locais. Ausência de imagem ou pré-requisito é exit 3; erro/relatório inválido
é exit 2; achado é exit 1; somente execução completa e sem achados é exit 0.

OSV: 24h desde o registro local é validade operacional, não prova de atualização ou
autenticidade upstream. RustSec: até sete dias desde o último commit, sem permitir
base futura. Hashes, frescor, autenticidade e eficácia são propriedades diferentes.
Atualizar as bases separadamente e rever sua procedência antes de um aceite.

O Playwright verifica comportamento do frontend com API simulada; não comprova RBAC
no backend. O harness Firefox com Server/Agent/PostgreSQL reais continua no E2E padrão.
Nenhum scanner ou conjunto destes checks certifica segurança enterprise, isolamento
para código hostil, conformidade normativa ou ausência completa de vulnerabilidades.


## Preparo local dos plugins e integridade

`cargo-tools` baixa somente os artefatos Linux x86_64 fixados em
`config/quality/cargo-tools.json`, confere SHA-256 publicado na release oficial e
instala em `.local/tools/bin`. Não altera a instalação global. O PATH do operador
continua prioritário; versão e hash efetivos são registrados. O preparo não é
chamado pelo runner. Cargo Deny 0.20.2 usa `--config` antes de `check`; `--offline`
impede fetch de bases. `deny-db` prepara o layout RustSec específico do plugin.
Para completar caches de todas as plataformas, execute `cargo fetch --locked`
explicitamente em cada workspace com o CARGO_HOME do Ec antes do scan offline.

ShellCheck 0.10.0 continua preservado no catálogo compartilhado. Ec seleciona
0.11.0, cujo asset oficial possui digest verificável. Opengrep é extraído no build,
sem precisar executar arquivos no tmpfs do container. Configuração e métricas
ficam em diretórios temporários; fontes são readonly, rede none e UID do operador.
