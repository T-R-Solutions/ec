# Verificação opcional após pedido de commit

Esta é a política canônica do Ec para SDD e skills. Scripts de verificação não são
acionados automaticamente durante implementação, revisão ou encerramento de tarefas.
Inspecione as alterações e registre resultados e lacunas; a execução depende do
fluxo abaixo, somente após pedido explícito de commit.

## Pergunta obrigatória

Após o pedido de commit, apresente exatamente:

> Deseja executar o script automate.sh (que roda todos os outros scripts)?

Ofereça somente duas respostas: `sim` e `não`. Aguarde a escolha; silêncio ou opção
pré-selecionada não constituem resposta. Faça a pergunta para o pedido de commit
atual, sem repetir a escolha para cada commit do mesmo pedido.

- `não`: crie normalmente os commits solicitados, sem executar scripts de verificação.
  Registre que a suíte não foi executada por escolha do usuário; isso não é erro nem
  impedimento para o commit e não equivale a aceite técnico das features.
- `sim`: execute, da raiz, a suíte completa pela única entrada abaixo. Só crie os
  commits se todos os scripts da suíte terminarem sem erros. Qualquer erro, ferramenta
  ausente, interrupção ou execução incompleta bloqueia os commits. Corrija problemas
  dentro do escopo autorizado e execute novamente a suíte completa antes de criar
  commits; se não puder resolvê-los, relate o bloqueio sem criar commits.

```bash
bash scripts/automate.sh run
```

Não usar `--surface` ou `--check` nesse fluxo, nem substituir o runner por scripts
avulsos, validadores SDD ou comandos de teste indicados em skills, templates ou guias.
Exemplos de comandos nessas fontes descrevem interfaces; não autorizam acionamento
fora deste fluxo. A regra trata de scripts de verificação, sem impedir leitura,
inspeção manual, edição de arquivos ou operações Git solicitadas.

A execução cobre todas as superfícies padrão configuradas no runner. Opções extras
não incluídas no catálogo padrão não passam a ser executadas por esta instrução.
O runner resolve a raiz pela própria localização; para caminhos com espaços, use
`bash "/caminho com espaços/ec/scripts/automate.sh" run`. Não depende de hooks e não
instala hooks. Esta política orienta o agente; não altera a CLI do runner.

## Suíte e critérios

| Superfície | Seleção e verificações reais |
| --- | --- |
| Documentação/governança/skills | `docs`: auditor comum, auditor `--require-installed`, instalador `--check`, SDD e unittest de governança. Governança roda também em todas as demais seleções. Revisar links/prosa e critérios semanticamente. |
| Automação | `scripts`: testes de contratos do runner, incluindo falha, ferramenta ausente, timeout, logs e caminhos. Um teste usa listener loopback efêmero e exige permissão de sockets locais. Bash valida sintaxe; testes Python exercitam contratos shell. Ruff e ShellCheck são tarefas obrigatórias via toolbox; ausência de imagem bloqueia. |
| Rust Server | `server`: workspace `application/server/backend`, toolchain do próprio rust-toolchain.toml, fmt check, Clippy workspace/all-targets/all-features com warnings negados, test workspace locked/offline; machete, deny (origens/licenças/advisories), audit e geiger offline; cobertura de linhas >=80% com target privado do run. |
| Rust Agent | `agent`: mesmos checks em `application/agents`, target separado. |
| Frontend Vue/TS/Pinia | `frontend`: npm run typecheck (vue-tsc, inclui .vue), test (Vitest) e build (Vite), package-lock existente. Cobertura V8/LCOV de linhas >=80%, incluindo fontes TS/Vue sem testes. Sem ESLint ou budget artificial. |
| Segurança | `security`: Gitleaks para segredos; Opengrep para testes de regras e SAST Rust/TypeScript/Vue; OSV para vulnerabilidades dos três lockfiles reais; Trivy nativo e CodeQL para Server/Agent/frontend, com bases/bancos vinculados e rede desabilitada. [Contrato, pré-requisitos e limites](../../scripts/security/README.md). Mudanças em autorização/isolamento exigem também seus testes negativos e revisão da feature. |
| Integração | `integration`: inclui checks Rust e compila ambos com test-failpoints imediatamente antes dos harnesses; publication_http, orchestration_http, agent_http sequenciais. |
| Ponta a ponta | `e2e`: checks Rust/frontend, builds de failpoints e frontend_firefox com banco/Server/Agent/browser reais. Não dispensa cenários adicionais da feature. |

A suíte inteira deve passar na opção `sim`; resultado parcial não libera commits.
Critérios de aceite de features continuam distintos da autorização para commit.

## Pré-requisitos permanentes

Bash 5+, jq 1.6+, GNU coreutils, util-linux e Python 3.11+ para testes/harnesses externos a scripts; Linux e espaço gravável em `.local/`.
Rustup com o canal já instalado dos dois rust-toolchain.toml (observado 1.99.1),
componentes rustfmt e clippy e linker do host; caches Cargo preparados separadamente
conforme [publicação](publication.md) e [Agent](agent.md). O runner usa `rustup run`,
`--locked --offline`, `RUSTUP_AUTO_INSTALL=0` e nunca instala toolchain/componentes.
`CARGO_HOME` explícito é respeitado; padrão `.local/build/ec-cargo-home`; a descoberta dos plugins globais mantém PATH e acrescenta os bins globais independentemente desse cache.
Targets são `.local/build/ec-server-clean` e `.local/build/ec-agent-target`, conforme
os harnesses reais. Nenhum build de aplicação é executado na raiz.

Frontend: Node >=22.12 e npm; dependências locais preparadas explicitamente com
`npm --prefix application/server/frontend ci --ignore-scripts`. Verificar o engine
também ao atualizar dependências. Nenhuma biblioteca Vue deve ser instalada globalmente.
O runner usa npm offline, não npx/bunx nem instalação implícita. Build gera dist e
testes podem gerar caches locais; checks não executam formatadores de correção.

Segurança: Gitleaks 8.24.3 em imagem preparada pelo toolbox, Opengrep 1.33.1 e OSV-Scanner 2.7.0 em imagens do toolbox;
OSV exige snapshot crates.io/npm vinculado por hash em toolbox.json. Instalação, preparo explícito,
escopos, licença e fontes oficiais estão no [guia de segurança](../../scripts/security/README.md).
Ruff/ShellCheck/Gitleaks/Playwright/Opengrep/OSV usam snapshots e relatórios pelo toolbox. [Configurações e preparo](verification-tools.md). Nenhum scan instala ferramentas, busca regras em registry, atualiza bases ou envia
dependências pela rede. CLI/base ausente bloqueia; relatório incompleto ou base
alterada falha. A falta de configuração não torna a ferramenta inaplicável.
O snapshot Gitleaks mantém o escopo descrito no guia; SAST usa fontes de aplicação,
e OSV só os lockfiles explícitos. Não há análise de histórico Git nem certificação de
licenças de dependências (cargo-deny aplica a política técnica); os scanners não certificam autorização, isolamento ou
segurança completa. Testes de regras com o motor real permanecem obrigatórios.
Trivy/CodeQL exigem bwrap, versões e preparo explícito conforme
[contrato nativo](../../scripts/security/native-scanners.md). Geiger inventaria unsafe
sem proibição geral; cargo-llvm-cov e llvm-tools-preview precisam estar preparados.
O provider V8 4.1.12 consta do lockfile, mas deve ser instalado pelo preparo npm explícito.

Integração/E2E: Docker com daemon autorizado, Git, container dedicado
`ec-publication-test` em 127.0.0.1:55439 com PostgreSQL 18 e `/usr/bin/firefox` no E2E.
Preparar explicitamente conforme [publicação](publication.md) e [frontend](frontend.md).
O runner verifica daemon, container/porta/readiness e portas livres 58139, 5173,
58282 para os harnesses reais; Playwright é autocontido e não exige esse preflight. O runner não cria container PostgreSQL, baixa imagem, instala browser ou altera o host.
Banco UUID é descartável e removido pelo harness. Nunca rodar harnesses avulsos em
paralelo com o runner; o lock só coordena executores desta entrada.

## Resultado e evidências

Runs em `.local/automation/runs/run-*/`: plano, inputs por hash antes/depois,
results.json e stdout/stderr brutos por comando, em arquivos 0600/diretórios privados.
Não existe limpeza automática de runs; revisar dados sensíveis antes de compartilhar.
O E2E guarda imagens/resultados no run e não sobrescreve observações anteriores.
HOME/PATH confiáveis do operador são usados para ferramentas locais; tokens e
NODE_OPTIONS não são herdados. O supervisor não é sandbox de segurança.

Exit agregado: 0 checks selecionados aprovados; 1 achados de segurança; 2 falha de
comando/configuração/timeout/log acima de 8MiB ou inputs alterados; 3 ferramenta ou
pré-requisito ausente/dependência bloqueada. Prioridade 2 > 3 > 1 > 0. Cada tarefa
preserva exit bruto, motivo e diagnóstico. Não interpreta palavras em stdout como
aprovação. Limite por comando 900s; cancelamento encerra grupo cooperante e preserva
logs parciais. Processos que escapem com setsid exigem contenção externa.

O SDD comum verifica evidência e rejeita drift, mas não exige aprovação agregada.
Aceite de features exige os critérios e evidências atuais definidos no SDD; um commit
criado com `não` não altera esse estado. Não executar validadores extras fora do
runner para encerrar tarefas ou liberar commits. Quando faltar evidência de um
critério, mantê-lo não verificado e registrar a lacuna, sem renovar hashes de
observações antigas, mover features ou enfraquecer critérios.
Na rota local sem feature, registrar objetivo/inputs/método/resultado/limites no
artefato de revisão já usado. Templates e skills remetem a esta política.
