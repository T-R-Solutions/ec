# Convergência T004 — fila e tentativas

| Critério | Estado | Observação |
| --- | --- | --- |
| AC-01 / T001 | UNVERIFIED | Parser preservado, trabalhos locais admitidos. Referências de segredos pendentes; não há detector de segredos arbitrários em scripts. |
| AC-02 / T002 | APPROVED | Regressão HTTP/PostgreSQL real de publicação, conflitos, replay e reinícios antes/depois de commit. |
| AC-03 / T003 | APPROVED | Regressão de sessões/grants e novas negações em submissão/cancelamento/contratos Agent sem efeitos persistidos. |
| AC-04 / T004 | APPROVED | PostgreSQL 18.4: revisão/hash/commit fixados, replay, disputa observada em conexões independentes por trabalho/slot, heartbeat/lease/fence/sessão, retry limitado, recibos, corridas cancelamento/conclusão nas duas ordens, recuperação/reinícios reais. |
| AC-05 / T005 | UNVERIFIED | Agent real, execução, logs e artefatos pendentes. Cliente do harness não é Agent implementado. |
| AC-06 / T006 | UNVERIFIED | Interface e evidência no navegador pendentes. |
| AC-07 / T007 | UNVERIFIED | Contribuição parcial T004: publicação → submissão → resultado Server persistido e consultável. Não demonstra execução Agent/artefato, frontend ou jornada completa. |

REQ-04 → D-04/R-04 → T004 → ec-server-orchestration/src/lib.rs, migration 002, composição service.rs → orchestration_http.py e oráculos SQL → docs/validation/orchestration-20261105/http-postgres.log → AC-04. REQ-02/03 → D-02/03 e R-02/03 → T002/T003 → regressão publication_http.py. Caminhos/hashes e comandos em evidence.json; seleção, pontes e contribuições em skills.json. Evidência anterior da feature preservada no previous.zip desta fatia; registros originais de publicação continuam intactos.

Decisão: serialização transacional PostgreSQL global, com índices únicos parciais para slot/run; não promete escala ou justiça. Relógio capturado depois da espera; teste pausa worker periódico somente no build de testes e comprova expiração com tentativa SQL ainda assigned. Deadlines encurtados por SQL administrativo atravessam tempo real do banco. Falhas de processo/HTTP foram exercitadas; falha de disco, host/failover PostgreSQL, isolamento e efeitos exactly-once externos não foram demonstrados. Recibos/histórico e listagens sem retenção/paginação nesta capacidade inicial. Exposição apenas loopback; TLS remoto/IdP fora de escopo.

Relatório reproduzível: docs/development/orchestration.md e docs/validation/orchestration-20261105/report.md. O aceite agregado deve continuar falhando para AC-01/05/06/07; checks estruturais não os promovem. Retomar T001 por referências de segredos; T005 pelo contrato HTTP autenticado de sessão/reserva/reconexão, checkout e execução reais; depois T006/T007. Não há commit, tag ou publicação nesta entrega.
