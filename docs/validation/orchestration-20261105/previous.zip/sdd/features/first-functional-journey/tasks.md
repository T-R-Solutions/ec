# Tarefas

- [ ] T001 [REQ-01, AC-01, D-01, R-01]: Parser, modelo, CLI e nove testes locais implementados; Referências projeto/repository/commit resolvidas contra cadastro PostgreSQL admitido de Git real por CLI. Campos de segredo continuam rejeitados; suporte de resolução de segredos pendente e AC-01 sem aceite.
- [x] T002 [REQ-02, AC-02, D-02, R-02]: Migration 001, publicação, recibos e recuperação PostgreSQL/HTTP demonstrados no harness publication_http.py.
- [x] T003 [REQ-03, AC-03, D-03, R-03]: Sessões opacas e papéis por projeto na API HTTP v1 demonstrados, inclusive negações sem efeitos.
- [ ] T004 [REQ-04, AC-04, AC-07, D-04, R-04]: fila, leases, fencing, reconciliação e testes concorrentes reais.
- [ ] T005 [REQ-05, AC-05, D-05, R-05]: Agent real, checkout, processos, logs, artefatos e recuperação.
- [ ] T006 [REQ-06, AC-06, D-06, R-06]: UI real, round-trip, navegação e evidência no navegador.
- [ ] T007 [REQ-04, AC-07, D-04, R-04]: harness ponta a ponta isolado com repositório controlado e todas as rejeições da spec.

## Backlog A–E posterior ao marco

A: consolidar fundamentos, ambientes reproduzíveis e decisões ainda pendentes; B: concluir núcleo seguro e o marco desta feature. C: completar edição e gestão, hierarquia, usuários/equipes e políticas. D: ampliar DAGs, triggers, templates, testes e entregas. E: plugins, operação e escala mediante medições e controles demonstrados. Nenhuma fase é declarada concluída.
