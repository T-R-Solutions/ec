# Convergência da publicação persistente

| Critério | Estado | Observação |
| --- | --- | --- |
| AC-01 / T001 | UNVERIFIED | Parser preservado; referências reais admitidas/resolvidas. Segredos por referência continuam pendentes e rejeitados pelo schema. |
| AC-02 / T002 | APPROVED | PostgreSQL 18.4 real, migrations, bytes/hash, imutabilidade, conflito, corrida com locks observados, replay, falha/queda antes de commit e conexão fechada após commit; reinícios reais. |
| AC-03 / T003 | APPROVED | HTTP real, token aleatório verificável, expiração/revogação, viewer e projeto invisível; snapshots SQL comprovam ausência de efeitos de publicação negados. Escopo loopback e provisão local. |
| AC-04 a AC-07 | UNVERIFIED | Fila, Agent, scripts, frontend e jornada completa pendentes. |

REQ-02 → D-02/R-02 → T002 → publication.rs/migration 001 → http-postgres.log; REQ-03 → D-03/R-03 → T003 → access/service.rs → mesmo harness com oráculos SQL independentes. Traceabilidade e hashes atuais em evidence.json; skills em skills.json. Evidência anterior preservada em previous.zip, sem renovar seus hashes para reutilizar aprovação.

Limites: teste local de queda de processo Server, não falha de disco/host PostgreSQL. Falha antes de commit usa rollback por retorno e também exit(86) após inserts. Após commit, writer HTTP é fechado sem resposta e o cliente observa desconexão; não simula falha de commit do banco. Referência de repositório é snapshot admitido de Git real, sem garantia de disponibilidade futura. Credenciais externas e detecção de segredo arbitrário em script não implementadas. Nenhum aceite da jornada completa.

Retomar T001 pelo schema/resolução autorizada de referências a segredos; depois T004/T005/T006/T007 nos limites já especificados. Comandos e preparação em docs/development/publication.md.
