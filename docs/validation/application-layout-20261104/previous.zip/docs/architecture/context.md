# Contexto arquitetural do Ec

## Alvo e implementação observada

Server Rust: identidade/RBAC, YAML, projetos/pipelines, API, PostgreSQL, fila/scheduler e integração de Agents.
Agent Rust: sessão, capacidades/slots, checkout, execução, isolamento, saída e recuperação.
Frontend Vue 3/TypeScript/Pinia: administração e operação, três modos de configuração e confirmação pelo backend.
São limites planejados; não existem manifests de aplicação ou binários de produto neste checkout.

A pesquisa e o protótipo Rust em `reverse_engineering_teamcity/` não são implementação do Ec Server/Agent.
HTTP versionado/PostgreSQL são os contratos vigentes. gRPC/Protobuf e SQLite no Agent estão em [proposta](../ec-arquitetura-comunicacao-e-validacao.md).

## Organização física inicial

A [ADR-002](../decisions/ADR-002-application-layout.md) e o [mapa da aplicação](application-layout.md) registram a estrutura documental criada em `agents/crates/`, `server/backend/crates/` e `server/frontend/`. Cada domínio tem `src/` e `tests/`; composição e regras de dependência estão documentadas. A [política de testes](../development/testing.md) distingue unitários, integração e ponta a ponta. Pinia foi explicitada no pedido desta estrutura. A existência dos diretórios não significa código implementado.

## Próximas decisões

Fixar toolchains e configurar os workspaces planejados quando iniciar código; especificar schemas YAML e revisão publicada; definir contratos job/attempt/lease; avaliar transporte e durabilidade local por ADR e ensaios.
As fases A–E das [normas de produto](../EC-REGRAS-DE-DESIGN-E-PRODUTO.md) organizam fundamentos, núcleo seguro, paridade/gestão, expansão e ecossistema/escala. Não importar as fases F0 do Ox.
