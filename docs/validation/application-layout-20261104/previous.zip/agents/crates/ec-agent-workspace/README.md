# ec-agent-workspace — Preparação do workspace

Estado: estrutura documental criada; código e testes de produto ainda não implementados.

## Responsabilidade e limite

Checkout em revisão fixa, preparação de entradas e ciclo de vida dos diretórios de trabalho; fronteira para cache de build quando especificado.

Não agenda tentativas, inicia processos de job ou trata cache como artefato imutável.

Derivação: [norma de produto](../../../docs/EC-REGRAS-DE-DESIGN-E-PRODUTO.md), context.md; norma de produto §§18, 22; [contexto arquitetural](../../../docs/architecture/context.md).

## Dependências e interface pública planejadas

Dependências diretas permitidas entre crates Ec: **nenhum crate Ec**. Bibliotecas externas ainda não foram escolhidas. Nunca depender do crate de composição.

Pedido de preparação por revisão, resultado com identidade das entradas e operação de limpeza sob política. Nomes de tipos, assinaturas, schema e serialização permanecem pendentes. Expor contratos mínimos pela raiz da biblioteca; módulos de implementação permanecem privados. Adaptadores de I/O ficam internos ao domínio proprietário, implementam portas desse domínio e são conectados pela composição.

## Organização e testes

- `src/`: código futuro e testes unitários próximos ao código, sob `#[cfg(test)]`.
- `tests/`: integração futura pela interface pública; testes com fronteira de processo explícita podem ter escopo ponta a ponta do componente.
- Cenários de integração entre crates do mesmo monólito pertencem ao `tests/` do crate de composição; entre Server e Agent pertencem a `tests/` na raiz do repositório.

Cenários a especificar e implementar: Revisão inexistente, entrada incompleta e falha de limpeza devem ter resultados explícitos. Ainda não há testes executáveis ou cobertura.

## Referências e manutenção

[Organização da aplicação](../../../docs/architecture/application-layout.md) · [Política de testes](../../../docs/development/testing.md) · [Autoridades](../../../docs/constitution.md).

Atualize este README quando mudar a responsabilidade, a interface pública, uma dependência permitida ou o modo de verificar este módulo. Comandos de produto só serão incluídos após implementação e execução verificadas.
