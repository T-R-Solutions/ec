# configuration — Edição e publicação de configuração

Estado: estrutura documental criada; código e testes de produto ainda não implementados.

## Responsabilidade e limite

Modelo de rascunho, projeções Visual/Formulário/YAML, diagnósticos, diff, conflito e estado de publicação.

Os modos compartilham semântica; a UI não substitui validação e autorização do backend.

Derivação: [norma de produto](../../../../../docs/EC-REGRAS-DE-DESIGN-E-PRODUTO.md), §§14–16; [norma de interface](../../../../../docs/EC-REGRAS-CRIACAO-DE-TELAS-E-IMAGENS.md).

## Dependências e interface pública planejadas

Pode consumir **shared**, sem importar `app/` ou implementações privadas de outros domínios. Dependências externas adicionais ainda não foram escolhidas.

Interface de edição configurável por descritores, preservação de campos e resultados confirmados pelo backend. A entrada pública futura será `src/index.ts`, com exportações explícitas e mínimas, sem expor stores e clientes internos por conveniência. Nenhum arquivo TypeScript é criado nesta etapa.

## Organização e testes

`src/` receberá páginas, componentes, composables, stores Pinia e acesso à API pertencentes ao domínio, conforme a necessidade. Testes unitários ficarão junto desses arquivos. `tests/` receberá integração entre partes do domínio pela interface pública; integração entre domínios e jornadas de interface ficam em `server/frontend/tests/`.

Cenários a especificar e implementar: Round-trip semântico, YAML inválido, campos desconhecidos e conflito de revisão. Casos com API simulada serão identificados como testes de interface, sem alegar ponta a ponta da plataforma.

## Referências e manutenção

[Organização da aplicação](../../../../../docs/architecture/application-layout.md) · [Política de testes](../../../../../docs/development/testing.md) · [Autoridades](../../../../../docs/constitution.md).

Atualize este README quando mudar a responsabilidade, a interface pública, uma dependência permitida ou o modo de verificar este módulo. Comandos de produto só serão incluídos após implementação e execução verificadas.
