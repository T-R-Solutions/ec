# Ec Server

O Server reúne o monólito modular Rust do control plane e a interface Vue 3 + TypeScript + Pinia. Estado atual: estrutura documental criada; nenhum backend ou frontend de produto executável.

- [Backend](backend/README.md): domínios, composição, API HTTP versionada e estado operacional planejado em PostgreSQL.
- [Frontend](frontend/README.md): administração, autoria e operação organizadas por domínios.

A organização não define serviços independentes por crate nem decide como os arquivos do frontend serão distribuídos. Configuração desejada continua em YAML canônico; sessões, fila, leases e resultados são estado operacional.

Integração interna pertence ao `tests/` do componente responsável. Jornadas que atravessam backend, frontend e/ou Agent ficam nos [testes da plataforma](../tests/README.md). Ainda não há manifests ou comandos de execução.

[Organização](../docs/architecture/application-layout.md) · [Política de testes](../docs/development/testing.md) · [Autoridades](../docs/constitution.md) · [Entrada do projeto](../README.md).
