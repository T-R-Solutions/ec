# ec-server-orchestration — Execuções e infraestrutura

Estado: estrutura documental criada; código e testes de produto ainda não implementados.

## Responsabilidade e limite

Submissão, jobs/tentativas, fila, elegibilidade, reservas, leases/fencing, retry, cancelamento e estado operacional de agentes/pools.

Não executa processos de workload, não publica YAML e não promete efeitos externos exatamente uma vez.

Derivação: [norma de produto](../../../../docs/EC-REGRAS-DE-DESIGN-E-PRODUTO.md), §§19, 20, 22; [contexto arquitetural](../../../../docs/architecture/context.md).

## Dependências e interface pública planejadas

Dependências diretas permitidas entre crates Ec: **ec-server-access, ec-server-configuration, ec-server-projects**. Bibliotecas externas ainda não foram escolhidas. Nunca depender do crate de composição.

Submeter execução com revisão fixa, consultar alocação, coordenar sessão de Agent e receber transições de tentativa. Nomes de tipos, assinaturas, schema e serialização permanecem pendentes. Expor contratos mínimos pela raiz da biblioteca; módulos de implementação permanecem privados. Adaptadores de I/O ficam internos ao domínio proprietário, implementam portas desse domínio e são conectados pela composição.

## Organização e testes

- `src/`: código futuro e testes unitários próximos ao código, sob `#[cfg(test)]`.
- `tests/`: integração futura pela interface pública; testes com fronteira de processo explícita podem ter escopo ponta a ponta do componente.
- Cenários de integração entre crates do mesmo monólito pertencem ao `tests/` do crate de composição; entre Server e Agent pertencem a `tests/` na raiz do repositório.

Cenários a especificar e implementar: Expiração de lease, desconexão, retry e cancelamento exigem estados e fronteiras transacionais explícitos antes de implementar. Ainda não há testes executáveis ou cobertura.

## Referências e manutenção

[Organização da aplicação](../../../../docs/architecture/application-layout.md) · [Política de testes](../../../../docs/development/testing.md) · [Autoridades](../../../../docs/constitution.md).

Atualize este README quando mudar a responsabilidade, a interface pública, uma dependência permitida ou o modo de verificar este módulo. Comandos de produto só serão incluídos após implementação e execução verificadas.
