# ec-server-delivery — Ambientes e entregas

Estado: estrutura documental criada; código e testes de produto ainda não implementados.

## Responsabilidade e limite

Recursos de ambiente e políticas, solicitações de promoção, aprovações vinculadas a revisão/artefato/destino e histórico de deployment.

Não interpreta um clique como aprovação suficiente nem promete rollback sem estratégia demonstrada.

Derivação: [norma de produto](../../../../docs/EC-REGRAS-DE-DESIGN-E-PRODUTO.md), §21; [contexto arquitetural](../../../../docs/architecture/context.md).

## Dependências e interface pública planejadas

Dependências diretas permitidas entre crates Ec: **ec-server-access, ec-server-configuration, ec-server-orchestration, ec-server-results**. Bibliotecas externas ainda não foram escolhidas. Nunca depender do crate de composição.

Validadores de recursos de ambiente, solicitar promoção, decidir aprovação e consultar progresso da entrega. Nomes de tipos, assinaturas, schema e serialização permanecem pendentes. Expor contratos mínimos pela raiz da biblioteca; módulos de implementação permanecem privados. Adaptadores de I/O ficam internos ao domínio proprietário, implementam portas desse domínio e são conectados pela composição.

## Organização e testes

- `src/`: código futuro e testes unitários próximos ao código, sob `#[cfg(test)]`.
- `tests/`: integração futura pela interface pública; testes com fronteira de processo explícita podem ter escopo ponta a ponta do componente.
- Cenários de integração entre crates do mesmo monólito pertencem ao `tests/` do crate de composição; entre Server e Agent pertencem a `tests/` na raiz do repositório.

Cenários a especificar e implementar: Mudança de destino ou artefato deve invalidar pressupostos da aprovação; rejeitar promoção sem condições satisfeitas. Ainda não há testes executáveis ou cobertura.

## Referências e manutenção

[Organização da aplicação](../../../../docs/architecture/application-layout.md) · [Política de testes](../../../../docs/development/testing.md) · [Autoridades](../../../../docs/constitution.md).

Atualize este README quando mudar a responsabilidade, a interface pública, uma dependência permitida ou o modo de verificar este módulo. Comandos de produto só serão incluídos após implementação e execução verificadas.
