# ec-server-operations — Operação e auditoria

Estado: estrutura documental criada; código e testes de produto ainda não implementados.

## Responsabilidade e limite

Registro de auditoria, diagnósticos e consultas de saúde da instância; recursos de configuração global e políticas operacionais.

Não modifica dados internos de outros domínios para contornar suas interfaces; retenção de resultados continua em results.

Derivação: [norma de produto](../../../../docs/EC-REGRAS-DE-DESIGN-E-PRODUTO.md), §§3, 22, 23; [contexto arquitetural](../../../../docs/architecture/context.md).

## Dependências e interface pública planejadas

Dependências diretas permitidas entre crates Ec: **nenhum crate Ec**. Bibliotecas externas ainda não foram escolhidas. Nunca depender do crate de composição.

Registro de fatos auditáveis, consultas de diagnóstico e validadores de recursos administrativos; portas para fontes de saúde. Nomes de tipos, assinaturas, schema e serialização permanecem pendentes. Expor contratos mínimos pela raiz da biblioteca; módulos de implementação permanecem privados. Adaptadores de I/O ficam internos ao domínio proprietário, implementam portas desse domínio e são conectados pela composição.

## Organização e testes

- `src/`: código futuro e testes unitários próximos ao código, sob `#[cfg(test)]`.
- `tests/`: integração futura pela interface pública; testes com fronteira de processo explícita podem ter escopo ponta a ponta do componente.
- Cenários de integração entre crates do mesmo monólito pertencem ao `tests/` do crate de composição; entre Server e Agent pertencem a `tests/` na raiz do repositório.

Cenários a especificar e implementar: Falha parcial e estado desconhecido não podem virar sucesso; auditoria não deve expor segredos. Ainda não há testes executáveis ou cobertura.

## Referências e manutenção

[Organização da aplicação](../../../../docs/architecture/application-layout.md) · [Política de testes](../../../../docs/development/testing.md) · [Autoridades](../../../../docs/constitution.md).

Atualize este README quando mudar a responsabilidade, a interface pública, uma dependência permitida ou o modo de verificar este módulo. Comandos de produto só serão incluídos após implementação e execução verificadas.
