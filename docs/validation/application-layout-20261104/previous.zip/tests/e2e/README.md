# Ponta a ponta da plataforma

Estado: diretório reservado; não há cenários executáveis.

Reservado a jornadas completas com Server, Agent e, quando pertinente, frontend reais: publicar revisão válida, executar trabalho autorizado e consultar resultado. Registrar ambiente, revisões, dados, limpeza, serviços reais e substituições de dependências externas. API simulada não comprova essa jornada.

Runner, fixtures, dependências de ambiente, descoberta e comandos permanecem pendentes. Não criar testes vazios para preencher este diretório.

[Política de testes](../../docs/development/testing.md) · [Organização](../../docs/architecture/application-layout.md).
