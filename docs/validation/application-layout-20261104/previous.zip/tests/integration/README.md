# Integração entre componentes

Estado: diretório reservado; não há cenários executáveis.

Reservado a cenários como negociação Agent/Server e entrega de resultados com falhas controladas. Identificar os componentes reais, dependências substituídas, contrato e oracle de cada cenário. Não duplicar testes internos de crates.

Runner, fixtures, dependências de ambiente, descoberta e comandos permanecem pendentes. Não criar testes vazios para preencher este diretório.

[Política de testes](../../docs/development/testing.md) · [Organização](../../docs/architecture/application-layout.md).
