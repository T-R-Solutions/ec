# Inventário de scripts e decisões Ec — 2026-11-05

O conteúdo foi inspecionado antes de executar importados. O inventário exato por
arquivo/hash/decisão está em [inventory.json](../validation/scripts-ec-20261105/inventory.json).
A cópia integral anterior está em [previous.zip](../validation/scripts-ec-20261105/previous.zip),
incluindo licenças/fontes e versões anteriores dos documentos/skills editados. Não
foi removido material histórico fora de scripts/. As decisões abaixo cobrem todos
os arquivos originais por grupos coerentes; não conservam infraestrutura por hipótese futura.

| Arquivos/grupo | Finalidade, consumidores e efeitos observados | Decisão Ec e verificação |
| --- | --- | --- |
| `scripts/tauri/` (7 arquivos) | Release/teste/performance desktop Tauri; wrappers CLI não tinham tarefa configurada. Ec é Server/Agent e web, sem manifest Tauri. | Nenhum consumidor Ec; remover; conferir imports e wrappers. |
| `scripts/release/` (5 arquivos) | Updater Tauri, atestados de origem com produto fixo, certificados Windows/macOS; escreve config e importa/remove certificado do usuário. | Sem release desktop Ec ou consumidor; remover; preservar fonte/licença, não executar efeitos no host. |
| `scripts/architecture/` (4 arquivos) | Parser TypeScript/Svelte, owners e dependências src-tauri, baseline do produto importado. | Não representa módulos Rust/HTTP/Vue do Ec. Remover em vez de renomear regras sem oráculo. Arquitetura exige revisão/testes de contratos concretos. |
| `scripts/graphify/` (5 arquivos) | Grafo com corpus Svelte/Tauri, caminhos de produto e wrappers sem ferramenta/configuração. | ADR-001 exclui motores de contexto; não há consumidor Ec. Remover; buscar referências operacionais. |
| `scripts/bun/` (2 arquivos) | Wrapper de política e helper que cria TMPDIR e exige Bun. | Frontend Ec tem package-lock e npm. Remover dependência obrigatória; confirmar execução npm e lock preservado. |
| `scripts/frontend/` (13 arquivos) | Wrappers de npm/Bun sem configuração, ESLint ratchet e budgets importados; dev/setup não apontavam a tarefa real. | Substituir typecheck/test/build pelo runner npm real; remover lint/cobertura/performance sem scripts/budgets Ec. vue-tsc cobre .vue, sem parser Svelte. |
| `scripts/rust/` (9 arquivos) | Wrappers fmt/clippy/test e audit/deny/geiger/machete/cobertura sem pins/tarefas reais. | Substituir verificações reais por seleção server/agent; remover ferramentas sem política/consumidor Ec. Ler os dois toolchains e usar caches/targets reais. |
| `scripts/governance/` (3 arquivos) | Validador genérico JSON para frases/budgets e wrappers AGENTS/skills. | Redundante com tools/governance; remover e chamar auditor/instalador canônicos diretamente. Testar integridade e negativos da suíte existente. |
| `scripts/security/verify.sh` (1 arquivos) | Wrapper security sem configuração Ec de ferramentas/bases. | Remover wrapper e substituir por automate.py run --surface security; ausência de Gitleaks é blocked. |
| `scripts/security/containers/` (2 arquivos) | Dockerfiles Qodana Rust/JS com EAP, bibliotecas WebKit/desktop e apt global na imagem. | Remover: não há configuração, baseline, licença/token ou pipeline Ec; não construir nem puxar imagens por herança. |
| `scripts/security/commands/` (8 arquivos) | Wrappers de scanners e Qodana que faz build --pull, usa tokens de outro produto, src-tauri e caminhos scripts/checks inexistentes. | Remover wrappers sem tarefa real; Gitleaks passa ao runner com regra default e snapshot explícito. Nenhum download automático. |
| `scripts/security/rules/` (3 arquivos) | Regras Opengrep Rust/TS/Svelte/Tauri com owners/nomes/limites da origem. | Remover: regras de outra arquitetura, sem fixtures/política Ec. Não afirmar cobertura SAST substituta. |
| `scripts/security/analyzers/` (2 arquivos) | Parsers de relatórios e registro genérico de exceções sem consumidor configurado. | Remover: scanner mantido valida JSON no próprio runner, sem motor de exceções ou limiares fictícios. |
| `scripts/git/` (1 arquivos) | Setup de hook encaminhava para tarefa inexistente. | Remover; não há hook Ec para configurar. Encerramento é política explícita, sem alterar hooks existentes. |
| `scripts/lib/` (4 arquivos) | Cores/temp e logs por palavras-chave com owner fixo e retenção destrutiva de apenas dois logs. | Remover helpers sem consumidor após Qodana/TS; runner retém bytes, exit e runs únicos, sem apagar histórico. |
| `scripts/typescript/` (1 arquivos) | tsconfig usa tipos Bun e extends/pacotes ausentes. | Remover; frontend tem tsconfig próprio com Vue. |
| `scripts/verify/` (1 arquivos) | Wrapper full de biblioteca, sem configuração do consumidor. | Substituir por automate.py run com seleção Ec utilizável e padrão conservador. |
| `scripts/automation/examples/` (4 arquivos) | Exemplos Rust/Kotlin/Gradle/Vue/misto com paths/hashes de placeholder. | Remover: exemplos não são config ativa. Ec não tem Gradle/Kotlin. ec.toml é configuração real e testada. |
| `scripts/automation/adapters/` (2 arquivos) | Descoberta de stacks e defaults de scanners, bases offline, Gradle e scripts não configurados. | Substituir por plano fixo Ec; não manter plataforma genérica. Testar encaminhamento, flags e ausências. |
| `scripts/automation/rules/security.yml` (1 arquivos) | Cinco indicadores SAST incluindo Kotlin/Svelte; sem suite/configuração Ec. | Remover sem alegar SAST completo ou herdar regras de origem. |
| `scripts/automation/rules/suspicious.yar` (1 arquivos) | Dois indicadores textuais YARA de malware; sem política/dataset validado. | Remover: sem scanner/consumidor necessário; não certificaria comportamento de terceiros. |
| `scripts/automation/rules/gitleaks.toml` (1 arquivos) | Estende regras default da CLI; não contém exceções de outro produto. | Manter; verificar CLI revisada e redaction/JSON; scanner ausente bloqueia security. |
| `scripts/automation/powershell-lint.ps1` (1 arquivos) | PSScriptAnalyzer para PowerShell; parsing AST sem dot-source. | Remover: retirados releases Windows, Ec mantido não tem PowerShell; sem consumidor. |
| `scripts/automation/metrics.py` (1 arquivos) | Cobertura LCOV/JaCoCo, budget gzip, p95 e exceções; consumidor teria de fornecer limiares. | Remover: não há política Ec/configuração/testes de aplicação que usem essas métricas. |
| `scripts/automation/reports.py` (1 arquivos) | Parsers para dez scanners/formatos, sem scanners Ec configurados. | Remover: mantido só JSON Gitleaks, validado diretamente; sem falsa equivalência de cobertura. |
| `scripts/automation/runtime.py` (1 arquivos) | Supervisor POSIX de subprocessos, timeout/cancelamento e logs; antigo Runner requeria pins absolutos e datasets. | Refatorar: preservar execute/terminate e logs brutos; substituir Runner genérico por lock/plano Ec e observação de inputs, sem pins pessoais ativos. |
| `scripts/automation/model.py` (1 arquivos) | Modelos/configuração TOML genéricos e detecção de stacks. | Refatorar para superfícies/workspaces/comandos reais, mantendo paths contidos; testes de seleção e execução. |
| `scripts/automation/cli.py` (1 arquivos) | Entrada plan/run, sinais, seleção e resultados. | Refatorar para Ec; sem root/config obrigatórios artificiais. Testar cwd, espaços, saídas e bloqueios. |
| `scripts/automation/LICENSE` (1 arquivos) | Licença MIT do componente de automação importado, distinta da licença raiz. | Manter bytes; não relicenciar outros recursos. |
| `scripts/automation/__init__.py` (1 arquivos) | Marcador do pacote Python, consumidor automate.py. | Manter; verificar importação/entrada. |
| `scripts/reports/summarize.py` (1 arquivos) | Renderiza resultados schema 1 em Markdown; não cria aprovação. | Manter consumidor real de results.json; testar renderização e estados do runner. |
| `scripts/automate.py` (1 arquivos) | Entrada Python da biblioteca. | Refatorar e manter como entrada única Ec; root pela localização e overrides explícitos. |
| `scripts/automation/README.md` (1 arquivos) | Manual genérico com exemplos/placeholders e consumidores externos ausentes. | Refatorar: responsabilidades reais e referência à política canônica. |
| `scripts/README.md` (1 arquivos) | Inventário importado com links para src/doc ausentes e comandos não configurados. | Refatorar: comandos reais, links Ec e inventário permanente. |

## Consumidores e recursos externos

Busca fora de scripts (incluindo arquivos ocultos pertinentes) não encontrou caller
operacional dos wrappers importados. Referências nos próprios scripts/READMEs foram
retiradas com seus consumidores. `tools/governance` permanece canônico. Nenhum
arquivo da pesquisa TeamCity ou dos relatórios históricos foi reescrito/removido.
O harness Firefox era consumidor de um destino fixo histórico; agora aceita
EC_E2E_ARTIFACT_DIR ou cria pasta temporária única, preservando imagens anteriores.
Novos consumidores são AGENTS, README, guias, workflow/templates e duas pontes/skills,
com a política concentrada em task-verification.md. O inventário original menciona
caminhos retirados como registro, não como instruções executáveis.

Qodana suporta análise Rust/JS, portanto não é inaplicável pela linguagem. Foi
retirado pela falta de configuração/licença/token/baseline Ec e pelas operações
específicas de desktop. Fontes oficiais consultadas: [edições](https://www.jetbrains.com/help/qodana/pricing.html),
[Rust e token](https://www.jetbrains.com/help/qodana/rust.html),
[licenças de linters pagos](https://www.jetbrains.com/help/qodana/contributors.html).
CodeQL JS/TS poderia analisar frontend, mas o wrapper só encaminhava para tarefa
inexistente: sem banco/query suite/licença/repositório elegível configurados. Não
conservar um comando vazio; [condições oficiais](https://docs.github.com/en/code-security/concepts/code-scanning/codeql/codeql-cli)
e [licença da CLI](https://github.com/github/codeql-cli-binaries/blob/main/LICENSE.md).

Opengrep, OSV, Trivy, YARA, cargo-audit/deny/geiger/machete, Syft/Grype e scanners de
CI exigiriam ferramentas, bases, políticas, fixtures ou artefatos não configurados.
Os wrappers importados não entregavam essas análises. Não são gates Ec silenciosamente
aprovados; estas coberturas ficam como lacunas documentadas. A necessidade concreta
mantida é detecção de segredos nas fontes com Gitleaks (MIT); indisponibilidade dá
blocked. As dependências comuns de Vue/Rust continuam nos manifests/lockfiles.

## Verificação e recuperação

Reproduzir conforme [política canônica](task-verification.md). O relatório de
[execução](../validation/scripts-ec-20261105/report.md) distingue baseline, resultados,
bloqueios e evidências. Restaurar um arquivo de previous.zip exige comparar o conteúdo
atual para preservar edições posteriores. Não extrair todo o arquivo sobre o checkout.
Não usar erase.md como dependência operacional ou link essencial.
