# Instalação pendente — consulta temporária

Gitleaks detecta segredos nas fontes; dependência da superfície `security` em
`scripts/automate.py`. Obrigatório quando essa superfície for aplicável ou no padrão
conservador; ausente no PATH observado. Versão revisada: **8.30.1**, licença MIT.
Nenhuma instalação foi feita. Pré-requisitos permanentes também estão em
`docs/development/task-verification.md`; nenhum gate depende deste documento.

Instalação Linux x86_64 em PATH global (ação futura do operador, requer rede e sudo
somente no install): baixe o asset e checksums da [release oficial](https://github.com/gitleaks/gitleaks/releases/tag/v8.30.1),
confira SHA-256 antes de extrair e instale o executável:

```bash
curl -fLO https://github.com/gitleaks/gitleaks/releases/download/v8.30.1/gitleaks_8.30.1_linux_x64.tar.gz
curl -fLO https://github.com/gitleaks/gitleaks/releases/download/v8.30.1/gitleaks_8.30.1_checksums.txt
sha256sum --ignore-missing -c gitleaks_8.30.1_checksums.txt
tar -xzf gitleaks_8.30.1_linux_x64.tar.gz gitleaks
sudo install -m 0755 gitleaks /usr/local/bin/gitleaks
gitleaks version
```

Use pasta vazia de download e confira sucesso do checksum antes dos próximos passos.
Asset observado: SHA-256 `551f6fc83ea457d62a0d98237cbad105af8d557003051f41f3e7ca7b3f2470eb`.
Outra arquitetura exige o asset correspondente, nunca este binário.

Alternativa Docker oficial, linux/amd64, referência reproduzível do
[pacote oficial](https://github.com/gitleaks/gitleaks/pkgs/container/gitleaks/):

```bash
docker run --rm --pull=never ghcr.io/gitleaks/gitleaks:v8.30.1@sha256:b109bc5f8f76a38196a3e413704fc5b9e3c32360bce4e4b603bd6f45b3721dbb version
```

A imagem precisa ser obtida explicitamente antes. Docker requer daemon/privilégios;
scan com bind mount deve montar somente fontes necessárias e guardar relatório
separado. O runner atual consome CLI no PATH: Docker isoladamente não satisfaz seu
preflight, e não há fallback automático. Sem credenciais ou rede para scan nativo;
regras versionadas em scripts/automation/rules/gitleaks.toml. Não habilitar upload.
Após preparar a CLI, executar `python3 scripts/automate.py run --surface security`.

Rust/Node/npm/Docker/Firefox já estavam disponíveis; dependências de aplicação
continuam nos manifests/lockfiles. Não há outra solução adicional a instalar nesta
adaptação. Instruções verificadas nas fontes oficiais acima e no [manual](https://github.com/gitleaks/gitleaks).
