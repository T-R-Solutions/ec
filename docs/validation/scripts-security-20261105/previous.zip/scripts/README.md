# Scripts do Ec

Entrada para verificar uma tarefa antes de encerrá-la:

```bash
python3 scripts/automate.py run
```

O padrão conservador cobre todas as superfícies. Seleção, pré-requisitos, limites,
checks obrigatórios e interpretação de resultados estão na
[política canônica de encerramento](../docs/development/task-verification.md).
Use `plan` para inspecionar sem executar; `--surface` repetível para escopo conhecido.
Linux, Python 3.11+, sem Bun obrigatório, downloads ou instalações implícitas.

- [Configuração Ec](automation/ec.toml): workspaces e pacote reais.
- [Runner](automation/README.md): organização e contratos de execução.
- [Inventário e decisões](../docs/development/scripts-inventory.md): retenções,
  refatorações, remoções e justificativas, com cópia preservada da origem.
- `python3 -m unittest discover -s scripts/tests -v`: regressão da automação.
- `python3 scripts/reports/summarize.py CAMINHO_DO_RUN/results.json`: resumo de
  resultado já observado; não muda seu estado nem cria evidência nova.

Não há wrappers para tarefas inexistentes, setup global, release desktop, hooks
implícitos nem perfis fictícios de cobertura/performance. Critérios adicionais da
feature continuam obrigatórios conforme SDD. Logs privados ficam em
`.local/automation/runs/`, sem sobrescrever evidências históricas.
