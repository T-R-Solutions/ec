"""Plano explícito do Ec; sem descoberta Git ou comandos inferidos."""
import hashlib
import json
import sys
import tomllib
from dataclasses import asdict, dataclass, field
from pathlib import Path

STATES = ('passed', 'findings', 'error', 'blocked', 'not_applicable')
SURFACES = ('docs', 'scripts', 'server', 'agent', 'frontend', 'security', 'integration', 'e2e')


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def inside(root, value):
    path = root / value
    if Path(value).is_absolute() or '..' in Path(value).parts:
        raise ValueError('caminho deve ser relativo à raiz')
    current = root
    for part in Path(value).parts:
        current = current / part
        if current.is_symlink():
            raise ValueError(f'symlink não permitido: {value}')
    if not path.resolve().is_relative_to(root):
        raise ValueError('caminho fora da raiz')
    return path


@dataclass
class Task:
    project: str
    name: str
    argv: list[str]
    cwd: str = '.'
    prerequisites: list[str] = field(default_factory=list)
    target: str = ''
    depends: list[str] = field(default_factory=list)
    timeout: int = 900

    def data(self):
        return asdict(self)


def plan(root, surfaces):
    config = tomllib.loads(inside(root, 'scripts/automation/ec.toml').read_text())
    if set(config) != {'schema', 'projects'} or config['schema'] != 1:
        raise ValueError('configuração Ec inválida')
    expected = {'server': 'application/server/backend', 'agent': 'application/agents',
                'frontend': 'application/server/frontend'}
    if config['projects'] != expected:
        raise ValueError('projetos divergentes dos workspaces Ec; revisar plano e harnesses')
    tasks = []

    def add(project, name, argv, **kwargs):
        tasks.append(Task(project, name, argv, **kwargs))

    # Sempre: nenhuma seleção parcial dispensa governança e integridade instaladas.
    py = sys.executable
    for name, argv in [
        ('governance', [py, 'tools/governance/validate.py']),
        ('installed', [py, 'tools/governance/validate.py', '--require-installed']),
        ('skills', [py, 'tools/governance/install_skills.py', '--check']),
        ('sdd', [py, 'sdd/tools/validate.py', '--root', '.']),
        ('governance-tests', [py, '-m', 'unittest', 'discover', '-s', 'tools/governance/tests', '-v']),
    ]:
        add('docs', name, argv)
    if 'scripts' in surfaces:
        add('scripts', 'tests', [py, '-m', 'unittest', 'discover', '-s', 'scripts/tests', '-v'])
    rusts = set(surfaces) & {'server', 'agent'}
    if set(surfaces) & {'integration', 'e2e'}:
        rusts.update(('server', 'agent'))
    for project in ('server', 'agent'):
        if project not in rusts:
            continue
        cwd = expected[project]
        channel = tomllib.loads(inside(root, cwd + '/rust-toolchain.toml').read_text())['toolchain']['channel']
        manifest = inside(root, cwd + '/Cargo.toml')
        tomllib.loads(manifest.read_text())
        target = '.local/build/ec-server-clean' if project == 'server' else '.local/build/ec-agent-target'
        for name, args in [
            ('fmt', ['fmt', '--all', '--', '--check']),
            ('clippy', ['clippy', '--workspace', '--locked', '--offline', '--all-targets', '--all-features', '--', '-D', 'warnings']),
            ('test', ['test', '--workspace', '--locked', '--offline']),
        ]:
            add(project, name, ['rustup', 'run', channel, 'cargo', *args], cwd=cwd,
                prerequisites=[cwd + '/Cargo.lock'], target=target)
        if set(surfaces) & {'integration', 'e2e'}:
            add(project, 'harness-build', ['rustup', 'run', channel, 'cargo', 'build', '--workspace',
                '--locked', '--offline', '--features', 'test-failpoints'], cwd=cwd, target=target)
    if set(surfaces) & {'frontend', 'e2e'}:
        cwd = expected['frontend']
        package = read_json(inside(root, cwd + '/package.json'))
        for script in ('typecheck', 'test', 'build'):
            if script not in package['scripts']:
                raise ValueError(f'script npm ausente: {script}')
            add('frontend', script, ['npm', 'run', script], cwd=cwd,
                prerequisites=[cwd + '/package-lock.json', cwd + '/node_modules/.package-lock.json'])
    if 'security' in surfaces:
        add('security', 'secrets', ['gitleaks', 'dir', '--config', '{root}/scripts/automation/rules/gitleaks.toml',
            '--redact', '--ignore-gitleaks-allow', '--exit-code', '10', '--report-format', 'json',
            '--report-path', '{task}/report.json', '{task}/source'])
    harness_depends = ['server:harness-build', 'agent:harness-build']
    if 'integration' in surfaces:
        for name in ('publication_http', 'orchestration_http', 'agent_http'):
            add('integration', name, [py, f'application/integration/tests/integration/{name}.py'],
                depends=harness_depends)
    if 'e2e' in surfaces:
        add('e2e', 'firefox', [py, 'application/integration/tests/e2e/frontend_firefox.py'],
            depends=harness_depends + ['frontend:build'], prerequisites=['/usr/bin/firefox'])
    return tasks
