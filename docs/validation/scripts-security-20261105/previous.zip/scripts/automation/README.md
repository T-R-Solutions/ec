# Automação Ec

`../automate.py` mantém a entrada Python original e o supervisor POSIX foi reaproveitado.
O planejador genérico de pins absolutos, perfis sem consumidor e adapters de outras
stacks foi substituído por um plano Ec proporcional. A licença original permanece
em LICENSE; o backup por conteúdo preserva também todos os arquivos retirados.

A [política canônica](../../docs/development/task-verification.md) define uso e
pré-requisitos. `ec.toml` declara os três projetos; `model.py` produz comandos reais,
`cli.py` seleciona, verifica pré-requisitos e registra resultados; `runtime.py`
supervisiona processos e grava JSON atomicamente por arquivo. Não há transação
multi-arquivo nem proteção contra escritor hostil com acesso ao mesmo checkout.
Inputs alterados durante execução impedem aprovação. Não atualiza hashes de SDD.

`plan` só lê. `run` adquire lock por raiz, executa tarefas em sequência e preserva
runs distintos. Preparação de caches/pacotes/componentes é explícita e fica fora dos
checks. Códigos e logs brutos não são descartados pelo resumo. A API Python interna
é específica do Ec; consumidores externos da antiga biblioteca não estão neste checkout.
