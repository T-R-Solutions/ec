# Convergência — scripts Ec

| Critério | Estado | Evidência / limite |
| --- | --- | --- |
| AC-01 / REQ-01 / D-01 / R-01 / T001 | APPROVED | Inventário de 92 originais; 82 remoções limitadas a scripts, origem/licença preservadas e referências operacionais conferidas. |
| AC-02 / REQ-02 / D-02 / R-02 / T002 | APPROVED | 16 testes do runner e rodada real dos projetos, saídas/cwd/logs e bloqueios observados. |
| AC-03 / REQ-03 / D-03 / R-03 / T003 | APPROVED | Política única, referências e duas skills sincronizadas com metadados; auditores e 34 testes PASS. |
| AC-04 / REQ-04 / D-04 / R-04 / T004 | UNVERIFIED | Gitleaks 8.30.1 ausente. Outros checks passam; sem aprovação agregada. |

[Registro atual](../../../docs/validation/scripts-ec-20261105/report.md).
Retomada: preparar Gitleaks explicitamente, repetir security, reobservar AC-04 e
aplicar gates com aprovação/freshness. A primeira jornada ainda tem AC-01/AC-07
pendentes por motivos próprios. Sem commit, instalação global ou publicação.
