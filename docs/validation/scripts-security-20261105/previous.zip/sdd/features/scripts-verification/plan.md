# Plano — rota completa

D-01 / R-01 / REQ-01: inventariar por conteúdo e preservar originais antes de remover.
Risco de fonte única/referência quebrada; cópia por arquivo em previous.zip, sem
modificar pesquisa/relatórios anteriores.
D-02 / R-02 / REQ-02: manter automate.py e execute/terminate; substituir configuração
genérica de pins absolutos/placeholder por plano Ec + ec.toml. Alternativa de preencher
exemplos manteria stacks sem consumidor e exigiria pins pessoais. Risco de perda de
exit/log, inferência de aprovação, downloads ou concorrência; testes negativos e lock.
D-03 / R-03 / REQ-03: política única, referências em entradas e só dois pacotes alterados.
Risco de drift; precondições e sincronização seletiva, preservação de source_files,
bundle e versões anteriores; autorização real para destino protegido.
D-04 / R-04 / REQ-04: comandos conforme manifests/guias, caches offline e harnesses
sequenciais em container dedicado; scanner ausente bloqueia. Risco de sobrescrever
histórico: Firefox grava por run, sem mudar cenários/oráculos de domínio.

## Skills consultadas e contribuição

- `.codex/skills/software-delivery/SKILL.md`, ponte versão 1; SHA-256 `86383b8494cab58e79cf2c31e2f0375a4851d6c60b9de23c89b8b066d3787e1f`. Primária: comandos/inputs reais e separação de preparo/verificação.
- `.codex/skills/cli-engineering/SKILL.md`, ponte versão 1; SHA-256 `530da9febf3cc02dad798db1c484a4dcffcdd40a5df3d660c755b197563ee466`. Auxiliar: plano, cwd, exit bruto/agregado e bloqueios explícitos.
- `/home/rodrigo/.codex/skills/.system/skill-creator/SKILL.md`; SHA-256 `6656e54755638e8efcf275a472b9672eaa8a9a1b9e59dc210e275b03b59e1e66`. Auxiliar para edição limitada das duas skills; software-testing foi lida como objeto de edição, sem ativar especialistas por catálogo.

Não houve delegação. Não foram carregadas todas as skills do catálogo. As versões
anteriores dos dois SKILL.md estão no backup; hashes atuais identificam os conteúdos
efetivamente usados após a revisão. Bibliotecas de aplicação não foram instaladas.
