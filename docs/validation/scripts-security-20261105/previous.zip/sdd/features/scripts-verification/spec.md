# Especificação — scripts e encerramento Ec

- REQ-01: remover componentes importados sem consumidor, preservando origem, licenças e observações históricas.
- AC-01 → REQ-01: inventário por conteúdo cobre todos os arquivos originais de scripts, decisões/grupos justificam remoções e não há referências operacionais quebradas.
- REQ-02: entrada proporcional executa comandos reais, sem instalações implícitas, com seleção/cwd/saídas e logs honestos.
- AC-02 → REQ-02: regressões demonstram seleção Rust/npm/harnesses, falha bruta, ausência bloqueada, timeout, cancelamento, retenção, espaços, outro cwd e rejeição de alterações de inputs.
- REQ-03: encerramento referencia uma política única em AGENTS, README, SDD, templates, pontes e skills relevantes, com integridade rastreável.
- AC-03 → REQ-03: inspeção das entradas e auditores conferem os dois pacotes revisados/recuperação, fontes originais preservadas e estados de evidência atualizados sem renovar observações antigas.
- REQ-04: observar todos os checks aplicáveis e separar bloqueios da implementação e de outras features.
- AC-04 → REQ-04: governança, Rust, frontend, scripts, scanner de segredos e harnesses integration/E2E passam no ambiente autorizado, com registros novos; qualquer ferramenta obrigatória ausente mantém este critério UNVERIFIED.

Limites: Linux local confiável, sem instalação global, commit, publicação ou promessa
nova de produto; segurança não equivale a SAST/CVE/licenças, e sem dispensa de ACs da
primeira jornada. erase.md é consulta temporária, sem consumidor operacional.
