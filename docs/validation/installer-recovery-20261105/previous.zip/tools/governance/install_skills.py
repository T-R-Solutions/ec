"""Install the prepared catalog without replacing existing user content."""
import argparse
import json
from pathlib import Path
import shutil
import sys
import tempfile

from validate import audit, digest, safe, strict_json


def install(root, apply=False):
    root=root.resolve()
    result=audit(root)
    if result['status']!='PASS':
        raise ValueError('Catalog audit failed: '+ '; '.join(result['errors']))
    profile_path=root/'config/governance/profile.json'
    profile=strict_json(profile_path)
    if profile['installation_status']=='installed':
        return {'status':'ALREADY_INSTALLED','count':profile['selected_count']}
    target=safe(root,profile['target_root'],must_exist=False)
    rows=[r for r in profile['skills'] if r['decision']!='excluded']
    if target.exists():
        allowed={r['name'] for r in rows}
        if set(p.name for p in target.iterdir())-allowed:
            raise ValueError('Destination contains unrelated entries; no writes performed')
    for row in rows:
        dest=target/row['name']
        if dest.exists():
            safe(root,str(dest.relative_to(root)))
            current={str(p.relative_to(dest)):digest(safe(dest,str(p.relative_to(dest)))) for p in dest.rglob('*') if p.is_file()}
            if current!=row['files']:
                raise ValueError(f'Conflicting destination: {dest}; no writes performed')
    if not apply:
        return {'status':'READY_TO_ATTEMPT','count':len(rows),'target':str(target),
                'note':'Read-only preflight does not prove write permission. --apply performs installation.'}
    # No elevation, chmod, symlink workaround, or overwrite of a conflicting destination.
    target.mkdir(parents=True,exist_ok=True)
    for row in rows:
        dest=target/row['name']
        if dest.exists():
            continue
        source=safe(root,row['path']).parent
        with tempfile.TemporaryDirectory(prefix='.ec-install-',dir=target.parent) as temp:
            candidate=Path(temp)/row['name']
            shutil.copytree(source,candidate)
            current={str(p.relative_to(candidate)):digest(p) for p in candidate.rglob('*') if p.is_file()}
            if current!=row['files']:
                raise ValueError(f'Copy verification failed: {row["name"]}')
            if dest.exists():
                raise ValueError(f'Destination appeared concurrently: {dest}')
            candidate.rename(dest)
    for row in rows:
        dest=target/row['name']
        if {str(p.relative_to(dest)):digest(p) for p in dest.rglob('*') if p.is_file()}!=row['files']:
            raise ValueError(f'Installed content changed: {row["name"]}')
    # Retain preparation as a recovery baseline. A retry accepts only identical packages.
    for row in rows:
        bridge=root/'sdd/chain'/f'{row["name"]}.md'
        text=bridge.read_text().replace('skill_path: '+row['path'],'skill_path: '+row['target_path'])
        text=text.replace('O caminho atual é a preparação local porque `.codex` está somente leitura. O instalador muda este campo após conferir a cópia integral. Preparação não significa descoberta automática.',
                          'Pacote instalado em `.codex/skills/` com integridade conferida. Descoberta pela interface exige observação própria.')
        bridge.write_text(text)
        row['path']=row['target_path']
    profile['skill_root']=profile['target_root'];profile['installation_status']='installed'
    profile_path.write_text(json.dumps(profile,ensure_ascii=False,indent=2)+'\n')
    final=audit(root,True)
    if final['status']!='PASS':
        raise ValueError('Post-install audit failed: '+ '; '.join(final['errors']))
    return {'status':'INSTALLED','count':len(rows),'next':'Update project status prose and reexamine affected SDD evidence; old hashes must not be renewed without review.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check',action='store_true');mode.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    try: result=install(args.root,args.apply)
    except (OSError,ValueError,KeyError) as exc:
        print(json.dumps({'status':'BLOCKED','error':str(exc)},ensure_ascii=False));return 1
    print(json.dumps(result,ensure_ascii=False,indent=2));return 0


if __name__=='__main__':
    sys.exit(main())
