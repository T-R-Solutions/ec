#!/usr/bin/env bash
# Ponte para o contrato descrito em .local/usage.md; sem instalação em run.
toolbox_cli() {
    TOOLBOX=${EC_TOOLBOX_BIN:-/home/rodrigo/Projetos/dev_audit/shared-toolbox/bin/toolbox}
    [[ -x $TOOLBOX ]] || blocked "toolbox ausente: $TOOLBOX (consultar .local/usage.md)"
}
toolbox_run() {
    : "${ROOT:?raiz necessária}" "${TASK_DIR:?diretório de tarefa necessário}"
    local tool=$1 mode=${2:-scan} rc=0 state count=0 output scope=all
    [[ $mode == scan || ( $tool == opengrep && $mode == test ) ]] || fail 'modo toolbox inválido'
    [[ $tool != yara-x ]] || blocked 'YARA-X: adapter 1.0.0 indisponível na Toolbox; Ec deve fornecer regras locais antes da integração'
    toolbox_cli
    if [[ $tool == gitleaks ]]; then
        [[ $(jq -r '.tools.gitleaks.mode' "$ROOT/toolbox.json") == files ]] || blocked 'Gitleaks history requer fonte com histórico Git; snapshot Ec atual fornece somente arquivos'
    fi
    if [[ -r /sys/fs/selinux/enforce && $(< /sys/fs/selinux/enforce) == 1 ]]; then
        # Somente o snapshot e a saída dedicados recebem rótulo privado.
        export TOOLBOX_SELINUX_LABEL=private
    fi
    # O snapshot não contém caches, credenciais locais, histórico ou outros runs.
    [[ $tool != opengrep || $mode != scan ]] || scope=sast
    [[ $tool != osv-scanner ]] || scope=dependencies
    [[ $tool != trivy ]] || scope=trivy
    [[ $tool != grype && $tool != syft ]] || scope=inventory
    observe_inputs "$scope" "$TASK_DIR/source-inputs.json" "$TASK_DIR/source"
    if [[ $scope != all ]]; then
        mkdir -p "$TASK_DIR/source/scripts/security/rules"
        cp -R "$ROOT/scripts/security/rules/." "$TASK_DIR/source/scripts/security/rules/"
    fi
    if [[ $tool == playwright ]]; then
        [[ -s $ROOT/application/server/frontend/dist/index.html ]] || blocked 'build frontend necessário antes de Playwright'
        local file rel
        while IFS= read -r -d '' file; do
            rel=${file#"$ROOT/"}
            inside "$ROOT" "$rel" >/dev/null
            [[ -f $file ]] || fail 'build contém fonte não regular'
            mkdir -p "$TASK_DIR/source/$(dirname "$rel")"
            cp -- "$file" "$TASK_DIR/source/$rel"
        done < <(find "$ROOT/application/server/frontend/dist" \( -type f -o -type l \) -print0)
    fi
    if [[ $tool == gitleaks ]]; then
        need rg
        # O adapter não fornece --ignore-gitleaks-allow: rejeitar bypass no input.
        if rg -l 'gitleaks:'"allow" "$TASK_DIR/source" > "$TASK_DIR/suppression-paths.txt"; then
            fail 'supressão inline de segredos proibida; consultar suppression-paths.txt'
        else
            rc=$?
            (( rc == 1 )) || fail 'não foi possível verificar supressões'
        fi
    fi
    json_file "$ROOT/toolbox.json"
    jq --arg tool "$tool" --arg root "$TASK_DIR/source" \
        '.root=$root | .tools={($tool):.tools[$tool]} | del(.profiles)' \
        "$ROOT/toolbox.json" > "$TASK_DIR/toolbox.json"
    if [[ $tool == opengrep ]]; then
        jq --arg mode "$mode" '.tools.opengrep.mode=$mode' "$TASK_DIR/toolbox.json" > "$TASK_DIR/config.tmp"
        mv "$TASK_DIR/config.tmp" "$TASK_DIR/toolbox.json"
    fi
    if [[ -f $ROOT/toolbox.images.lock.json ]]; then
        json_file "$ROOT/toolbox.images.lock.json"
        cp "$ROOT/toolbox.images.lock.json" "$TASK_DIR/toolbox.images.lock.json"
    fi
    "$TOOLBOX" validate --config "$TASK_DIR/toolbox.json" > "$TASK_DIR/toolbox-validation.json" || fail 'configuração toolbox inválida'
    "$TOOLBOX" plan --config "$TASK_DIR/toolbox.json" --only "$tool" > "$TASK_DIR/toolbox-plan.json" || fail 'plano toolbox inválido'
    json_file "$TASK_DIR/toolbox-plan.json"
    jq -e 'length==1 and .[0].status=="planned"' "$TASK_DIR/toolbox-plan.json" >/dev/null || blocked "toolbox $tool: consultar toolbox-plan.json (imagem/adapter/preparo ausente)"
    rc=0
    "$TOOLBOX" run --config "$TASK_DIR/toolbox.json" --only "$tool" > "$TASK_DIR/toolbox-result.json" || rc=$?
    json_file "$TASK_DIR/toolbox-result.json"
    jq -e --arg tool "$tool" '.schema==1 and .sources_unchanged==true and (.tools|length==1) and .tools[0].tool==$tool' "$TASK_DIR/toolbox-result.json" >/dev/null || fail 'resultado toolbox incompleto ou fontes alteradas'
    state=$(jq -r '.tools[0].status' "$TASK_DIR/toolbox-result.json")
    output=$(jq -r '.tools[0].output' "$TASK_DIR/toolbox-result.json")
    jq --arg launcher "$TOOLBOX" --arg hash "$(hash "$TOOLBOX")" '.tools[0] | {version,image,database,command,tool_exit_code,output} + {launcher:$launcher,launcher_sha256:$hash}' "$TASK_DIR/toolbox-result.json" | atomic_json "$TASK_DIR/tool.json"
    case $state:$rc in
        prerequisite_missing:2) blocked "toolbox $tool: pré-requisito ausente; consultar $output";;
        success:0|findings:1|measurement:3) ;;
        *) fail "toolbox $tool: execução não aprovada ($state, exit=$rc); consultar $output";;
    esac
    [[ $state != measurement || $tool == syft ]] || fail 'medição inesperada para scanner'
    # Preservar relatórios nativos no run Ec, além do caminho da evidência externa.
    case $tool in
        gitleaks)
            cp "$output/native.json" "$TASK_DIR/report.json"
            jq -e 'type=="array" and all(.[]; (.RuleID|type=="string" and length>0))' "$TASK_DIR/report.json" >/dev/null || fail 'relatório Gitleaks inválido'
            count=$(jq 'length' "$TASK_DIR/report.json");;
        ruff)
            cp "$output/stdout.log" "$TASK_DIR/report.json"
            jq -e 'type=="array" and all(.[]; (.code|type=="string" and length>0))' "$TASK_DIR/report.json" >/dev/null || fail 'relatório Ruff inválido'
            count=$(jq 'length' "$TASK_DIR/report.json");;
        shellcheck)
            cp "$output/stdout.log" "$TASK_DIR/report.json"
            jq -e '.comments|type=="array" and all(.[]; (.code|type=="number"))' "$TASK_DIR/report.json" >/dev/null || fail 'relatório ShellCheck inválido'
            count=$(jq '.comments|length' "$TASK_DIR/report.json");;
        opengrep|osv-scanner)
            cp "$output/stdout.log" "$TASK_DIR/report.json"
            local parser=sast
            [[ $mode != test ]] || parser=sast-rules
            [[ $tool != osv-scanner ]] || parser=dependencies
            bash "$ROOT/scripts/security/analyzers/check-report.sh" "$parser" "$TASK_DIR/report.json" "$rc" "$TASK_DIR/source-inputs.json" /src > "$TASK_DIR/classification.json"
            return "$rc";;
        trivy)
            cp "$output/stdout.log" "$TASK_DIR/report.json"
            # O adapter retorna exit nativo 0 e traduz achados para exit agregado 1.
            bash "$ROOT/scripts/security/analyzers/check-report.sh" trivy "$TASK_DIR/report.json" "$rc" "$TASK_DIR/source-inputs.json" /src > "$TASK_DIR/classification.json"
            return "$rc";;
        bandit)
            cp "$output/stdout.log" "$TASK_DIR/report.json"
            jq -e '.errors==[] and (.metrics._totals.loc>0) and (.results|type=="array") and all(.results[]; (.test_id|type=="string" and length>0))' "$TASK_DIR/report.json" >/dev/null || fail 'relatório Bandit inválido ou sem fontes'
            count=$(jq '.results|length' "$TASK_DIR/report.json");;
        grype)
            cp "$output/stdout.log" "$TASK_DIR/report.json"
            jq -e '(.matches|type=="array") and (.descriptor|type=="object") and (.source|type=="object") and all(.matches[]; (.vulnerability.id|type=="string" and length>0))' "$TASK_DIR/report.json" >/dev/null || fail 'relatório Grype inválido'
            count=$(jq '.matches|length' "$TASK_DIR/report.json");;
        syft)
            [[ $state == measurement && $rc == 3 ]] || fail 'Syft deve produzir medição'
            cp "$output/stdout.log" "$TASK_DIR/sbom.json"
            jq -e '.descriptor.name=="syft" and (.source|type=="object") and (.artifacts|type=="array" and length>0)' "$TASK_DIR/sbom.json" >/dev/null || fail 'SBOM Syft inválido ou vazio'
            jq '{state:"passed",measurement:true,artifact_count:(.artifacts|length),reason:"SBOM gerado; não avalia vulnerabilidades"}' "$TASK_DIR/sbom.json" | atomic_json "$TASK_DIR/classification.json"
            return 0;;
        playwright)
            cp "$output/native.json" "$TASK_DIR/report.json"
            jq -e '.errors==[] and .stats.skipped==0 and .stats.flaky==0 and .stats.expected>0' "$TASK_DIR/report.json" >/dev/null || fail 'Playwright: testes omitidos, flaky, vazios ou com erro'
            count=$(jq '.stats.unexpected' "$TASK_DIR/report.json");;
    esac
    (( (rc == 1) == (count > 0) )) || fail 'exit toolbox e contagem inconsistentes'
    jq -n --arg state "$state" --argjson count "$count" '{state:(if $state=="success" then "passed" else "findings" end),finding_count:$count}' | atomic_json "$TASK_DIR/classification.json"
    return "$rc"
}
