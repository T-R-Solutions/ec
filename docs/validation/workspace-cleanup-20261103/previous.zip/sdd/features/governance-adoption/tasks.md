# Tarefas — adoção de governança

- [x] T001 [REQ-01, AC-01, D-01, R-01]: inventariar 71 candidatas, selecionar 67, preservar fontes e recursos, adaptar escopos/metadados.
- [x] T002 [REQ-02, AC-02, D-02, R-02]: revisar cinco documentos; adaptar AGENTS, constituição, arquitetura, análise e ADR.
- [x] T003 [REQ-03, AC-03, D-03, R-03]: configurar pontes reais e SDD portátil; validar links e metadados.
- [x] T004 [REQ-04, AC-04, D-04, R-04]: implementar/executar verificadores e testes negativos; registrar resultados e limites após correções.
- [x] T005 [REQ-05, AC-05, D-05, R-05]: instalar 67 skills no destino real, conferir 594 arquivos, migrar perfil/pontes, atualizar estado e reexaminar evidências afetadas. Concluído após execução autorizada fora do sandbox em 2026-11-03.
