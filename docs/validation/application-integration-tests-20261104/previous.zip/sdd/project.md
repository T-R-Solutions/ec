# Contexto e estado do Ec

## Identidade, fase e escopo

Ec é uma plataforma CI/CD de gestão abrangente. Fase observada: pesquisa, normas de produto, governança e estrutura documental da aplicação; sem aplicação implementada. A adoção de governança e a limpeza de entradas foram concluídas. O pedido atual cria os diretórios de Agent, Server e testes e documenta sua organização, sem iniciar funcionalidades do roadmap.
A feature de governança é [governance-adoption](features/governance-adoption/spec.md). A estrutura da aplicação segue a rota local documental, registrada na [ADR-002](../docs/decisions/ADR-002-application-layout.md) e no [relatório](../docs/validation/application-layout-20261103/report.md).

## Fontes e caminhos

- [Constituição/autoridades](../docs/constitution.md), [arquitetura](../docs/architecture/context.md), [ADR](../docs/decisions/ADR-001-skills-sdd-adoption.md).
- `application/agents/crates/`: domínios e composição do Agent, apenas documentação e marcadores.
- `application/server/backend/crates/`: domínios e composição do Server, apenas documentação e marcadores.
- `application/server/frontend/`: estrutura Vue 3/TypeScript/Pinia por domínios; sem código de interface.
- `tests/`: organização dos testes entre componentes, ainda sem cenários executáveis.
- `docs/`: normas, propostas, análise e resultados; [organização da aplicação](../docs/architecture/application-layout.md) e [testes](../docs/development/testing.md).
- `reverse_engineering_teamcity/`: pesquisa histórica, utilitários e protótipo de leases.
- `config/governance/sources/skills-inputs.zip`: fontes pertinentes preservadas; `skills_to_use/` removida após a integração e auditoria de limpeza.
- `config/governance/profile.json`: catálogo, origem, arquivos/hashes e estado de instalação.
- `.codex/skills/`: 67 skills instaladas e verificadas; `.local/skill-installation/skills/`: baseline de recuperação preservado.
- `sdd/`: workflow, templates, pontes, features e validador; `tools/governance/`: auditor e instalador.

## Stack e comandos reais

Alvo: Rust Server/Agent, Vue 3/TypeScript/Pinia, PostgreSQL e HTTP versionado. Sem Cargo.toml/package.json de produto, toolchain fixada ou comandos de build/run Ec disponíveis. Git history não acessível neste ambiente. Não inicializar Git nem inventar comandos.
Da raiz, Python 3.11+ stdlib:

```bash
python3 tools/governance/validate.py
python3 sdd/tools/validate.py --root .
python3 -m unittest discover -s tools/governance/tests -v
python3 tools/governance/install_skills.py --check
```

Instalação concluída pelo instalador, com perfil e pontes migrados. `python3 tools/governance/validate.py --require-installed` exige integridade no destino real; `--apply` reconhece uma instalação íntegra como `ALREADY_INSTALLED`.
O utilitário `python3 reverse_engineering_teamcity/tools/query.py BuildQueueImpl` consulta símbolos históricos. Scripts antigos com `rea/` e gerador que lê `/opt/jvm/TeamCity` exigem pré-requisitos; não executá-los como teste desta governança.

## Decisões pendentes

Transporte gRPC, Protobuf, SQLite local, plataformas, versões, isolamento, schemas reais e limites de escala continuam pendentes. A meta de 1.000 agentes é experimental. Aceitação estrutural das skills não certifica sua eficácia, acessibilidade, segurança ou comportamento do produto.

A correção dos caminhos sob `application/` em 2026-11-04 está registrada na [reobservação](../docs/validation/application-layout-20261104/report.md).
