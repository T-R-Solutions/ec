# Convergência — governança Ec após limpeza

Data: 2026-11-03. Nova observação após retirada das entradas dispensáveis; não reutiliza os hashes de aceitação anterior.

| Critério | Estado | Evidência e limite |
|---|---|---|
| AC-01 / REQ-01 / D-01 / R-01 / T001 | APPROVED | Catálogo de 71 candidatas, 67 selecionadas, seis condicionais e quatro excluídas; 578 recursos originais no bundle e 594 arquivos instalados conferidos. |
| AC-02 / REQ-02 / D-02 / R-02 / T002 | APPROVED | Cinco fontes documentais preservadas; limpeza não muda os contratos de produto nem adota propostas. |
| AC-03 / REQ-03 / D-03 / R-03 / T003 | APPROVED | Estrutura, pontes e vínculos revalidados com as novas fontes e evidências. |
| AC-04 / REQ-04 / D-04 / R-04 / T004 | APPROVED | 24 testes de governança, incluindo controles de ausência/alteração dos recursos originais e escape no bundle. |
| AC-05 / REQ-05 / D-05 / R-05 / T005 | APPROVED | Auditoria real --require-installed e preflight passam; instalação e baseline intactos. |
| AC-06 / REQ-06 / D-06 / R-06 / T006 | APPROVED | 16 arquivos removidos após preservação; inventário completo e comparação de hashes dos arquivos mantidos; verificações sem skills_to_use. |

Consultar [relatório de limpeza](../../../docs/validation/workspace-cleanup-20261103/report.md), [checks](../../../docs/validation/workspace-cleanup-20261103/checks.json) e [evidence.json](evidence.json). Os registros substituídos estão em [previous.zip](../../../docs/validation/workspace-cleanup-20261103/previous.zip). Eficácia das skills, descoberta na UI e runtime Ec não foram verificados. O material descartado de produto Ox não é recuperável pelo hash dos ZIPs antigos.

## Reobservação após estrutura da aplicação — 2026-11-03

Os estados da tabela acima descrevem a observação da limpeza. A [validação atual](../../../docs/validation/application-layout-20261103/report.md) registra a revisão dos contratos, verificações reexecutadas e comparação dos inputs após a documentação da aplicação. A evidência anterior foi preservada em [previous.zip](../../../docs/validation/application-layout-20261103/previous.zip); evidence.json passa a apontar para a observação atual. Nenhuma remoção histórica foi reexecutada. Os seis critérios continuam limitados à governança; runtime não foi implementado ou aceito.

## Correção de caminhos — 2026-11-04

A instrução do usuário move Agent e Server para `application/agents/` e `application/server/`. Contratos e critérios de governança permanecem vigentes. A [reobservação](../../../docs/validation/application-layout-20261104/report.md) preserva a evidência anterior, confere links e estrutura e reexecuta os controles com a fixture ajustada.
