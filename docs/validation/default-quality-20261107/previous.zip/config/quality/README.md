# Políticas de verificação

Configurações nativas de dependências, vulnerabilidades e SAST. Consulte o
[guia de ferramentas, preparo, fontes oficiais e limites](../../docs/development/verification-tools.md).
