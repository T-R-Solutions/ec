#!/usr/bin/env bash
set -euo pipefail
CODE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)
source "$CODE/scripts/lib/common.sh"
[[ $# == 1 ]] || fail 'uso: check.sh typecheck|test|build|dev|setup|lint|coverage|build-budget|performance (no frontend)'
check=$1
[[ -f package.json && -f package-lock.json ]] || blocked 'package.json/package-lock.json necessários'
need node; need npm; need jq
node -e 'let [a,b]=process.versions.node.split(".").map(Number);process.exit(a>22||(a===22&&b>=12)?0:1)' || blocked 'Node >=22.12 necessário'
record_tool npm "$(npm --version); Node $(node --version)"
export npm_config_offline=true npm_config_update_notifier=false
case $check in
    setup) exec npm ci --ignore-scripts;;
    build-budget)
        [[ -f quality/build-budget.json ]] || blocked 'política quality/build-budget.json necessária'
        npm run build
        exec bash "$CODE/scripts/metrics/check.sh" budget quality/build-budget.json;;
    performance)
        jq -e '.scripts.performance | type == "string"' package.json >/dev/null || blocked 'script npm performance necessário'
        [[ -f quality/performance.json ]] || blocked 'política quality/performance.json necessária'
        npm run performance
        exec bash "$CODE/scripts/metrics/check.sh" performance quality/performance.json;;
    lint|coverage|typecheck|test|build|dev) ;;
    *) fail "check frontend desconhecido: $check";;
esac
[[ -f node_modules/.package-lock.json ]] || blocked 'preparar npm ci --ignore-scripts explicitamente'
jq -e --arg check "$check" '.scripts[$check] | type == "string" and length > 0' package.json >/dev/null || blocked "script npm ausente: $check"
exec npm run "$check"
