#!/usr/bin/env bash
set -euo pipefail
CODE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)
source "$CODE/scripts/lib/common.sh"
[[ $# -ge 1 ]] || fail 'uso: check.sh fmt|clippy|test|harness-build|machete|deny|geiger|audit|coverage (no workspace)'
check=$1; shift
[[ $# == 0 ]] || fail 'argumentos inesperados'
[[ -f Cargo.toml && -f Cargo.lock && -f rust-toolchain.toml ]] || blocked 'executar no workspace Rust Ec'
# O formato versionado Ec contém um único channel literal; não avaliar TOML como código.
channel=$(sed -n 's/^channel = "\([a-zA-Z0-9.-]*\)"$/\1/p' rust-toolchain.toml)
[[ -n $channel && $channel != *$'\n'* ]] || fail 'toolchain sem channel literal único'
# Descoberta dos plugins globais independente do cache de dependências do Ec.
export PATH="$PATH:${EC_CARGO_BIN:-${CARGO_HOME:-$HOME/.cargo}/bin}:$HOME/.cargo/bin"
ROOT=${EC_ROOT:-$CODE}
export PATH="$PATH:$ROOT/.local/tools/bin"
need rustup
export RUSTUP_AUTO_INSTALL=0 CARGO_NET_OFFLINE=true
version=$(rustup run "$channel" cargo --version) || blocked "toolchain indisponível: $channel"
record_tool rustup "$version"
case $check in
    fmt) rustup run "$channel" rustfmt --version >/dev/null || blocked 'rustfmt indisponível'; set -- fmt --all -- --check;;
    clippy) rustup run "$channel" clippy-driver --version >/dev/null || blocked 'clippy indisponível'; set -- clippy --workspace --locked --offline --all-targets --all-features -- -D warnings;;
    test) set -- test --workspace --locked --offline;;
    harness-build) set -- build --workspace --locked --offline --features test-failpoints;;
    machete) need cargo-machete; set -- machete;;
    geiger) need cargo-geiger; set -- geiger --locked --offline;;
    deny)
        need cargo-deny
        policy=$ROOT/config/quality/deny.toml
        [[ -f $policy ]] || blocked 'política config/quality/deny.toml necessária'
        set -- deny --locked --offline --all-features --config "$policy" check;;
    audit)
        need cargo-audit
        db=${EC_RUSTSEC_DB:-$ROOT/.local/security/rustsec}
        [[ -d $db/.git ]] || blocked 'base RustSec local necessária; executar bash scripts/prepare.sh rustsec ou configurar EC_RUSTSEC_DB'
        need git
        stamp=$(git -C "$db" log -1 --format=%ct) || fail 'base RustSec inválida'
        [[ $stamp =~ ^[0-9]+$ ]] || fail 'data RustSec inválida'
        now=$(date +%s)
        (( stamp <= now && now - stamp <= 604800 )) || blocked 'base RustSec futura ou com commit há mais de sete dias'
        stage=${EC_TASK_DIR:-$(mktemp -d)}/audit
        mkdir -p "$stage/.cargo"
        cp "$ROOT/config/quality/audit.toml" "$stage/.cargo/audit.toml"
        lockfile=$PWD/Cargo.lock
        cd "$stage"
        set -- audit --no-fetch --db "$db" --file "$lockfile" --deny warnings --json;;
    coverage)
        need cargo-llvm-cov
        rustup component list --installed --toolchain "$channel" | grep '^llvm-tools' >/dev/null || blocked 'componente llvm-tools-preview necessário'
        set -- llvm-cov --workspace --locked --offline --lcov --output-path "${EC_TASK_DIR:-$PWD}/coverage.lcov";;
    *) fail "check Rust desconhecido: $check";;
esac
case $check in
    machete|geiger|deny|audit|coverage)
        plugin=$check
        [[ $check != coverage ]] || plugin=llvm-cov
        plugin_version=$(rustup run "$channel" cargo "$plugin" --version) || blocked "não foi possível identificar cargo-$plugin"
        record_tool "cargo-$plugin" "$plugin_version";;
esac
exec rustup run "$channel" cargo "$@"
