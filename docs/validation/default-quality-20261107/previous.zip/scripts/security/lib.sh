#!/usr/bin/env bash
# Biblioteca OSV compartilhada pelo scanner e registro explícito das bases.
database() {
    : "${ROOT:?raiz necessária}"
    local cache manifest file expected actual stamp now
    cache=$(inside "$ROOT" .local/security/osv)
    manifest=$(inside "$cache" manifest.json)
    [[ -f $manifest ]] || blocked 'base OSV não registrada: executar scripts/security/record-osv-db.sh após preparar bases'
    json_file "$manifest"
    jq -e '.schema==1 and (.recorded_at|type=="string") and (.files|keys==["osv-scanner/crates.io/all.zip","osv-scanner/npm/all.zip"])' "$manifest" >/dev/null || fail 'manifesto OSV inválido'
    stamp=$(date -d "$(jq -r .recorded_at "$manifest")" +%s) || fail 'data OSV inválida'
    now=$(date +%s)
    (( now - stamp <= 86400 )) || blocked 'snapshot OSV registrado há mais de 24h; atualizar bases explicitamente'
    (( stamp <= now )) || fail 'data OSV futura'
    for file in osv-scanner/crates.io/all.zip osv-scanner/npm/all.zip; do
        path=$(inside "$cache" "$file")
        [[ -f $path ]] || blocked "base OSV ausente: $file"
        expected=$(jq -r --arg file "$file" '.files[$file]' "$manifest")
        actual=$(hash "$path")
        [[ $actual == "$expected" ]] || fail "base OSV alterada: $file"
    done
    jq --arg hash "$(hash "$manifest")" '.+{manifest_sha256:$hash}' "$manifest"
}
