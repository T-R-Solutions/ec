#!/usr/bin/env bash
set -euo pipefail
umask 077
CODE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)
source "$CODE/scripts/lib/common.sh"
source "$CODE/scripts/lib/inputs.sh"
[[ $# == 1 ]] || fail 'uso: check.sh secrets|sast-rules|sast|dependencies|trivy|codeql'
check=$1
ROOT=${EC_ROOT:-$CODE}
if [[ -z ${EC_TASK_DIR:-} ]]; then
    exec bash "$CODE/scripts/automate.sh" run --surface security --check "$check"
fi
TASK_DIR=$EC_TASK_DIR
export SEMGREP_SEND_METRICS=off SEMGREP_ENABLE_VERSION_CHECK=0 OPENGREP_ENABLE_VERSION_CHECK=0 SEMGREP_SETTINGS_FILE=$TASK_DIR/settings.yml
source "$CODE/scripts/security/lib.sh"
source "$CODE/scripts/lib/toolbox.sh"
case $check in
    secrets) exec bash "$CODE/scripts/toolbox.sh" gitleaks;;
    sast-rules) exec bash "$CODE/scripts/toolbox.sh" opengrep test;;
    sast) exec bash "$CODE/scripts/toolbox.sh" opengrep;;
    dependencies) exec bash "$CODE/scripts/toolbox.sh" osv-scanner;;
    trivy)
        if ! command -v trivy >/dev/null; then
            exec bash "$CODE/scripts/toolbox.sh" trivy
        fi;;
esac
case $check in
    trivy)
        need trivy
        version=$(trivy --version)
        [[ $version =~ (^|[^0-9.])0\.61\.1([^0-9.]|$) ]] || blocked 'Trivy revisado: 0.61.1'
        [[ -d $ROOT/.local/security/trivy/db ]] || blocked 'base Trivy local necessária em .local/security/trivy/db'
        : > "$TASK_DIR/empty-trivyignore"
        argv=(trivy fs --config "$ROOT/config/quality/trivy.yaml" --cache-dir "$ROOT/.local/security/trivy" --ignorefile "$TASK_DIR/empty-trivyignore" --offline-scan --skip-db-update --skip-java-db-update --skip-check-update --exit-code 1 --format json --output "$TASK_DIR/report.json" "$ROOT/application");;
    codeql)
        need codeql
        version=$(codeql version)
        [[ -d $ROOT/.local/security/codeql/frontend && -f $ROOT/config/quality/codeql.qls ]] || blocked 'banco CodeQL frontend preparado e config/quality/codeql.qls necessários; conferir licença'
        observe_inputs sast "$TASK_DIR/current-sources.json"
        jq 'with_entries(select(.key|startswith("application/server/frontend/")))' "$TASK_DIR/current-sources.json" > "$TASK_DIR/frontend-sources.json"
        binding=$ROOT/.local/security/codeql/frontend/source-inputs.json
        json_file "$binding"
        jq -e --slurpfile current "$TASK_DIR/frontend-sources.json" '.==$current[0] and length>0' "$binding" >/dev/null || blocked 'banco CodeQL divergente das fontes; recriar banco e registrar source-inputs.json'
        argv=(codeql database analyze "$ROOT/.local/security/codeql/frontend" "$ROOT/config/quality/codeql.qls" --format=sarif-latest --output="$TASK_DIR/report.json");;
    *) fail "check desconhecido: $check";;
esac
command -v "${argv[0]}" > "$TASK_DIR/launcher.txt"
hash "$(command -v "${argv[0]}")" > "$TASK_DIR/launcher.sha256"
record_tool "${argv[0]}" "$version"
rc=0
"${argv[@]}" || rc=$?
printf '%s\n' "$rc" > "$TASK_DIR/scanner-exit.txt"
parser=$check
[[ $check != codeql ]] || parser=sarif
bash "$CODE/scripts/security/analyzers/check-report.sh" "$parser" "$TASK_DIR/report.json" "$rc" "$TASK_DIR/source-inputs.json" "$TASK_DIR/source" > "$TASK_DIR/classification.json"
jq -e '.state=="passed"' "$TASK_DIR/classification.json" >/dev/null || exit 1
