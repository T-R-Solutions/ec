#!/usr/bin/env bash
set -euo pipefail
CODE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)
source "$CODE/scripts/lib/common.sh"
source "$CODE/scripts/lib/inputs.sh"
source "$CODE/scripts/lib/toolbox.sh"
ROOT=${EC_ROOT:-$CODE}
TASK_DIR=${EC_TASK_DIR:?executar pelo runner}
[[ -f $ROOT/toolbox.images.lock.json ]] || blocked 'preparar imagem Gitleaks antes do teste de regras'
fixture=$TASK_DIR/fixture
mkdir -p "$fixture/config/governance" "$fixture/scripts/security/rules"
cp "$ROOT/toolbox.json" "$fixture/toolbox.json"
cp "$ROOT/toolbox.images.lock.json" "$fixture/toolbox.images.lock.json"
cp "$ROOT/scripts/security/rules/gitleaks.toml" "$fixture/scripts/security/rules/gitleaks.toml"
printf 'fixture\n' > "$fixture/AGENTS.md"
printf 'fixture\n' > "$fixture/README.md"
# Valor descartável gerado no teste, sem credencial real ou segredo em código.
token=$(head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')
jq -n --arg token "$token" '{"references/access-control.md":$token,"api_key":$token}' > "$fixture/config/governance/profile.json"
rc=0
EC_ROOT=$fixture bash "$CODE/scripts/toolbox.sh" gitleaks || rc=$?
[[ $rc == 1 ]] || fail 'Gitleaks precisa detectar a credencial sintética'
jq -e 'length==1 and .[0].RuleID=="generic-api-key" and .[0].File=="config/governance/profile.json" and .[0].StartLine==3' "$TASK_DIR/report.json" >/dev/null || fail 'exceção SHA256 ocultou credencial ou não reconheceu hash'
printf '{"state":"passed","finding_count":0}\n' | atomic_json "$TASK_DIR/classification.json"
