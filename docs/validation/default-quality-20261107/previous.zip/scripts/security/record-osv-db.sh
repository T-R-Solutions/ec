#!/usr/bin/env bash
set -euo pipefail
umask 077
CODE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)
source "$CODE/scripts/lib/common.sh"
ROOT=$CODE
if [[ $# == 2 && $1 == --root ]]; then ROOT=$(cd -- "$2" && pwd -P); elif [[ $# != 0 ]]; then fail 'uso: record-osv-db.sh [--root RAIZ]'; fi
need jq; need unzip
cache=$(inside "$ROOT" .local/security/osv)
files='{}'
for file in osv-scanner/crates.io/all.zip osv-scanner/npm/all.zip; do
    path=$(inside "$cache" "$file")
    [[ -f $path ]] || blocked "base ausente: $file"
    unzip -tqq "$path" || fail "ZIP inválido: $file"
    files=$(jq --arg key "$file" --arg hash "$(hash "$path")" '.+{($key):$hash}' <<< "$files")
done
manifest=$(inside "$cache" manifest.json)
if [[ -f $manifest ]]; then cp -p -- "$manifest" "$cache/manifest-$(date -u +%Y%m%dT%H%M%S%N).json"; fi
jq -n --arg recorded "$(date -u +%Y-%m-%dT%H:%M:%SZ)" --argjson files "$files" '{schema:1,recorded_at:$recorded,files:$files}' | atomic_json "$manifest"
printf '%s\n' "$manifest"
