# Segurança das fontes Ec

O perfil security executa Gitleaks 8.24.3 pelo toolbox compartilhado, Opengrep
1.33.1 (testes de regras + SAST) e OSV-Scanner 2.7.0 (três lockfiles offline).
As configurações, versões, preparo, fontes oficiais e limites estão no
[guia de ferramentas](../../docs/development/verification-tools.md). O toolbox documentado em
`.local/usage.md` preserva o catálogo anterior. Os adapters versionados Opengrep
1.33.1 e OSV 2.7.0 foram adicionados ao toolbox; Trivy continua pendente.

```bash
bash scripts/automate.sh run --surface security
bash scripts/automate.sh run --check secrets
bash scripts/automate.sh run --check sast
bash scripts/automate.sh run --check dependencies
bash scripts/prepare.sh tools gitleaks opengrep osv-scanner
bash scripts/prepare.sh osv-db
bash scripts/prepare.sh rustsec
```

A seleção parcial mantém governança; SAST inclui testes das oito regras locais.
Gitleaks usa defaults, redação de segredos e snapshot sem arquivos de ignore; um
teste real distingue hash de recurso e credencial sintética no mesmo arquivo. Um
preflight rejeita marcadores inline que o adapter não consegue desabilitar por flag.
A análise de segredos não inclui histórico Git, diretórios pessoais, caches ou
relatórios históricos. Inputs ativos incluem aplicação, automação, ferramentas,
SDD, configuração e guias de desenvolvimento, além dos arquivos de configuração da raiz.

SAST exige inventário completo sem skips/supressões e testes positivos de cada regra.
As regras Vue são textuais, sem análise de taint completa do script do SFC.
OSV usa snapshots dos dois Cargo.lock e do package-lock.json com --all-packages;
sem rede, sem call analysis Rust e sem executar build scripts. TOML explícito sem
ignores. Qualquer achado bloqueia o gate, independentemente da severidade.

## Bases OSV

`bash scripts/prepare.sh osv-db` baixa os ZIPs oficiais crates.io/npm por HTTPS,
valida o arquivo, grava um snapshot imutável no volume `tools/osv-scanner/volume`
do toolbox e vincula seu hash em `toolbox.json`. Usa o lock do runner. O scan exige
hash íntegro, data não futura e idade de até 24h; copia a base para a saída privada
e confere integridade depois. Rede permanece desativada no container.
Não renovar só o timestamp para aparentar download novo. Hash local não é assinatura
nem prova de frescor upstream. `record-osv-db.sh` permanece para snapshots nativos
históricos e seus testes, sem ser usado pelo adapter atual.
RustSec usa preparos separados: `prepare.sh rustsec` para Audit e `prepare.sh deny-db`
para Deny. Ambos scans são offline.

## Evidências

O runner preserva logs, exit original, configurações, snapshots por hash e relatórios
nos runs privados. Toolbox registra também imagem/versão e caminho de seus volumes;
relatórios de Ruff/Gitleaks/ShellCheck/Playwright/Opengrep/OSV são copiados para o run Ec.
No scan não há instalação, update de bases ou regras buscadas em registry.
Relatório ausente/incompleto, erro ou exit inconsistente falha; ferramenta/adapter/base
indisponível bloqueia. Exceções não são aplicadas automaticamente pelo validador.

A segurança depende também dos testes negativos reais de autorização, execução,
publicação e recuperação. Um scan limpo não substitui essas jornadas nem autoriza
publicação, implantação ou aceite de conformidade.
