#!/usr/bin/env bash
# Operação explícita com rede: não é chamada pelo runner de verificação.
set -euo pipefail
umask 077
CODE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)
source "$CODE/scripts/lib/common.sh"
source "$CODE/scripts/lib/toolbox.sh"
[[ $# -ge 1 ]] || fail 'uso: prepare.sh tools FERRAMENTA... | cargo-tools | deny-db | osv-db | rustsec'
mode=$1; shift
prepare_lock() {
    local directory lock
    need flock
    directory=$(inside "$CODE" .local/automation)
    lock=$(inside "$CODE" .local/automation/workspace.lock)
    mkdir -p "$directory"
    exec 9> "$lock"
    flock -n 9 || blocked 'outra operação usa este checkout'
}
case $mode in
    tools)
        (( $# > 0 )) || fail 'selecione ferramentas explicitamente'
        toolbox_cli
        prepare_lock
        for tool in "$@"; do
            case $tool in ruff|shellcheck|gitleaks|playwright|opengrep|osv-scanner|trivy) ;; *) fail "ferramenta desconhecida: $tool";; esac
            "$TOOLBOX" prepare --config "$CODE/toolbox.json" --only "$tool"
        done;;
    cargo-tools)
        (( $# == 0 )) || fail 'argumentos inesperados'
        prepare_lock
        need curl; need jq; need tar; need sha256sum
        mkdir -p "$CODE/.local/tools/bin"
        staging=$(mktemp -d "$CODE/.local/tools/preparation-XXXXXXXX")
        while IFS= read -r item; do
            name=$(jq -r .name <<< "$item")
            url=$(jq -r .url <<< "$item")
            checksum=$(jq -r .sha256 <<< "$item")
            member=$(jq -r .member <<< "$item")
            [[ $name == cargo-deny || $name == cargo-machete ]] || fail 'plugin desconhecido'
            [[ $url == https://github.com/* && $checksum =~ ^[a-f0-9]{64}$ && $member != /* && $member != *..* ]] || fail 'pin de plugin inválido'
            curl --fail --location --proto '=https' --proto-redir '=https' "$url" -o "$staging/$name.tar.gz"
            printf '%s  %s\n' "$checksum" "$staging/$name.tar.gz" | sha256sum --check --status || fail 'SHA256 de plugin divergente'
            tar -xOzf "$staging/$name.tar.gz" -- "$member" > "$staging/$name"
            chmod 755 "$staging/$name"
            "$staging/$name" --version
            mv "$staging/$name" "$CODE/.local/tools/bin/$name"
        done < <(jq -c '.[]' "$CODE/config/quality/cargo-tools.json");;
    deny-db)
        (( $# == 0 )) || fail 'argumentos inesperados'
        prepare_lock
        export PATH="$PATH:$CODE/.local/tools/bin" CARGO_HOME="${CARGO_HOME:-$CODE/.local/build/ec-cargo-home}"
        need cargo-deny
        cargo-deny --manifest-path "$CODE/application/server/backend/Cargo.toml" --config "$CODE/config/quality/deny.toml" fetch db;;
    osv-db)
        (( $# == 0 )) || fail 'argumentos inesperados'
        prepare_lock
        toolbox_cli
        result=$("$TOOLBOX" update-db --config "$CODE/toolbox.json" --only osv-scanner)
        database=$(jq -er '.database | select(test("^[a-f0-9]{64}$"))' <<< "$result")
        jq --arg database "$database" '.tools["osv-scanner"].database=$database' "$CODE/toolbox.json" | atomic_json "$CODE/toolbox.json"
        printf '%s\n' "$result";;
    rustsec)
        (( $# == 0 )) || fail 'argumentos inesperados'
        need git
        # Mesmo lock de verificação: nunca atualizar a base enquanto um scan roda.
        prepare_lock
        mkdir -p "$(inside "$CODE" .local/security)"
        db=$(inside "$CODE" .local/security/rustsec)
        if [[ ! -d $db ]]; then
            git clone --depth 1 https://github.com/RustSec/advisory-db.git "$db"
        else
            [[ $(git -C "$db" remote get-url origin) == https://github.com/RustSec/advisory-db.git ]] || fail 'origem RustSec divergente'
            [[ -z $(git -C "$db" status --porcelain) ]] || fail 'base RustSec com alterações locais'
            git -C "$db" fetch --depth 1 origin main
            git -C "$db" merge --ff-only FETCH_HEAD
        fi
        git -C "$db" log -1 --format='%H %cI';;
    *) fail 'modo de preparo desconhecido';;
esac
