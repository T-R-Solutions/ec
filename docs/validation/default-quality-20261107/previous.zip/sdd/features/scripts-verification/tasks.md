# Tarefas — scripts Ec

- [x] T001 [REQ-01, AC-01, D-01, R-01]: ler autoridades/manifests/guias e importados; observar baseline; inventariar e preservar originais; retirar componentes sem consumidor.
- [x] T002 [REQ-02, AC-02, D-02, R-02]: implementar plano e runner Ec e testar contratos reais e negativos.
- [x] T003 [REQ-03, AC-03, D-03, R-03]: integrar política, skills e metadados; preservar fonte/baseline e reobservar evidência afetada.
- [ ] T004 [REQ-04, AC-04, D-04, R-04]: motores obrigatórios executados;
  aceite agregado REJECTED porque Deny reprova licenças dos 11 crates privados Ec.
  Nenhuma exceção ou licença aplicada sem decisão do usuário. Demais resultados
  atuais em docs/validation/tooling-remediation-20261106/report.md.

- [x] T005 [REQ-05, AC-05, D-05, R-05]: restaurar wrappers, configurar regras/fixtures Ec e scan OSV offline; testar encaminhamento, snapshots, relatórios, versões e base; atualizar documentação e preservar registros anteriores.

T004 permanece pendente pelo gate de licenças. Os motores/bases reais executaram;
a validação por fixtures em T005 não substitui critérios de outras features.

## Migração shell — 2026-11-06

- [x] T006 [REQ-06, AC-06, D-06, R-06]: preservar originais, integrar capacidades e
  converter runner/módulos para shell; remover scripts_erase, migrar callers.
- [x] T007 [REQ-06, AC-06, D-06, R-06]: testar contratos shell, lint/sintaxe e execução
  proporcional; reobservar evidências afetadas e registrar bloqueios reais de AC-04.

- [x] T008 [REQ-07/08, AC-07/08, D-07/08, R-07/08]: integrar toolbox, configurar
  ferramentas nativas e scanners, testar contratos e documentar fontes oficiais.
- [x] T009 [AC-04/07/08]: executar runner completo e preparos autorizados, registrar
  bloqueios e reobservar evidências atuais sem renovar registros históricos.

- [x] T010 [AC-04/05/07/08, D-09/R-09]: corrigir/justificar cada alerta Ruff,
  preparar ShellCheck íntegro, disponibilizar Cargo Machete/Deny, integrar e executar
  Opengrep/OSV, rodar regressões e reobservar evidências afetadas.
