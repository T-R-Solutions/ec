# Convergência — scripts Ec

| Critério | Estado atual | Observação |
| --- | --- | --- |
| AC-01 / T001 | APPROVED | Inventário reexaminado: cinco caminhos originais reintegrados/refatorados, novas regras/fixtures/adapters registrados; backups e relatórios anteriores preservados. |
| AC-02 / T002 | APPROVED | 32 testes da automação passaram; saídas, bloqueios e seleção parcial conferidos. |
| AC-03 / T003 | APPROVED | Política única e referências atualizadas; integridade instalada e 34 testes de governança passam. Nenhuma skill/perfil alterado nesta reintegração. |
| AC-04 / T004 | UNVERIFIED | Gitleaks, Opengrep, OSV e bases ausentes. Motor real de regras/scan não aprovado por fixtures. |
| AC-05 / T005 | APPROVED | Integrações, escopo explícito, versões, config, wrappers e contratos positivos/negativos validados em fixtures; eficácia real depende de AC-04. |

[Registro atual](../../../docs/validation/scripts-security-20261105/report.md).
Retomada: preparar CLIs/bases, executar security e sast-rules reais, reobservar AC-04
sem dispensar gates. AC-01/AC-07 da primeira jornada têm pendências próprias.
