# Tarefas — scripts Ec

- [x] T001 [REQ-01, AC-01, D-01, R-01]: ler autoridades/manifests/guias e importados; observar baseline; inventariar e preservar originais; retirar componentes sem consumidor.
- [x] T002 [REQ-02, AC-02, D-02, R-02]: implementar plano e runner Ec e testar contratos reais e negativos.
- [x] T003 [REQ-03, AC-03, D-03, R-03]: integrar política, skills e metadados; preservar fonte/baseline e reobservar evidência afetada.
- [ ] T004 [REQ-04, AC-04, D-04, R-04]: executar todos os checks aplicáveis; faltam Gitleaks 8.30.1, Opengrep 1.33.1 e OSV 2.7.0/bases no PATH/cache. Não instalar globalmente nesta tarefa; preparar conforme fontes oficiais e repetir security e gate.

- [x] T005 [REQ-05, AC-05, D-05, R-05]: restaurar wrappers, configurar regras/fixtures Ec e scan OSV offline; testar encaminhamento, snapshots, relatórios, versões e base; atualizar documentação e preservar registros anteriores.

T004 permanece pendente até execução com os motores/bases reais. A validação por
fixtures em T005 não substitui esse critério nem as pendências de outras features.
