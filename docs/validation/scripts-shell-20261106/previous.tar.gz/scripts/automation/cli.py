"""Planejar ou verificar superfícies Ec com resultados preservados."""
import argparse
import fcntl
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
from pathlib import Path
from .model import SURFACES, inside, plan, read_json, sha256
from .runtime import execute, save


from . import security
from .security import Blocked


def aggregate(results):
    states = {r['state'] for r in results}
    return 2 if 'error' in states else 3 if 'blocked' in states else 1 if 'findings' in states else 0


def environment(root, directory, task):
    # Ferramentas locais confiáveis. Não herdar tokens, NODE_OPTIONS ou hooks Python.
    env = {key: os.environ[key] for key in ('PATH', 'HOME', 'RUSTUP_HOME', 'SYSTEMROOT') if key in os.environ}
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', NO_COLOR='1', PYTHONDONTWRITEBYTECODE='1',
               CARGO_NET_OFFLINE='true', RUSTUP_AUTO_INSTALL='0', npm_config_offline='true',
               npm_config_update_notifier='false',
               SEMGREP_SEND_METRICS='off', SEMGREP_ENABLE_VERSION_CHECK='0',
               OPENGREP_ENABLE_VERSION_CHECK='0', SEMGREP_SETTINGS_FILE=str(directory / 'settings.yml'), npm_config_cache=str(directory / 'npm-cache'),
               TMPDIR=str(directory), EC_E2E_ARTIFACT_DIR=str(directory / 'artifacts'))
    env['CARGO_HOME'] = os.environ.get('CARGO_HOME', str(root / '.local/build/ec-cargo-home'))
    if task.target:
        env['CARGO_TARGET_DIR'] = str(root / task.target)
    return env


def observation(command, env):
    try:
        result = subprocess.run(command, env=env, capture_output=True, timeout=15)
    except FileNotFoundError as error:
        raise Blocked(f'ferramenta de pré-requisito ausente: {command[0]}') from error
    if result.returncode:
        raise Blocked(f'pré-requisito indisponível: {command!r}: ' + result.stderr.decode(errors='replace')[-1500:])
    return result.stdout.decode(errors='replace').strip()


def preflight(root, task, env):
    for name in task.prerequisites:
        path = Path(name) if Path(name).is_absolute() else inside(root, name)
        if not path.exists():
            raise Blocked(f'pré-requisito ausente: {name}; consultar docs/development/task-verification.md')
    tool = shutil.which(task.argv[0], path=env.get('PATH'))
    if not tool:
        raise Blocked(f'ferramenta ausente: {task.argv[0]}')
    identity = {'launcher': tool, 'launcher_sha256': sha256(Path(tool))}
    if task.argv[0] == 'rustup':
        channel = task.argv[2]
        identity['version'] = observation(['rustup', 'run', channel, 'cargo', '--version'], env)
        component = 'rustfmt' if task.name == 'fmt' else 'clippy-driver' if task.name == 'clippy' else 'rustc'
        identity['component'] = observation(['rustup', 'run', channel, component, '--version'], env)
    elif task.argv[0] == 'npm':
        version = observation(['node', '--version'], env).lstrip('v').split('.')
        major, minor = int(version[0]), int(version[1])
        if major < 22 or (major == 22 and minor < 12):
            raise Blocked('Node incompatível: package.json exige >=22.12')
        identity['node'] = '.'.join(version)
        identity['version'] = observation(['npm', '--version'], env)
    elif task.argv[0] == 'gitleaks':
        identity['version'] = observation(['gitleaks', 'version'], env)
        if identity['version'].lstrip('v') != '8.30.1':
            raise Blocked('Gitleaks incompatível; versão revisada 8.30.1')
    elif task.argv[0] in security.VERSIONS:
        identity['version'] = observation([task.argv[0], *(['--disable-version-check'] if task.argv[0] == 'opengrep' else []), '--version'], env)
        security.check_version(task.argv[0], identity['version'])
        if task.name == 'dependencies':
            identity['database'] = security.database(root)
    if task.project in ('integration', 'e2e'):
        identity['docker'] = observation(['docker', 'version', '--format', '{{.Server.Version}}'], env)
        data = json.loads(observation(['docker', 'inspect', 'ec-publication-test'], env))[0]
        bindings = data['NetworkSettings']['Ports'].get('5432/tcp', [])
        if not data['State']['Running'] or not any(b['HostIp'] == '127.0.0.1' and b['HostPort'] == '55439' for b in bindings):
            raise Blocked('container dedicado deve estar ativo em 127.0.0.1:55439')
        identity['database_image'] = data['Image']
        observation(['docker', 'exec', 'ec-publication-test', 'pg_isready', '-U', 'postgres'], env)
        if not shutil.which('git', path=env.get('PATH')):
            raise Blocked('Git necessário às fixtures descartáveis')
        for port in ((58139, 5173, 58282) if task.project == 'e2e' else (58139,)):
            with socket.socket() as sock:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                try:
                    sock.bind(('127.0.0.1', port))
                except OSError as error:
                    raise Blocked(f'porta {port} indisponível: {error}') from error
    return identity


def source_files(root):
    # Escopo mantido. Pesquisa, fontes compactadas e observações históricas não são fonte ativa.
    excluded = {'.git', '.local', '.codex', '.agents', '.aws', 'node_modules', 'target', 'dist', '__pycache__'}
    for base in ('application', 'scripts', 'tools', 'sdd', 'config', 'docs/development'):
        for directory, dirs, files in os.walk(root / base, followlinks=False):
            for name in dirs:
                if name not in excluded and Path(directory, name).is_symlink():
                    raise ValueError(f'diretório fonte symlink: {Path(directory, name)}')
            dirs[:] = sorted(d for d in dirs if d not in excluded)
            for name in sorted(files):
                p = Path(directory, name)
                rel = p.relative_to(root).as_posix()
                if rel.startswith('config/governance/sources/') or rel in ('config/governance/install.lock', 'config/governance/install-journal.json'):
                    continue
                if p.is_symlink() or not p.is_file():
                    raise ValueError(f'fonte não regular: {rel}')
                yield p
    for name in ('AGENTS.md', 'README.md'):
        yield inside(root, name)


def snapshot(root, directory):
    target = directory / 'source'
    target.mkdir(mode=0o700)
    for path in source_files(root):
        dest = target / path.relative_to(root)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
        dest.chmod(0o600)
    return {p.relative_to(target).as_posix(): sha256(p) for p in target.rglob('*') if p.is_file()}


def run(root, tasks, surfaces, cancel, checks=None):
    parent = inside(root, '.local/automation/runs')
    parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    lockpath = inside(root, '.local/automation/workspace.lock')
    fd = os.open(lockpath, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise Blocked('outra verificação usa este checkout')
        directory = Path(tempfile.mkdtemp(prefix='run-', dir=parent))
        inputs = {p.relative_to(root).as_posix(): sha256(p) for p in source_files(root)}
        save(directory / 'inputs.json', inputs)
        document = {'schema': 1, 'root': str(root), 'surfaces': surfaces, 'checks': checks, 'plan': [t.data() for t in tasks],
                    'results': [], 'inputs_sha256': sha256(directory / 'inputs.json'), 'complete': False}
        results = document['results']
        print(f'Resultados: {directory}', flush=True)
        for index, task in enumerate(tasks):
            taskdir = directory / f'{index:02}-{task.project}-{task.name}'
            taskdir.mkdir(mode=0o700)
            row = {'project': task.project, 'task': task.name, 'state': 'error', 'reason': '', 'returncode': None}
            try:
                if cancel.is_set():
                    raise Blocked('cancelado antes da tarefa')
                done = {r['project'] + ':' + r['task'] for r in results if r['state'] == 'passed'}
                if set(task.depends) - done:
                    raise Blocked('dependências não aprovadas: ' + ', '.join(set(task.depends) - done))
                env = environment(root, taskdir, task)
                row['tool'] = preflight(root, task, env)
                argv = [a.replace('{root}', str(root)).replace('{task}', str(taskdir)) for a in task.argv]
                if task.project == 'security' and task.name == 'secrets':
                    (taskdir / 'empty.gitleaksignore').write_text('')
                    argv.extend(['--gitleaks-ignore-path', str(taskdir / 'empty.gitleaksignore')])
                    save(taskdir / 'source-inputs.json', snapshot(root, taskdir))
                expected = None
                if task.project == 'security' and task.name in ('sast', 'dependencies'):
                    expected = security.prepare(root, task, taskdir, env)
                    save(taskdir / 'source-inputs.json', expected)
                row['argv'], row['cwd'] = argv, str(root / task.cwd)
                row.update(execute(argv, root / task.cwd, env, taskdir, task.timeout, 8 * 1024 * 1024, cancel))
                if row['cause']:
                    row['reason'] = row['cause']
                elif task.project == 'security' and task.name == 'secrets' and row['returncode'] in (0, 10):
                    if not (taskdir / 'report.json').is_file() or (taskdir / 'report.json').is_symlink():
                        raise ValueError('relatório Gitleaks ausente ou não regular')
                    (taskdir / 'report.json').chmod(0o600)
                    report = read_json(taskdir / 'report.json')
                    if not isinstance(report, list) or any(not isinstance(v, dict) for v in report):
                        raise ValueError('relatório Gitleaks inválido')
                    if row['returncode'] == 10 and not report:
                        raise ValueError('exit de achados sem achados no relatório')
                    row['state'] = 'findings' if report else 'passed'
                    row['finding_count'] = len(report)
                elif task.project == 'security' and task.name == 'sast-rules':
                    report = read_json(taskdir / 'stdout.log')
                    row.update(security.classify_rules(report, row['returncode'], security.rule_ids(root)))
                    save(taskdir / 'report.json', report)
                elif expected is not None:
                    report_path = taskdir / 'report.json'
                    if not report_path.is_file() or report_path.is_symlink():
                        raise ValueError('scanner não produziu relatório JSON')
                    if report_path.stat().st_size > 8 * 1024 * 1024:
                        raise ValueError('relatório scanner acima do limite de 8MiB')
                    report_path.chmod(0o600)
                    row.update(security.classify(task.name, read_json(report_path), row['returncode'], taskdir / 'source', expected))
                    if task.name == 'dependencies' and security.database(root) != row['tool']['database']:
                        raise ValueError('base OSV mudou durante execução')
                else:
                    row['state'] = 'passed' if row['returncode'] == 0 else 'error'
                    if row['state'] == 'error':
                        row['reason'] = 'comando falhou; consultar stderr.log/stdout.log'
            except Blocked as error:
                row.update(state='blocked', reason=str(error))
            except (OSError, ValueError, subprocess.SubprocessError) as error:
                row.update(state='error', reason=str(error))
            results.append(row)
            save(taskdir / 'result.json', row)
            document['exit_code'] = aggregate(results)
            save(directory / 'results.json', document)
            print(f"{task.project}:{task.name}: {row['state']} (exit={row['returncode']}) {row['reason']}", flush=True)
        current = {p.relative_to(root).as_posix(): sha256(p) for p in source_files(root)}
        document['changed_inputs'] = sorted(k for k in inputs.keys() | current.keys() if inputs.get(k) != current.get(k))
        if document['changed_inputs']:
            results.append(dict(project='scripts', task='input-stability', state='error', returncode=None,
                                reason='inputs alterados durante execução; repetir checks afetados'))
        document['exit_code'] = aggregate(results)
        document['complete'] = document['exit_code'] == 0 and len(results) == len(tasks)
        save(directory / 'results.json', document)
        return document['exit_code']


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('plan', 'run'))
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--surface', action='append', choices=SURFACES, help='repetível; padrão conservador: todas')
    parser.add_argument('--check', action='append', choices=('secrets', 'sast', 'dependencies'),
                        help='check de segurança específico; não aprova os demais')
    args = parser.parse_args(argv)
    previous = {}
    try:
        root = args.root.resolve(strict=True)
        surfaces = list(dict.fromkeys(args.surface or (['security'] if args.check else SURFACES)))
        if args.check and 'security' not in surfaces:
            raise ValueError('--check requer superfície security')
        tasks = plan(root, surfaces)
        if args.check:
            names = set(args.check) | ({'sast-rules'} if 'sast' in args.check else set())
            tasks = [t for t in tasks if t.project != 'security' or t.name in names]
        if args.operation == 'plan':
            print(json.dumps({'root': str(root), 'surfaces': surfaces, 'checks': args.check, 'tasks': [t.data() for t in tasks], 'executed': False}, indent=2))
            return 0
        if sys.platform != 'linux':
            raise ValueError('supervisão suportada somente em Linux')
        cancel = threading.Event()
        for sig in (signal.SIGINT, signal.SIGTERM):
            previous[sig] = signal.signal(sig, lambda *_: cancel.set())
        return run(root, tasks, surfaces, cancel, args.check)
    except Blocked as error:
        print(f'blocked: {error}', file=sys.stderr)
        return 3
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f'error: {error}', file=sys.stderr)
        return 2
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
