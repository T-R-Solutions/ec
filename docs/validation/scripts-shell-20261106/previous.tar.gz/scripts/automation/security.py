"""Integrações Ec de SAST e dependências. Sem rede, instalação ou aceites implícitos."""
import datetime as dt
import re
import os
import shutil
from pathlib import Path
from .model import inside, read_json, sha256

VERSIONS = {'opengrep': '1.33.1', 'osv-scanner': '2.7.0'}
LOCKFILES = ('application/agents/Cargo.lock', 'application/server/backend/Cargo.lock',
             'application/server/frontend/package-lock.json')
DATABASES = ('osv-scanner/crates.io/all.zip', 'osv-scanner/npm/all.zip')
DB_ROOT = '.local/security/osv'
SAST_RULES = 'scripts/security/rules/opengrep'


class Blocked(RuntimeError):
    pass


def check_version(tool, output):
    version = re.search(r'(?<![\w.])(\d+\.\d+\.\d+(?:[-+][\w.-]+)?)(?![\w.])', output)
    if version is None or version.group(1) != VERSIONS[tool]:
        raise Blocked(f'{tool} incompatível; versão revisada {VERSIONS[tool]}; observado: {output}')


def database(root):
    cache = inside(root, DB_ROOT)
    manifest = inside(root, DB_ROOT + '/manifest.json')
    if not manifest.is_file():
        raise Blocked('base OSV não registrada: preparar crates.io/npm e executar scripts/security/record-osv-db.py')
    doc = read_json(manifest)
    if (not isinstance(doc, dict) or doc.get('schema') != 1
            or not isinstance(doc.get('files'), dict) or set(doc['files']) != set(DATABASES)
            or not isinstance(doc.get('recorded_at'), str)):
        raise ValueError('manifesto OSV inválido ou incompleto')
    stamp = dt.datetime.fromisoformat(doc['recorded_at'])
    if stamp.tzinfo is None or stamp > dt.datetime.now(dt.timezone.utc):
        raise ValueError('data de observação OSV inválida ou futura')
    for relative in DATABASES:
        path = inside(cache, relative)
        if not path.is_file():
            raise Blocked(f'base OSV ausente: {relative}')
        if sha256(path) != doc['files'][relative]:
            raise ValueError(f'base OSV alterada desde registro: {relative}')
    return {'manifest_sha256': sha256(manifest), **doc}


def prepare(root, task, directory, env):
    """Snapshots delimitados por tarefa; nunca executar configurações do alvo."""
    target = directory / 'source'
    target.mkdir(mode=0o700)
    if task.name == 'dependencies':
        files = [inside(root, p) for p in LOCKFILES]
        env['OSV_SCANNER_LOCAL_DB_CACHE_DIRECTORY'] = str(inside(root, DB_ROOT))
    else:
        files = []
        for base in ('application/agents', 'application/server/backend', 'application/server/frontend'):
            # Não seguir links nem incluir testes de regra ou histórico nos alvos SAST.
            for folder, dirs, names in os.walk(inside(root, base), followlinks=False):
                dirs[:] = sorted(d for d in dirs if d not in {'target', 'node_modules', 'dist', '.git', '__pycache__'})
                for name in dirs:
                    if Path(folder, name).is_symlink():
                        raise ValueError('diretório symlink no alvo SAST')
                for name in sorted(names):
                    path = Path(folder, name)
                    if path.suffix in {'.rs', '.ts', '.vue'}:
                        if path.is_symlink() or not path.is_file():
                            raise ValueError('fonte SAST não regular')
                        files.append(path)
        if not files:
            raise ValueError('alvo SAST vazio')
    observed = {}
    for path in files:
        rel = path.relative_to(root).as_posix()
        dest = target / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
        dest.chmod(0o600)
        observed[rel] = sha256(dest)
        if observed[rel] != sha256(path):
            raise ValueError(f'input mudou durante snapshot: {rel}')
    return observed


def relative_target(value, target):
    if not isinstance(value, str):
        raise ValueError('caminho ausente no relatório')
    path = Path(value)
    if not path.is_absolute():
        path = target / path
    try:
        return path.resolve().relative_to(target.resolve()).as_posix()
    except ValueError as error:
        raise ValueError('caminho no relatório fora do snapshot') from error


def classify(name, report, code, target, expected):
    """Valida completude antes de converter exit em findings/passed."""
    if code not in (0, 1):
        raise ValueError(f'{name}: falha operacional (exit={code})')
    if not isinstance(report, dict):
        raise ValueError('relatório scanner deve ser objeto JSON')
    if name == 'sast':
        results, errors, paths = report.get('results'), report.get('errors'), report.get('paths')
        if not isinstance(results, list) or not isinstance(errors, list) or errors or not isinstance(paths, dict):
            raise ValueError('relatório Opengrep inválido ou com erros')
        scanned = paths.get('scanned')
        if not isinstance(scanned, list) or paths.get('skipped'):
            raise ValueError('Opengrep omitiu alvos')
        if {relative_target(p, target) for p in scanned} != set(expected):
            raise ValueError('cobertura Opengrep diverge do snapshot')
        for row in results:
            if (not isinstance(row, dict) or not isinstance(row.get('check_id'), str)
                    or not isinstance(row.get('extra'), dict) or row['extra'].get('is_ignored')):
                raise ValueError('achado Opengrep inválido ou suprimido')
        count = len(results)
    else:
        results = report.get('results')
        if not isinstance(results, list) or not results or report.get('errors'):
            raise ValueError('relatório OSV vazio, inválido ou com erros')
        seen, count = set(), 0
        for source in results:
            if not isinstance(source, dict) or not isinstance(source.get('source'), dict):
                raise ValueError('origem OSV inválida')
            info, packages = source['source'], source.get('packages')
            path = relative_target(info.get('path'), target)
            if info.get('type') != 'lockfile' or path in seen or not isinstance(packages, list) or not packages:
                raise ValueError('inventário OSV incompleto ou duplicado')
            seen.add(path)
            for package in packages:
                if not isinstance(package, dict) or not isinstance(package.get('package'), dict):
                    raise ValueError('pacote OSV inválido')
                if not all(isinstance(package['package'].get(key), str) and package['package'][key]
                           for key in ('name', 'version', 'ecosystem')):
                    raise ValueError('identidade de pacote OSV ausente')
                vulns = package.get('vulnerabilities', [])
                if not isinstance(vulns, list) or any(not isinstance(v, dict) or not v.get('id') for v in vulns):
                    raise ValueError('vulnerabilidades OSV inválidas')
                count += len(vulns)
            if source.get('experimental_pes'):
                raise ValueError('sinais de supressão OSV exigem revisão explícita')
        if seen != set(expected):
            raise ValueError('OSV não reportou todos os três lockfiles')
        generic = report.get('experimental_generic_findings', [])
        if generic:
            raise ValueError('achados OSV adicionais exigem classificação explícita')
    if (code == 1) != (count > 0):
        raise ValueError('exit e contagem de achados inconsistentes')
    return {'state': 'findings' if count else 'passed', 'finding_count': count}


def rule_ids(root):
    # As anotações das fixtures são o oráculo local, independente do resultado do motor.
    ids = set()
    for path in inside(root, SAST_RULES).iterdir():
        if path.suffix in {'.rs', '.ts', '.vue'}:
            ids.update(re.findall(r'ruleid:\s*(ec\.[\w.-]+)', path.read_text()))
    if not ids:
        raise ValueError('fixtures de regras sem casos positivos')
    return ids


def classify_rules(report, code, expected):
    if code != 0 or not isinstance(report, dict):
        raise ValueError('teste das regras falhou ou não produziu JSON válido')
    for key in ('config_missing_tests', 'config_with_errors'):
        if not isinstance(report.get(key), list) or report[key]:
            raise ValueError('teste de regras incompleto ou com erro de configuração')
    results = report.get('results')
    if not isinstance(results, dict) or not results:
        raise ValueError('nenhum teste de regra executado')
    seen = set()
    for file in results.values():
        checks = file.get('checks') if isinstance(file, dict) else None
        if not isinstance(checks, dict) or not checks:
            raise ValueError('teste sem checks de regras')
        for name, result in checks.items():
            if name in seen or not isinstance(result, dict) or result.get('passed') is not True or result.get('errors'):
                raise ValueError('regra duplicada, falhou ou teve erro de motor')
            matches = result.get('matches')
            if not isinstance(matches, dict) or not matches:
                raise ValueError('regra sem comparação de linhas')
            positives = 0
            for match in matches.values():
                if not isinstance(match, dict):
                    raise ValueError('comparação de linhas inválida')
                wanted, actual = match.get('expected_lines'), match.get('reported_lines')
                if (not isinstance(wanted, list) or not isinstance(actual, list) or wanted != actual
                        or any(type(line) is not int or line < 1 for line in wanted)):
                    raise ValueError('linhas esperadas e observadas divergem')
                positives += len(wanted)
            if not positives:
                raise ValueError('regra sem caso positivo executado')
            seen.add(name)
    if seen != set(expected):
        raise ValueError('motor não testou todas as regras declaradas nas fixtures')
    return {'state': 'passed', 'rule_count': len(seen)}
