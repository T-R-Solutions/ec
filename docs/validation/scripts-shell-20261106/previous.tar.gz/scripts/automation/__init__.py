"""Portable automation; Python 3.11 standard library only."""
