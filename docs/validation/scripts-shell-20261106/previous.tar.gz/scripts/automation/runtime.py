"""Supervisão Linux: logs brutos privados, limites e lock por checkout. Não é sandbox."""
import fcntl
import json
import os
import selectors
import signal
import subprocess
import tempfile
import time
from pathlib import Path
from .model import sha256, inside


def save(path, value):
    temp = path.with_suffix('.tmp')
    with temp.open('x', encoding='utf8') as stream:
        os.chmod(temp, 0o600)
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def terminate(process):
    try: os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError: return
    try: process.wait(timeout=1)
    except subprocess.TimeoutExpired:
        try: os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError: pass
        process.wait(timeout=2)
    # Kill remaining descendants, even if their parent already exited on TERM.
    try: os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError: pass


def execute(argv, cwd, environment, directory, timeout, limit, cancel):
    """Byte-preserving stdout/stderr, bounded combined size; retain prefix on overflow."""
    started = time.monotonic(); status = None; cause = ''
    stdout_path, stderr_path = directory / 'stdout.log', directory / 'stderr.log'
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        os.chmod(stdout_path, 0o600); os.chmod(stderr_path, 0o600)
        process = subprocess.Popen(argv, cwd=cwd, env=environment, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        selector = selectors.DefaultSelector()
        selector.register(process.stdout, selectors.EVENT_READ, stdout)
        selector.register(process.stderr, selectors.EVENT_READ, stderr)
        total = 0
        try:
            while selector.get_map() or process.poll() is None:
                if cancel.is_set(): cause = 'cancelled'
                elif time.monotonic() - started >= timeout: cause = 'timeout'
                if cause:
                    terminate(process); break
                for key, _ in selector.select(timeout=0.05):
                    data = os.read(key.fileobj.fileno(), 65536)
                    if not data:
                        selector.unregister(key.fileobj); continue
                    remaining = max(0, limit - total)
                    key.data.write(data[:remaining]); total += len(data)
                    if total > limit:
                        cause = 'log byte limit exceeded'; terminate(process); break
            if not cause:
                remaining = max(0.001, timeout - (time.monotonic() - started))
                try: process.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    cause = 'timeout'; terminate(process)
            status = process.returncode
        finally:
            if process.poll() is None: terminate(process)
            # A detached child that retained no pipes is still in the process group.
            try: os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            selector.close(); process.stdout.close(); process.stderr.close()
    return {'returncode': status, 'cause': cause, 'duration_seconds': round(time.monotonic() - started, 4),
            'stdout_sha256': sha256(stdout_path), 'stderr_sha256': sha256(stderr_path)}


