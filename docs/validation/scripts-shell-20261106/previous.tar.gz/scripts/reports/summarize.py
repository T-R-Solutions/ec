#!/usr/bin/env python3
"""Render observed automation results to Markdown; never creates quality scores."""
import argparse
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from automation.model import read_json, STATES


def render(document):
    if not isinstance(document, dict) or document.get('schema') != 1 or not isinstance(document.get('results'), list) or not document['results']:
        raise ValueError('nonempty schema 1 automation results required')
    lines = ['# Resultado de automação', '', '| Projeto | Tarefa | Estado | Exit bruto | Diagnóstico |', '| --- | --- | --- | --- | --- |']
    def cell(value): return str(value).replace('|', '\\|').replace('\n', ' ').replace('\r', ' ')
    for row in document['results']:
        if not isinstance(row, dict) or row.get('state') not in STATES or not all(k in row for k in ('project','task','returncode','reason')):
            raise ValueError('invalid task result')
        lines.append('| '+' | '.join(cell(row[k]) for k in ('project','task','state','returncode','reason'))+' |')
    lines.extend(['', 'Os estados acima descrevem esta execução. Não representam assinatura de artefatos, análise de fontes alteradas depois da execução ou aprovação de produção.', ''])
    return '\n'.join(lines)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('results',type=Path);args=parser.parse_args()
    try:
        if args.results.stat().st_size > 8*1024*1024: raise ValueError('results exceeds 8 MiB')
        print(render(read_json(args.results)),end='');return 0
    except (OSError,ValueError,TypeError) as error:
        print(str(error),file=sys.stderr);return 2


if __name__=='__main__':raise SystemExit(main())
