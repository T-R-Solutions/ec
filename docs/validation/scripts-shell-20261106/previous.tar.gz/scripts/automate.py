#!/usr/bin/env python3
"""Entrada de verificação de tarefas do Ec, independente do cwd."""
from automation.cli import main

if __name__ == '__main__':
    raise SystemExit(main())
