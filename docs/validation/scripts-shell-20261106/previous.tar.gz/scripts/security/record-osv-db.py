#!/usr/bin/env python3
"""Registrar hashes de bases OSV já preparadas; não faz download nem instalação."""
import argparse
import datetime as dt
import json
from pathlib import Path
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from automation.model import inside, sha256
from automation.security import DATABASES, DB_ROOT


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    args = parser.parse_args()
    try:
        root = args.root.resolve(strict=True)
        cache = inside(root, DB_ROOT)
        files = {}
        for name in DATABASES:
            path = inside(cache, name)
            if not path.is_file() or not zipfile.is_zipfile(path):
                raise ValueError(f'base ausente ou ZIP inválido: {name}')
            files[name] = sha256(path)
        stamp = dt.datetime.now(dt.timezone.utc)
        doc = dict(schema=1, recorded_at=stamp.isoformat(), files=files)
        # Retém manifesto anterior; nunca renova uma observação antiga em silêncio.
        path = inside(root, DB_ROOT + '/manifest.json')
        if path.exists():
            old = cache / ('manifest-' + stamp.strftime('%Y%m%dT%H%M%S%f') + '.json')
            with old.open('xb') as stream:
                stream.write(path.read_bytes())
            old.chmod(0o600)
        from automation.runtime import save
        save(path, doc)
        print(json.dumps({'manifest': str(path), 'recorded_at': doc['recorded_at'],
                          'limit': 'Data de observação de bytes, não prova de download recente ou autenticidade.'}))
        return 0
    except (OSError, ValueError) as error:
        print(str(error), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
