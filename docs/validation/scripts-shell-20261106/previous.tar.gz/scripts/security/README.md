# Segurança das fontes Ec

O perfil `security` integra **Gitleaks 8.30.1**, **Opengrep 1.33.1** e **OSV-Scanner
2.7.0**. Todas as ferramentas precisam estar no PATH e apresentar a versão revisada;
preflight registra versão e hash do launcher. Não há instalação ou fallback Docker
implícito. Licenças dos executáveis: MIT, LGPL-2.1 e Apache-2.0 respectivamente;
regras Ec são locais e não incorporam pacotes de registry. Credenciais não são
necessárias. [Procedimento de encerramento](../../docs/development/task-verification.md).

```bash
python3 scripts/automate.py run --surface security
python3 scripts/automate.py run --check sast
python3 scripts/automate.py run --check dependencies
bash scripts/security/commands/opengrep.sh
bash scripts/security/commands/osv-scanner.sh
```

Os wrappers encaminham ao mesmo runner e preservam exit. Raiz/cwd seguem o contrato
comum; `--root` aceita uma cópia completa do Ec, inclusive com espaços. `--check`
seleciona somente o scanner indicado e os testes de regra necessários, mantendo
checks de governança; resultado parcial não aprova todo o perfil. O padrão sem
seletores inclui os três scanners.

| Check | Alvo e comportamento |
| --- | --- |
| secrets | Gitleaks com regras default e redaction, sem comentários de supressão. Snapshot inclui application, scripts, tools, sdd, config, docs/development, AGENTS e README; exclui .git, .local, .codex, .agents, .aws, node_modules, target, dist, __pycache__ e config/governance/sources. Pesquisa/relatórios históricos ficam fora. |
| sast-rules | `opengrep scan --test` nas regras/fixtures versionadas; falha de teste impede aprovação agregada. JSON deve conter comparações de linhas e casos positivos para as oito regras; teste vazio não aprova. Nenhuma fixture insegura é executada. |
| sast | Snapshot de .rs/.ts/.vue dos dois workspaces Rust e frontend, incluindo seus testes, excluindo target/node_modules/dist/.git/__pycache__. Regras em rules/opengrep: SQL PostgreSQL dinâmico, hashes fracos e valor Rust não inicializado; interpretação dinâmica, sinks HTML e tokens persistidos no browser TS; v-html/eval em Vue. Sem regra que proíba o shell autorizado do Agent. |
| dependencies | Snapshot dos dois Cargo.lock e application/server/frontend/package-lock.json; três `--lockfile` explícitos, `--offline --all-packages --all-vulns`, sem call analysis Rust, sem resolver manifests ou executar build scripts. Config TOML explícita sem ignores. |

Vue usa regras textuais `generic` para o SFC; não oferece parsing/taint TypeScript
completo de seu script. Comentários/strings podem produzir achados a revisar. O
conjunto inicial tem cobertura limitada e não é uma auditoria universal. O gate
bloqueia qualquer achado; triagem exige revisar contexto, corrigir ou definir uma
exceção específica e autorizada com teste, sem importar baselines de outro produto.
Não há supressão silenciosa nem aprovação baseada apenas em severidade.

## Preparação explícita

Instalar os binários das versões fixadas para arquitetura/libc do host a partir das
[releases Gitleaks](https://github.com/gitleaks/gitleaks/releases/tag/v8.30.1),
[releases Opengrep](https://github.com/opengrep/opengrep/releases/tag/v1.33.1) e
[releases OSV](https://github.com/google/osv-scanner/releases/tag/v2.7.0), conferindo
hash/procedência antes de disponibilizá-los no PATH. Evitar instalador `latest`.
Verificar com `gitleaks version`, `opengrep --disable-version-check --version` e
`osv-scanner --version`. Não instalar bibliotecas Vue globalmente. Rede/privilégios
de instalação são ações explícitas do operador, separadas dos scans.

OSV precisa de bases **crates.io** e **npm**, já baixadas, nesta estrutura:

```text
.local/security/osv/
  osv-scanner/crates.io/all.zip
  osv-scanner/npm/all.zip
  manifest.json
```

Preparar da raiz, em etapa com acesso à rede, conforme o
[modo offline oficial](https://github.com/google/osv-scanner/blob/v2.7.0/docs/offline-mode.md):

```bash
mkdir -p .local/security/osv/osv-scanner/crates.io .local/security/osv/osv-scanner/npm
curl -fL --output .local/security/osv/osv-scanner/crates.io/all.zip https://osv-vulnerabilities.storage.googleapis.com/crates.io/all.zip
curl -fL --output .local/security/osv/osv-scanner/npm/all.zip https://osv-vulnerabilities.storage.googleapis.com/npm/all.zip
python3 scripts/security/record-osv-db.py
```

Atualizações posteriores devem ser baixadas primeiro em arquivos temporários novos,
verificadas e substituídas somente fora de scans ativos. `record-osv-db.py` não baixa
nada: registra data de observação e SHA-256 dos ZIPs existentes, preservando o
manifesto anterior. O runner exige os dois arquivos e manifesto, verifica hashes
antes/depois e registra a identidade da base no resultado. Essa identidade não
atesta autenticidade nem download recente: atualizar antes do aceite e informar a
data/procedência observadas. Não há prazo arbitrário de validade inventado neste
incremento. Licenças/proveniência dos avisos continuam as de suas fontes OSV.

## Resultados e limites

Ferramenta/versão/base ausente: blocked (exit agregado 3). Base divergente,
relatório inválido, erro operacional, alvo omitido ou exit inconsistente: error (2).
Achados válidos: findings (1). Sem achados e com inventário completo: passed (0)
para aquele check. Erros têm precedência e nenhum bloqueio vira aprovação.

Os relatórios JSON devem cobrir todos os arquivos SAST e os três lockfiles com
pacotes identificados; `--all-packages` evita interpretar ausência de inventário
como ausência de vulnerabilidades. Erros/skips e supressões reportadas não passam.
Regras Opengrep usam somente configuração local, métricas e version check desligados;
OSV offline não envia dependências nem busca bases. HOME/PATH permanecem do operador
confiável, conforme contrato do runner, que não é sandbox de rede/OS.

Logs, relatórios privados, inventários por hash e resultados ficam em runs únicos,
sem sobrescrever observações anteriores. Não se alega scan real quando a CLI está
ausente: testes com executáveis fixture validam o adapter, não a eficácia do motor.
Não há análise de histórico Git, licença de dependências ou segurança de artefatos.

Referências dos contratos: [CLI Opengrep](https://github.com/opengrep/opengrep/blob/v1.33.1/src/osemgrep/cli_scan/Scan_CLI.ml),
[flags OSV](https://github.com/google/osv-scanner/blob/v2.7.0/cmd/osv-scanner/internal/helper/flags.go),
[scan source](https://github.com/google/osv-scanner/blob/v2.7.0/docs/scan-source.md),
[JSON OSV](https://github.com/google/osv-scanner/blob/v2.7.0/pkg/models/results.go).
