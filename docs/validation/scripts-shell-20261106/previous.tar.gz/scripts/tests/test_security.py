"""Oráculos de escopo/completude e execução por executáveis fixture, sem scanners reais."""
import contextlib
import copy
import datetime as dt
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from automation import security
from automation.cli import run
from automation.model import Task, plan, read_json, sha256

ROOT = Path(__file__).resolve().parents[2]


class SecurityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ec security with spaces ')
        self.root = Path(self.temp.name).resolve()
        for file in ('AGENTS.md', 'README.md', *security.LOCKFILES):
            path = self.root / file
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('fixture')
        self.cache = self.root / security.DB_ROOT

    def tearDown(self):
        self.temp.cleanup()

    def make_database(self):
        files = {}
        for relative in security.DATABASES:
            path = self.cache / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(path, 'w') as archive:
                archive.writestr('fixture.json', '{}')
            files[relative] = sha256(path)
        doc = dict(schema=1, recorded_at=dt.datetime.now(dt.timezone.utc).isoformat(), files=files)
        (self.cache / 'manifest.json').write_text(json.dumps(doc))
        return doc

    def osv_report(self):
        return {'results': [dict(source=dict(path=path, type='lockfile'), packages=[
            dict(package=dict(name='fixture', version='1.0', ecosystem='npm' if path.endswith('.json') else 'crates.io'))]) for path in security.LOCKFILES]}

    def test_plan_retains_all_security_checks_and_explicit_offline_locks(self):
        tasks = [t for t in plan(ROOT, ['security']) if t.project == 'security']
        self.assertEqual([t.name for t in tasks], ['secrets', 'sast-rules', 'sast', 'dependencies'])
        sast = tasks[2].argv
        self.assertIn('--disable-nosem', sast)
        self.assertIn('--strict', sast)
        self.assertNotIn('auto', sast)
        osv = tasks[3].argv
        self.assertIn('--offline', osv)
        self.assertIn('--all-packages', osv)
        self.assertNotIn('--download-offline-databases', osv)
        self.assertNotIn('--recursive', osv)
        self.assertEqual(osv.count('--lockfile'), 3)
        self.assertEqual(tasks[3].prerequisites, list(security.LOCKFILES))

    def test_sast_scanned_complete_and_zero_is_pass(self):
        report = dict(results=[], errors=[], paths=dict(scanned=['src/a.rs', 'src/b.vue']))
        result = security.classify('sast', report, 0, self.root, {'src/a.rs': '', 'src/b.vue': ''})
        self.assertEqual(result['state'], 'passed')

    def test_sast_finding_blocks_even_without_suppression_policy(self):
        report = dict(results=[dict(check_id='ec.vue.raw-html', extra={})], errors=[], paths=dict(scanned=['a.vue']))
        self.assertEqual(security.classify('sast', report, 1, self.root, {'a.vue': ''})['state'], 'findings')

    def test_sast_errors_skips_missing_files_and_inconsistent_exit_fail(self):
        clean = dict(results=[], errors=[], paths=dict(scanned=['a.vue']))
        cases = []
        item = copy.deepcopy(clean); item['errors'] = [{'message': 'parse failed'}]; cases.append((item, 0))
        item = copy.deepcopy(clean); item['paths']['scanned'] = []; cases.append((item, 0))
        item = copy.deepcopy(clean); item['paths']['skipped'] = [{'path': 'a.vue'}]; cases.append((item, 0))
        item = copy.deepcopy(clean); item['paths']['scanned'] = ['../outside.vue']; cases.append((item, 0))
        item = copy.deepcopy(clean); item['results'] = [dict(check_id='x', extra=dict(is_ignored=True))]; cases.append((item, 1))
        cases.extend([(clean, 1), (clean, 2), ({}, 0)])
        for report, code in cases:
            with self.subTest(report=report, code=code), self.assertRaises(ValueError):
                security.classify('sast', report, code, self.root, {'a.vue': ''})

    def test_rule_test_json_requires_actual_complete_line_comparisons(self):
        clean = dict(config_missing_tests=[], config_with_errors=[], results={
            'rule.yml': dict(checks={'ec.fixture': dict(passed=True, errors=[], matches={
                'fixture.rs': dict(expected_lines=[5], reported_lines=[5])})})})
        self.assertEqual(security.classify_rules(clean, 0, {'ec.fixture'})['rule_count'], 1)
        invalids = [dict(config_missing_tests=[], config_with_errors=[], results={})]
        d = copy.deepcopy(clean); d['config_missing_tests'] = ['other.yml']; invalids.append(d)
        d = copy.deepcopy(clean); d['results']['rule.yml']['checks']['ec.fixture']['matches']['fixture.rs']['reported_lines'] = []; invalids.append(d)
        for report in invalids:
            with self.assertRaises(ValueError): security.classify_rules(report, 0, {'ec.fixture'})
        with self.assertRaises(ValueError): security.classify_rules(clean, 0, {'ec.fixture', 'ec.missing'})
        with self.assertRaises(ValueError): security.classify_rules(clean, 1, {'ec.fixture'})
        self.assertEqual(len(security.rule_ids(ROOT)), 8)

    def test_osv_all_three_sources_and_packages_are_required(self):
        report = self.osv_report()
        self.assertEqual(security.classify('dependencies', report, 0, self.root, security.LOCKFILES)['state'], 'passed')
        for mutator in (lambda d: d['results'].pop(), lambda d: d['results'][0].update(packages=[]),
                        lambda d: d['results'].append(d['results'][0]),
                        lambda d: d['results'][0]['source'].update(path='../outside')):
            invalid = copy.deepcopy(report); mutator(invalid)
            with self.assertRaises(ValueError):
                security.classify('dependencies', invalid, 0, self.root, security.LOCKFILES)

    def test_osv_vulnerability_and_exit_are_checked_together(self):
        report = self.osv_report()
        report['results'][0]['packages'][0]['vulnerabilities'] = [{'id': 'OSV-FIXTURE'}]
        result = security.classify('dependencies', report, 1, self.root, security.LOCKFILES)
        self.assertEqual(result, {'state': 'findings', 'finding_count': 1})
        for code in (0, 2, 127):
            with self.assertRaises(ValueError):
                security.classify('dependencies', report, code, self.root, security.LOCKFILES)

    def test_database_missing_incomplete_corrupt_and_symlink(self):
        with self.assertRaises(security.Blocked): security.database(self.root)
        self.make_database()
        self.assertIn('manifest_sha256', security.database(self.root))
        path = self.cache / security.DATABASES[0]
        path.write_bytes(b'changed')
        with self.assertRaises(ValueError): security.database(self.root)
        self.make_database()
        path.unlink()
        with self.assertRaises(security.Blocked): security.database(self.root)
        path.symlink_to(self.cache / security.DATABASES[1])
        with self.assertRaises(ValueError): security.database(self.root)

    def test_database_record_keeps_previous_observation(self):
        self.make_database()
        original = (self.cache / 'manifest.json').read_bytes()
        result = subprocess.run([sys.executable, str(ROOT / 'scripts/security/record-osv-db.py'), '--root', str(self.root)], cwd='/tmp', capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        backups = list(self.cache.glob('manifest-*.json'))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_bytes(), original)
        self.assertEqual((self.cache / 'manifest.json').stat().st_mode & 0o777, 0o600)

    def test_database_bad_metadata_does_not_escape_result_classification(self):
        self.make_database()
        for doc in ({'schema': 1, 'files': []}, {'schema': 1, 'files': {p: 'x' for p in security.DATABASES}}):
            (self.cache / 'manifest.json').write_text(json.dumps(doc))
            with self.assertRaises(ValueError):
                security.database(self.root)

    def test_versions_reject_prerelease_and_unexpected_outputs(self):
        security.check_version('opengrep', '1.33.1')
        security.check_version('osv-scanner', 'osv-scanner version: 2.7.0\nbuild info')
        for tool, output in [('opengrep', '1.33.1-alpha'), ('osv-scanner', '2.7.1'), ('opengrep', '')]:
            with self.assertRaises(security.Blocked): security.check_version(tool, output)

    def test_duplicate_json_and_nan_are_rejected(self):
        path = self.root / 'report.json'
        for text in ('{"results":[],"results":[]}', '{"value":NaN}'):
            path.write_text(text)
            with self.assertRaises(ValueError): read_json(path)

    def test_snapshot_only_rust_ts_vue_and_explicit_lockfiles(self):
        files = ['application/agents/crates/app/a.rs', 'application/server/frontend/src/View.vue',
                 'application/server/frontend/src/api.ts', 'application/server/frontend/node_modules/ignore.ts']
        for name in files:
            path = self.root / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_text('fixture')
        out = self.root / 'sast'; out.mkdir()
        found = security.prepare(self.root, Task('security', 'sast', []), out, {})
        self.assertEqual(set(found), set(files[:3]))
        dest = self.root / 'osv'; dest.mkdir(); env = {}
        self.assertEqual(set(security.prepare(self.root, Task('security', 'dependencies', []), dest, env)), set(security.LOCKFILES))
        self.assertEqual(env['OSV_SCANNER_LOCAL_DB_CACHE_DIRECTORY'], str(self.cache))
        self.assertFalse((dest / 'source/erase.md').exists())

    def test_wrappers_forward_correct_check_and_exit_from_other_cwd(self):
        bindir = self.root / 'bin'; bindir.mkdir()
        python = bindir / 'python3'
        python.write_text('#!/usr/bin/python3\nimport json,sys\nprint(json.dumps(sys.argv[1:]))\nraise SystemExit(19)\n')
        python.chmod(0o700)
        for name, check in [('opengrep', 'sast'), ('osv-scanner', 'dependencies')]:
            result = subprocess.run(['bash', str(ROOT / f'scripts/security/commands/{name}.sh'), '--root', str(self.root)],
                                    cwd='/tmp', env=dict(os.environ, PATH=str(bindir) + os.pathsep + os.environ['PATH']), capture_output=True)
            self.assertEqual(result.returncode, 19)
            args = json.loads(result.stdout)
            self.assertEqual(args[args.index('--check') + 1], check)
            self.assertEqual(args[-1], str(self.root))

    def test_selective_check_does_not_hide_rule_tests_or_governance(self):
        result = subprocess.run([sys.executable, str(ROOT / 'scripts/automate.py'), 'plan', '--check', 'sast'], cwd='/tmp', capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        doc = json.loads(result.stdout)
        self.assertEqual(doc['checks'], ['sast'])
        self.assertEqual([t['name'] for t in doc['tasks'] if t['project'] == 'security'], ['sast-rules', 'sast'])
        self.assertIn('governance', [t['name'] for t in doc['tasks']])

    def test_osv_runner_invokes_snapshot_and_preserves_raw_findings(self):
        self.make_database()
        bindir = self.root / 'bin'; bindir.mkdir()
        scanner = bindir / 'osv-scanner'
        scanner.write_text('''#!/usr/bin/python3
import sys,json,os
if '--version' in sys.argv:
    print('osv-scanner version: 2.7.0'); raise SystemExit()
assert '--offline' in sys.argv and '--all-packages' in sys.argv
assert '--gitleaks-ignore-path' not in sys.argv
assert 'OSV_SCANNER_LOCAL_DB_CACHE_DIRECTORY' in os.environ
locks = [sys.argv[i+1] for i,a in enumerate(sys.argv) if a=='--lockfile']
assert len(locks)==3 and all('/source/' in p for p in locks)
report = {'results':[{'source':{'type':'lockfile','path':p},'packages':[{'package':{'name':'fixture','version':'1','ecosystem':'npm'},'vulnerabilities':[{'id':'OSV-FIXTURE'}]}]} for p in locks]}
open(sys.argv[sys.argv.index('--output-file')+1],'w').write(json.dumps(report))
raise SystemExit(1)
''')
        scanner.chmod(0o700)
        # Ler o plano real, sem executar checks de governança na fixture minimalista.
        task = next(t for t in plan(ROOT, ['security']) if t.name == 'dependencies')
        with patch.dict(os.environ, {'PATH': str(bindir) + os.pathsep + os.environ['PATH']}), contextlib.redirect_stdout(io.StringIO()):
            code = run(self.root, [task], ['security'], threading.Event())
        self.assertEqual(code, 1)
        directory = next((self.root / '.local/automation/runs').iterdir())
        result = read_json(directory / 'results.json')['results'][0]
        self.assertEqual((result['returncode'], result['state'], result['finding_count']), (1, 'findings', 3))
        self.assertIn('database', result['tool'])


if __name__ == '__main__':
    unittest.main()
