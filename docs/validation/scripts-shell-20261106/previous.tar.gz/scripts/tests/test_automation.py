"""Contratos de execução em fixtures descartáveis, sem ferramentas de aplicação."""
import contextlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from automation.cli import Blocked, aggregate, run
from automation.model import Task, inside, plan

ROOT = Path(__file__).resolve().parents[2]


class AutomationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ec scripts with spaces ')
        self.root = Path(self.temp.name).resolve()
        for name in ('AGENTS.md', 'README.md'):
            (self.root / name).write_text('fixture')

    def tearDown(self):
        self.temp.cleanup()

    def execute(self, tasks):
        with contextlib.redirect_stdout(io.StringIO()):
            code = run(self.root, tasks, ['scripts'], threading.Event())
        dirs = sorted((self.root / '.local/automation/runs').iterdir(), key=lambda p: p.stat().st_mtime_ns)
        return code, dirs[-1], json.loads((dirs[-1] / 'results.json').read_text())

    def test_failure_preserves_bytes_and_exit_and_continues(self):
        fail = Task('scripts', 'fail', [sys.executable, '-c', "import os;os.write(1,b'raw\\x00\\xff');os.write(2,b'diagnostic');raise SystemExit(17)"])
        ok = Task('scripts', 'next', [sys.executable, '-c', 'pass'])
        code, directory, doc = self.execute([fail, ok])
        self.assertEqual(code, 2)
        self.assertEqual([r['returncode'] for r in doc['results']], [17, 0])
        self.assertFalse(doc['complete'])
        self.assertEqual((directory / '00-scripts-fail/stdout.log').read_bytes(), b'raw\x00\xff')
        self.assertEqual((directory / '00-scripts-fail/stderr.log').read_bytes(), b'diagnostic')

    def test_missing_tool_and_dependency_are_blocked(self):
        missing = Task('scripts', 'missing', ['ec-nonexistent-required-tool'])
        dep = Task('scripts', 'next', [sys.executable, '-c', 'raise Exception()'], depends=['scripts:missing'])
        code, _, doc = self.execute([missing, dep])
        self.assertEqual(code, 3)
        self.assertEqual([r['state'] for r in doc['results']], ['blocked', 'blocked'])
        self.assertTrue(all(r['returncode'] is None for r in doc['results']))

    def test_timeout_preserves_partial_output(self):
        task = Task('scripts', 'timeout', [sys.executable, '-c', "import time;print('started',flush=True);time.sleep(10)"], timeout=0.3)
        code, directory, doc = self.execute([task])
        self.assertEqual(code, 2)
        self.assertEqual(doc['results'][0]['reason'], 'timeout')
        self.assertIn(b'started', (directory / '00-scripts-timeout/stdout.log').read_bytes())

    def test_runs_are_private_and_prior_logs_survive(self):
        task = Task('scripts', 'ok', [sys.executable, '-c', "print('evidence')"])
        code, first, _ = self.execute([task])
        original = (first / 'results.json').read_bytes()
        code2, second, doc = self.execute([task])
        self.assertEqual((code, code2), (0, 0))
        self.assertNotEqual(first, second)
        self.assertEqual(original, (first / 'results.json').read_bytes())
        self.assertTrue(doc['complete'])
        self.assertEqual(first.stat().st_mode & 0o777, 0o700)
        self.assertEqual((first / 'results.json').stat().st_mode & 0o777, 0o600)

    def test_changed_input_prevents_success(self):
        task = Task('scripts', 'mutator', [sys.executable, '-c', "from pathlib import Path;Path('README.md').write_text('changed')"])
        code, _, doc = self.execute([task])
        self.assertEqual(code, 2)
        self.assertIn('README.md', doc['changed_inputs'])
        self.assertFalse(doc['complete'])

    def test_root_boundaries(self):
        with self.assertRaises(ValueError):
            inside(self.root, '../outside')
        (self.root / 'link').symlink_to('/tmp')
        with self.assertRaises(ValueError):
            inside(self.root, 'link/test')

    def test_plan_routes_actual_workspaces_npm_and_harnesses(self):
        tasks = plan(ROOT, ['server', 'agent', 'frontend', 'integration', 'e2e'])
        rust = [t for t in tasks if t.project in ('server', 'agent')]
        self.assertEqual({t.cwd for t in rust}, {'application/agents', 'application/server/backend'})
        self.assertTrue(all(t.argv[:2] == ['rustup', 'run'] for t in rust))
        self.assertTrue(all('--offline' in t.argv for t in rust if t.name != 'fmt'))
        self.assertEqual([t.argv for t in tasks if t.project == 'frontend'], [['npm', 'run', s] for s in ('typecheck', 'test', 'build')])
        self.assertEqual([t.name for t in tasks if t.project == 'integration'], ['publication_http', 'orchestration_http', 'agent_http'])
        self.assertTrue(next(t for t in tasks if t.project == 'e2e').depends)

    def test_other_cwd_spaced_root_and_no_erase(self):
        for name in ('application/agents', 'application/server/backend', 'application/server/frontend', 'scripts/automation'):
            src, dest = ROOT / name, self.root / name
            dest.mkdir(parents=True)
            files = ('ec.toml',) if name.endswith('automation') else ('package.json',) if name.endswith('frontend') else ('Cargo.toml', 'rust-toolchain.toml')
            for file in files:
                shutil.copyfile(src / file, dest / file)
        result = subprocess.run([sys.executable, str(ROOT / 'scripts/automate.py'), 'plan', '--root', str(self.root)], cwd='/tmp', capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        doc = json.loads(result.stdout)
        self.assertFalse(doc['executed'])
        self.assertEqual(set(doc['surfaces']), {'docs', 'scripts', 'server', 'agent', 'frontend', 'security', 'integration', 'e2e'})
        self.assertFalse((self.root / 'erase.md').exists())

    def test_cancellation_prevents_command(self):
        cancel = threading.Event()
        cancel.set()
        with contextlib.redirect_stdout(io.StringIO()):
            code = run(self.root, [Task('scripts', 'cancel', [sys.executable, '-c', 'raise Exception()'])], ['scripts'], cancel)
        self.assertEqual(code, 3)

    def test_log_overflow_is_failure(self):
        from automation.runtime import execute
        directory = self.root / 'logs'
        directory.mkdir()
        result = execute([sys.executable, '-c', "import os;os.write(1,b'x'*200000)"], self.root,
                         os.environ.copy(), directory, 3, 1000, threading.Event())
        self.assertEqual(result['cause'], 'log byte limit exceeded')
        self.assertEqual((directory / 'stdout.log').stat().st_size, 1000)

    def test_lock_conflict_prevents_command(self):
        import fcntl
        lockdir = self.root / '.local/automation'
        lockdir.mkdir(parents=True)
        with (lockdir / 'workspace.lock').open('w') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            with self.assertRaises(Blocked):
                self.execute([Task('scripts', 'no', [sys.executable, '-c', 'raise Exception()'])])

    def test_scan_ignores_symlink_directory_only_by_failing(self):
        from automation.cli import source_files
        (self.root / 'application').mkdir()
        (self.root / 'application/external').symlink_to('/tmp', target_is_directory=True)
        with self.assertRaises(ValueError):
            list(source_files(self.root))

    def test_preflight_distinguishes_listener_from_time_wait(self):
        import socket
        # SO_REUSEADDR é necessário para sequenciar os Servers dos harnesses.
        with socket.socket() as listener:
            listener.bind(('127.0.0.1', 0))
            listener.listen()
            address = listener.getsockname()
            with socket.socket() as probe:
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                with self.assertRaises(OSError):
                    probe.bind(address)

    def test_security_report_failure_is_not_a_pass(self):
        from unittest.mock import patch
        bindir = self.root / 'bin'
        bindir.mkdir()
        scanner = bindir / 'gitleaks'
        scanner.write_text("#!/usr/bin/python3\nimport sys,pathlib\nif sys.argv[1]=='version': print('8.30.1');raise SystemExit()\npathlib.Path(sys.argv[sys.argv.index('--report-path')+1]).write_text('{}')\n")
        scanner.chmod(0o700)
        task = Task('security', 'secrets', ['gitleaks', 'dir', '--report-path', '{task}/report.json'])
        with patch.dict(os.environ, {'PATH': str(bindir) + os.pathsep + os.environ['PATH']}):
            code, _, doc = self.execute([task])
        self.assertEqual(code, 2)
        self.assertEqual(doc['results'][0]['state'], 'error')
        self.assertFalse(doc['complete'])

    def test_security_findings_exit_remains_findings(self):
        from unittest.mock import patch
        bindir = self.root / 'bin'
        bindir.mkdir()
        scanner = bindir / 'gitleaks'
        scanner.write_text("#!/usr/bin/python3\nimport sys,pathlib\nif sys.argv[1]=='version': print('8.30.1');raise SystemExit()\npathlib.Path(sys.argv[sys.argv.index('--report-path')+1]).write_text('[{\"RuleID\":\"fixture\"}]')\nraise SystemExit(10)\n")
        scanner.chmod(0o700)
        task = Task('security', 'secrets', ['gitleaks', 'dir', '--report-path', '{task}/report.json'])
        with patch.dict(os.environ, {'PATH': str(bindir) + os.pathsep + os.environ['PATH']}):
            code, _, doc = self.execute([task])
        self.assertEqual(code, 1)
        self.assertEqual(doc['results'][0]['returncode'], 10)
        self.assertEqual(doc['results'][0]['state'], 'findings')

    def test_missing_and_findings_never_approve(self):
        self.assertEqual(aggregate([{'state': 'passed'}, {'state': 'findings'}]), 1)
        self.assertEqual(aggregate([{'state': 'findings'}, {'state': 'blocked'}]), 3)
        self.assertEqual(aggregate([{'state': 'blocked'}, {'state': 'error'}]), 2)


if __name__ == '__main__':
    unittest.main()
