# Repository Guidelines

## Contexto e autoridades

Ec é uma plataforma CI/CD em implementação: Server e Agent como monólitos modulares Rust e frontend Vue 3/TypeScript/Pinia. Há workspaces e código executável local; guias dos componentes registram limites e pendências.
Antes de alterar, leia [estado/escopo](sdd/project.md), [autoridades](docs/constitution.md), [arquitetura](docs/architecture/context.md) e ADRs pertinentes. Preserve mudanças existentes e evidências históricas; instruções do usuário e permissões reais prevalecem sobre templates.

## Estrutura

`application/agents/` contém o Agent; `application/server/` contém backend e frontend; `application/integration/tests/` reúne os testes entre componentes, com integração e ponta a ponta separados. Os caminhos partem da raiz do repositório. Cargo.toml/Cargo.lock e rust-toolchain.toml existem nos dois workspaces; frontend usa package.json/package-lock.json e npm. Diretórios, isoladamente, não comprovam funcionalidade.
`docs/` reúne normas e decisões; `reverse_engineering_teamcity/` preserva pesquisa, utilitários e protótipo; `sdd/` contém workflow, pontes e features; `config/governance/` registra catálogo e hashes; `tools/governance/` contém verificações.
As 67 skills selecionadas estão instaladas em `.codex/skills/`, com hashes conferidos. A preparação em `.local/skill-installation/skills/` permanece como baseline de recuperação. Consulte o perfil e o caminho real na ponte; não alegue instalação automática.

## Workflow e skills

Siga [sdd/workflow.md](sdd/workflow.md): rota local para reparos delimitados; completa para contratos, persistência, segurança, concorrência e recuperação. Selecione uma primária pelo problema e auxiliares por questões distintas no [catálogo](sdd/chain/README.md). Leia o `SKILL.md` efetivo e registre contribuição/hash quando usar a rota completa. Disponibilidade não significa execução; não carregue todo o catálogo.

## Contratos do produto

YAML é a configuração desejada canônica; Visual/Formulário/YAML preservam a mesma semântica. PostgreSQL guarda estado operacional; HTTP versionado é vigente. gRPC/Protobuf/SQLite local são propostas pendentes. Ec Agent não implica IA. Não prometer exactly-once, isolamento ou capacidade sem evidência. Consultar ambas as normas de `docs/` para UI; preservar autorização, acessibilidade e estados reais.

## Comandos, estilo e testes

Antes de marcar uma tarefa concluída, siga a [política canônica de verificação](docs/development/task-verification.md): identifique superfícies/consumidores, execute `python3 scripts/automate.py run` (todas por padrão, seleção explícita proporcional), corrija regressões, atualize evidências afetadas e relate comandos, resultados e lacunas. Ferramenta ausente ou perfil parcial não aprova checks restantes; critérios SDD continuam obrigatórios. Não depender exclusivamente de Git.
Código Python novo: quatro espaços e `snake_case`; JSON de governança: dois espaços. Documentação nova em pt-BR; preserve referências importadas. Testes verificam invariantes e rejeições. Não inventar comandos; usar manifests e guias vigentes.

## Commits e revisão

Apenas com pedido de commit/tag, leia a ponte `commit-governance`. Use Conventional Commits em inglês como convenção desta integração; histórico Git está indisponível. PRs descrevem mudança, requisitos/ADRs, verificações e limitações; telas alteradas incluem evidência visual pertinente. Não incluir segredos nem publicar por inferência.
