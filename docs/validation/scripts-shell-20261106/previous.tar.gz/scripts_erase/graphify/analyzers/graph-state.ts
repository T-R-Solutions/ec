import { createHash } from 'node:crypto';
import { lstat, readFile, readdir, realpath, writeFile } from 'node:fs/promises';
import { basename, isAbsolute, relative, resolve, sep } from 'node:path';

type JsonObject = Record<string, unknown>;
type GraphNodeId = string | number;

type GraphSummary = Readonly<{
  nodes: number;
  edges: number;
  selfLoops: number;
}>;

type IndexMetadata = Readonly<{
  schemaVersion: 1;
  repositoryRoot: string;
  corpusProfile: 'production-code';
  graphifyVersion: string;
  graphSha256: string;
  manifestSha256: string;
  ignoreSha256: string;
  nodes: number;
  edges: number;
}>;

const SOURCE_EXTENSIONS = new Set(['.bash', '.cjs', '.js', '.mjs', '.rs', '.sh', '.sql', '.svelte', '.ts']);
const SOURCE_ROOTS = ['src', 'src-tauri/src', 'src-tauri/campaign-migrations'] as const;
const REQUIRED_CONFIG_FILES = [
  'package.json',
  'svelte.config.js',
  'tsconfig.json',
  'vite.config.ts',
  'src-tauri/Cargo.toml',
  'src-tauri/build.rs',
  'src-tauri/tauri.conf.json',
] as const;
const VALID_CONFIDENCE = new Set(['EXTRACTED', 'INFERRED', 'AMBIGUOUS']);

const sha256 = (data: string | Buffer): string => createHash('sha256').update(data).digest('hex');
// noopengrep -- Graphify's manifest protocol stores MD5 for non-security change detection;
// SHA-256 remains the authority for the sealed graph and configuration evidence.
const graphifyManifestHash = (data: Buffer): string =>
  createHash('md5').update(data).digest('hex'); // noopengrep -- Graphify manifest compatibility only.

const parseObject = async (path: string): Promise<JsonObject> => {
  const parsed: unknown = JSON.parse(await readFile(path, 'utf8'));
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    throw new Error(`${path} must contain a JSON object`);
  }
  return parsed as JsonObject;
};

const resolveInside = (root: string, candidate: string): string => {
  if (candidate.includes('\0')) throw new Error('path contains a null byte');
  const resolved = resolve(root, candidate);
  const fromRoot = relative(root, resolved);
  if (fromRoot === '..' || fromRoot.startsWith(`..${sep}`) || isAbsolute(fromRoot)) {
    throw new Error(`path escapes repository root: ${candidate}`);
  }
  return resolved;
};

const endpointId = (value: unknown): string | number | undefined => {
  if (typeof value === 'string' || typeof value === 'number') return value;
  if (typeof value === 'object' && value !== null && 'id' in value) {
    const id = (value as JsonObject).id;
    return typeof id === 'string' || typeof id === 'number' ? id : undefined;
  }
  return undefined;
};

const validateNode = (
  root: string,
  rawNode: unknown,
  index: number,
  nodeIds: Set<GraphNodeId>,
): GraphNodeId => {
  if (typeof rawNode !== 'object' || rawNode === null || Array.isArray(rawNode)) {
    throw new Error(`node ${index} is not an object`);
  }
  const node = rawNode as JsonObject;
  const id = endpointId(node.id);
  if (id === undefined) throw new Error(`node ${index} has no valid id`);
  if (nodeIds.has(id)) throw new Error(`duplicate node id: ${String(id)}`);
  if (typeof node.source_file === 'string' && node.source_file.length > 0) {
    resolveInside(root, node.source_file);
  }
  return id;
};

const validateEdge = (
  rawEdge: unknown,
  index: number,
  nodeIds: ReadonlySet<GraphNodeId>,
): boolean => {
  if (typeof rawEdge !== 'object' || rawEdge === null || Array.isArray(rawEdge)) {
    throw new Error(`edge ${index} is not an object`);
  }
  const edge = rawEdge as JsonObject;
  const source = endpointId(edge.source);
  const target = endpointId(edge.target);
  if (source === undefined || target === undefined) {
    throw new Error(`edge ${index} has an invalid endpoint`);
  }
  if (!nodeIds.has(source) || !nodeIds.has(target)) {
    throw new Error(`edge ${index} references a missing node`);
  }
  if (edge.confidence !== undefined && !VALID_CONFIDENCE.has(String(edge.confidence))) {
    throw new Error(`edge ${index} has invalid confidence: ${String(edge.confidence)}`);
  }
  return source === target;
};

const validateGraph = async (root: string, graphPath: string): Promise<GraphSummary> => {
  const graph = await parseObject(graphPath);
  if (!Array.isArray(graph.nodes) || graph.nodes.length === 0) throw new Error('graph has no nodes');
  const edges = Array.isArray(graph.links) ? graph.links : Array.isArray(graph.edges) ? graph.edges : undefined;
  if (!edges) throw new Error('graph has neither links nor edges');

  const nodeIds = new Set<GraphNodeId>();
  for (const [index, rawNode] of graph.nodes.entries()) {
    nodeIds.add(validateNode(root, rawNode, index, nodeIds));
  }

  let selfLoops = 0;
  for (const [index, rawEdge] of edges.entries()) {
    if (validateEdge(rawEdge, index, nodeIds)) selfLoops += 1;
  }

  return { nodes: graph.nodes.length, edges: edges.length, selfLoops };
};

const isTestPath = (relativePath: string): boolean => {
  const normalized = relativePath.replaceAll('\\', '/');
  const name = basename(normalized);
  return normalized.includes('/__tests__/') || normalized.includes('/tests/') || name === 'tests.rs' || name.includes('.test.');
};

const extensionOf = (path: string): string => {
  const name = basename(path);
  const dot = name.lastIndexOf('.');
  return dot === -1 ? '' : name.slice(dot);
};

const collectSourceFiles = async (root: string, relativeDirectory: string): Promise<string[]> => {
  const absoluteDirectory = resolveInside(root, relativeDirectory);
  const entries = await readdir(absoluteDirectory, { withFileTypes: true });
  const files: string[] = [];
  for (const entry of entries.sort((left, right) => left.name.localeCompare(right.name))) {
    const relativePath = `${relativeDirectory}/${entry.name}`.replaceAll('\\', '/');
    const absolutePath = resolveInside(root, relativePath);
    const stat = await lstat(absolutePath);
    if (stat.isSymbolicLink()) continue;
    if (stat.isDirectory()) {
      files.push(...(await collectSourceFiles(root, relativePath)));
    } else if (stat.isFile() && SOURCE_EXTENSIONS.has(extensionOf(relativePath)) && !isTestPath(relativePath)) {
      files.push(relativePath);
    }
  }
  return files;
};

const expectedCorpus = async (root: string): Promise<Set<string>> => {
  const files = new Set<string>(REQUIRED_CONFIG_FILES);
  for (const sourceRoot of SOURCE_ROOTS) {
    for (const file of await collectSourceFiles(root, sourceRoot)) files.add(file);
  }
  return files;
};

const validateManifest = async (
  root: string,
  manifestPath: string,
): Promise<Readonly<{ entries: number; changed: string[]; missingFromManifest: string[] }>> => {
  const manifest = await parseObject(manifestPath);
  const manifestPaths = new Set<string>();
  const changed: string[] = [];

  for (const [storedPath, rawEntry] of Object.entries(manifest)) {
    if (isAbsolute(storedPath)) throw new Error(`manifest contains an absolute path: ${storedPath}`);
    const normalizedPath = storedPath.replaceAll('\\', '/');
    const absolutePath = resolveInside(root, normalizedPath);
    const stat = await lstat(absolutePath).catch(() => undefined);
    if (!stat?.isFile()) {
      changed.push(normalizedPath);
      continue;
    }
    if (typeof rawEntry !== 'object' || rawEntry === null || Array.isArray(rawEntry)) {
      changed.push(normalizedPath);
      continue;
    }
    const astHash = (rawEntry as JsonObject).ast_hash;
    if (
      typeof astHash !== 'string' ||
      astHash.length === 0 ||
      graphifyManifestHash(await readFile(absolutePath)) !== astHash
    ) {
      changed.push(normalizedPath);
    }
    manifestPaths.add(normalizedPath);
  }

  const missingFromManifest = [...(await expectedCorpus(root))].filter((path) => !manifestPaths.has(path)).sort();
  return { entries: Object.keys(manifest).length, changed: changed.sort(), missingFromManifest };
};

const readMetadata = async (path: string): Promise<IndexMetadata> => (await parseObject(path)) as IndexMetadata;

const buildMetadata = async (
  root: string,
  graphDirectory: string,
  graphifyVersion: string,
  summary: GraphSummary,
): Promise<IndexMetadata> => {
  const graph = await readFile(resolve(graphDirectory, 'graph.json'));
  const manifest = await readFile(resolve(graphDirectory, 'manifest.json'));
  const ignore = await readFile(resolve(root, '.graphifyignore'));
  return {
    schemaVersion: 1,
    repositoryRoot: root,
    corpusProfile: 'production-code',
    graphifyVersion,
    graphSha256: sha256(graph),
    manifestSha256: sha256(manifest),
    ignoreSha256: sha256(ignore),
    nodes: summary.nodes,
    edges: summary.edges,
  };
};

const status = async (root: string, graphDirectory: string): Promise<JsonObject> => {
  const graphPath = resolve(graphDirectory, 'graph.json');
  const manifestPath = resolve(graphDirectory, 'manifest.json');
  const metadataPath = resolve(graphDirectory, 'oryvin-index.json');
  for (const path of [graphPath, manifestPath, metadataPath]) {
    if (!(await lstat(path).catch(() => undefined))?.isFile()) return { status: 'unavailable', missing: path };
  }
  for (const marker of ['needs_update', '.needs_update']) {
    if (await lstat(resolve(graphDirectory, marker)).catch(() => undefined)) return { status: 'stale', marker };
  }

  const summary = await validateGraph(root, graphPath);
  const manifest = await validateManifest(root, manifestPath);
  const metadata = await readMetadata(metadataPath);
  const canonicalRoot = await realpath(root);
  const current = await buildMetadata(canonicalRoot, graphDirectory, metadata.graphifyVersion, summary);
  const metadataMatches = JSON.stringify(metadata) === JSON.stringify(current);
  const fresh = metadataMatches && manifest.changed.length === 0 && manifest.missingFromManifest.length === 0;
  return {
    status: fresh ? 'fresh' : 'stale',
    coverage: metadata.corpusProfile,
    nodes: summary.nodes,
    edges: summary.edges,
    selfLoops: summary.selfLoops,
    manifestEntries: manifest.entries,
    changed: manifest.changed,
    missingFromManifest: manifest.missingFromManifest,
    metadataMatches,
  };
};

const valueAfter = (flag: string): string => {
  const index = process.argv.indexOf(flag);
  const value = index === -1 ? undefined : process.argv[index + 1];
  if (!value) throw new Error(`missing ${flag}`);
  return value;
};

const optionalValueAfter = (flag: string): string | undefined => {
  const index = process.argv.indexOf(flag);
  return index === -1 ? undefined : process.argv[index + 1];
};

const main = async (): Promise<void> => {
  const operation = process.argv[2];
  const root = await realpath(valueAfter('--root'));
  const requestedGraphDirectory = resolveInside(root, valueAfter('--graph-dir'));
  const graphDirectoryStat = await lstat(requestedGraphDirectory).catch(() => undefined);
  if (operation === 'status' && !graphDirectoryStat?.isDirectory()) {
    console.log(JSON.stringify({ status: 'unavailable', missing: requestedGraphDirectory }));
    process.exitCode = 2;
    return;
  }
  const graphDirectory = await realpath(requestedGraphDirectory);

  if (operation === 'seal') {
    const version = valueAfter('--graphify-version');
    const summary = await validateGraph(root, resolve(graphDirectory, 'graph.json'));
    const previousDirectory = optionalValueAfter('--previous-dir');
    if (previousDirectory) {
      const previousMetadata = await readMetadata(resolve(previousDirectory, 'oryvin-index.json'));
      if (summary.nodes < previousMetadata.nodes && !process.argv.includes('--allow-shrink')) {
        throw new Error(`unexplained graph shrink: previous=${previousMetadata.nodes}, staged=${summary.nodes}`);
      }
    }
    const manifest = await validateManifest(root, resolve(graphDirectory, 'manifest.json'));
    if (manifest.changed.length > 0 || manifest.missingFromManifest.length > 0) {
      throw new Error(`manifest is incomplete: changed=${manifest.changed.length}, missing=${manifest.missingFromManifest.length}`);
    }
    const metadata = await buildMetadata(root, graphDirectory, version, summary);
    await writeFile(resolve(graphDirectory, 'oryvin-index.json'), `${JSON.stringify(metadata, null, 2)}\n`, 'utf8');
    console.log(JSON.stringify({ status: 'sealed', ...metadata, selfLoops: summary.selfLoops }));
    return;
  }

  if (operation === 'status') {
    const result = await status(root, graphDirectory);
    console.log(JSON.stringify(result));
    if (result.status !== 'fresh') process.exitCode = 2;
    return;
  }

  throw new Error(`unknown operation: ${String(operation)}`);
};

await main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
});
