import { createRequire } from 'node:module';

// Load the ecosystem parser only for Svelte inputs; JS/TS checks do not require Svelte.
const require = createRequire(import.meta.url);

export const svelteScriptContents = (content: string): ReadonlyArray<string> => {
  const { parse } = require('svelte/compiler') as {
    parse: (source: string, options: { modern: true }) => {
      instance?: { content: { start: number; end: number } };
      module?: { content: { start: number; end: number } };
    };
  };
  const parsed = parse(content, { modern: true });
  return [parsed.module, parsed.instance]
    .filter((script): script is { content: { start: number; end: number } } => script !== undefined && script !== null)
    .map((script) => content.slice(script.content.start, script.content.end));
};
