import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { dirname, extname, join, relative, resolve, sep } from 'node:path';
import ts from 'typescript';
import { svelteScriptContents } from './svelte-scripts.js';

export type ArchitectureDiagnostic = Readonly<{
  code: string;
  detail: string;
  message: string;
  path: string;
}>;

type ArchitectureBaseline = Readonly<{
  allowedDiagnostics: ReadonlyArray<string>;
  version: 1;
}>;

type FrontendSource = Readonly<{
  absolutePath: string;
  content: string;
  imports: ReadonlyArray<string>;
  path: string;
  sourceFiles: ReadonlyArray<ts.SourceFile>;
}>;

export type ArchitectureEvaluation = Readonly<{
  errors: ReadonlyArray<ArchitectureDiagnostic>;
  known: ReadonlyArray<ArchitectureDiagnostic>;
  staleBaseline: ReadonlyArray<string>;
}>;

const SOURCE_EXTENSIONS = new Set(['.js', '.svelte', '.ts']);
const MAX_FRONTEND_LOCAL_DEPENDENCIES = 10;
const RESOLUTION_EXTENSIONS = ['.ts', '.svelte', '.js'] as const;
const IGNORED_DIRECTORIES = new Set(['.git', '.local', 'dist', 'node_modules', 'target']);
const GENERIC_SHARED_OWNERS = new Set([
  'assets',
  'components',
  'core',
  'helpers',
  'hooks',
  'locale',
  'renderers',
  'services',
  'state',
  'styles',
  'types',
  'utils'
]);

const normalizePath = (path: string): string => path.split(sep).join('/');

const repositoryPath = (root: string, path: string): string => normalizePath(relative(root, path));

const diagnosticIdentity = (diagnostic: ArchitectureDiagnostic): string =>
  `${diagnostic.code}:${diagnostic.path}:${diagnostic.detail}`;

const diagnostic = (
  code: string,
  path: string,
  detail: string,
  message: string
): ArchitectureDiagnostic => ({ code, detail, message, path });

const walkFiles = (directory: string): ReadonlyArray<string> => {
  if (!existsSync(directory)) return [];

  return readdirSync(directory, { withFileTypes: true })
    .sort((left, right) => left.name.localeCompare(right.name))
    .flatMap((entry) => {
      const path = join(directory, entry.name);
      if (entry.isDirectory()) {
        return IGNORED_DIRECTORIES.has(entry.name) ? [] : walkFiles(path);
      }
      return entry.isFile() ? [path] : [];
    });
};

const sourceFile = (content: string, path: string): ts.SourceFile => {
  const parsed = ts.createSourceFile(path, content, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const diagnostics = (parsed as ts.SourceFile & { parseDiagnostics: readonly ts.Diagnostic[] }).parseDiagnostics;
  if (diagnostics.length) throw new Error(`Incomplete frontend parsing: ${path}`);
  return parsed;
};

const svelteScripts = (content: string, path: string): ReadonlyArray<ts.SourceFile> =>
  svelteScriptContents(content).map((script, index) =>
    sourceFile(script, `${path}#script-${index + 1}`)
  );

const parseSourceFiles = (content: string, path: string): ReadonlyArray<ts.SourceFile> =>
  path.endsWith('.svelte') ? svelteScripts(content, path) : [sourceFile(content, path)];

const moduleSpecifiers = (parsedSources: ReadonlyArray<ts.SourceFile>): ReadonlyArray<string> => {
  const imports = new Set<string>();

  const visit = (node: ts.Node): void => {
    if (
      (ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) &&
      node.moduleSpecifier &&
      ts.isStringLiteral(node.moduleSpecifier)
    ) {
      imports.add(node.moduleSpecifier.text);
    }

    if (
      ts.isCallExpression(node) &&
      node.expression.kind === ts.SyntaxKind.ImportKeyword &&
      node.arguments.length === 1 &&
      ts.isStringLiteral(node.arguments[0])
    ) {
      imports.add(node.arguments[0].text);
    }

    ts.forEachChild(node, visit);
  };

  parsedSources.forEach((parsed) => visit(parsed));
  return [...imports].sort();
};

const frontendSources = (root: string): ReadonlyArray<FrontendSource> =>
  walkFiles(join(root, 'src'))
    .filter((path) => SOURCE_EXTENSIONS.has(extname(path)))
    .filter((path) => !/\.(?:spec|test)\.[^.]+$/u.test(path))
    .map((absolutePath) => {
      const path = repositoryPath(root, absolutePath);
      const content = readFileSync(absolutePath, 'utf8');
      const sourceFiles = parseSourceFiles(content, path);
      return {
        absolutePath,
        content,
        imports: moduleSpecifiers(sourceFiles),
        path,
        sourceFiles
      };
    });

const stripImportSuffix = (specifier: string): string => specifier.replace(/[?#].*$/u, '');

const resolutionCandidates = (base: string): ReadonlyArray<string> => {
  const direct = extname(base) ? [base] : [];
  const extensionless = RESOLUTION_EXTENSIONS.map((extension) => `${base}${extension}`);
  const indexFiles = RESOLUTION_EXTENSIONS.map((extension) => join(base, `index${extension}`));
  const sourceMapped = base.endsWith('.js') ? [`${base.slice(0, -3)}.ts`] : [];
  return [...direct, ...sourceMapped, ...extensionless, ...indexFiles];
};

const localImportBase = (
  root: string,
  source: FrontendSource,
  specifier: string
): string | undefined => {
  const cleanSpecifier = stripImportSuffix(specifier);
  if (cleanSpecifier.startsWith('.')) {
    return resolve(dirname(source.absolutePath), cleanSpecifier);
  }
  if (cleanSpecifier === '$lib') return join(root, 'src', 'lib', 'index');
  if (cleanSpecifier.startsWith('$lib/')) {
    return join(root, 'src', 'lib', cleanSpecifier.slice('$lib/'.length));
  }
  return undefined;
};

const resolveLocalImport = (
  root: string,
  source: FrontendSource,
  specifier: string,
  knownPaths: ReadonlySet<string>
): string | undefined => {
  const base = localImportBase(root, source, specifier);
  if (!base) return undefined;

  return resolutionCandidates(base)
    .map((candidate) => repositoryPath(root, candidate))
    .find((candidate) => knownPaths.has(candidate));
};

const dependencyGraph = (
  root: string,
  sources: ReadonlyArray<FrontendSource>
): ReadonlyMap<string, ReadonlyArray<string>> => {
  const knownPaths = new Set(sources.map(({ path }) => path));
  return new Map(
    sources.map((source) => [
      source.path,
      source.imports
        .map((specifier) => resolveLocalImport(root, source, specifier, knownPaths))
        .filter((path): path is string => path !== undefined)
    ])
  );
};

const nonSourceDependencyGraph = (
  root: string,
  sources: ReadonlyArray<FrontendSource>
): ReadonlyMap<string, ReadonlyArray<string>> => {
  const knownPaths = new Set(
    walkFiles(join(root, 'src')).map((absolutePath) => repositoryPath(root, absolutePath))
  );
  return new Map(
    sources.map((source) => [
      source.path,
      source.imports
        .map((specifier) => resolveLocalImport(root, source, specifier, knownPaths))
        .filter(
          (path): path is string => path !== undefined && !SOURCE_EXTENSIONS.has(extname(path))
        )
    ])
  );
};

const stronglyConnectedComponents = (
  graph: ReadonlyMap<string, ReadonlyArray<string>>
): ReadonlyArray<ReadonlyArray<string>> => {
  let nextIndex = 0;
  const indices = new Map<string, number>();
  const lowLinks = new Map<string, number>();
  const active = new Set<string>();
  const stack: string[] = [];
  const components: string[][] = [];

  const visit = (node: string): void => {
    const index = nextIndex++;
    indices.set(node, index);
    lowLinks.set(node, index);
    stack.push(node);
    active.add(node);

    for (const target of graph.get(node) ?? []) {
      if (!indices.has(target)) {
        visit(target);
        lowLinks.set(node, Math.min(lowLinks.get(node) ?? index, lowLinks.get(target) ?? index));
      } else if (active.has(target)) {
        lowLinks.set(node, Math.min(lowLinks.get(node) ?? index, indices.get(target) ?? index));
      }
    }

    if (lowLinks.get(node) !== indices.get(node)) return;

    const component: string[] = [];
    let current: string | undefined;
    do {
      current = stack.pop();
      if (!current) break;
      active.delete(current);
      component.push(current);
    } while (current !== node);
    components.push(component.sort());
  };

  [...graph.keys()].sort().forEach((node) => {
    if (!indices.has(node)) visit(node);
  });
  return components;
};

const cycleDiagnostics = (
  graph: ReadonlyMap<string, ReadonlyArray<string>>
): ReadonlyArray<ArchitectureDiagnostic> =>
  stronglyConnectedComponents(graph)
    .filter((component) => {
      if (component.length > 1) return true;
      const [node] = component;
      return (graph.get(node) ?? []).includes(node);
    })
    .map((component) => {
      const members = component.join(' -> ');
      return diagnostic(
        'frontend-cycle',
        component[0],
        members,
        `ciclo de imports detectado: ${members}`
      );
    });

const dependencyFanOutDiagnostics = (
  graph: ReadonlyMap<string, ReadonlyArray<string>>,
  nonSourceGraph: ReadonlyMap<string, ReadonlyArray<string>>
): ReadonlyArray<ArchitectureDiagnostic> =>
  [...graph.entries()].flatMap(([path, targets]) => {
    const count = new Set([...targets, ...(nonSourceGraph.get(path) ?? [])]).size;
    if (count <= MAX_FRONTEND_LOCAL_DEPENDENCIES) return [];
    return [
      diagnostic(
        'frontend-dependency-fan-out',
        path,
        `count=${count}`,
        `módulo possui ${count} dependências locais; máximo permitido é ${MAX_FRONTEND_LOCAL_DEPENDENCIES}`
      )
    ];
  });

const domainOwner = (path: string): string | undefined =>
  path.match(/^src\/domains\/([^/]+)\//u)?.[1];

const isDomainRoute = (path: string): boolean => /^src\/domains\/[^/]+\/routes\//u.test(path);

const routeTargetIsAllowed = (target: string): boolean =>
  target.startsWith('src/routes/') ||
  isDomainRoute(target) ||
  /^src\/app\/[^/]+\/(?:components|routes)\//u.test(target);

type EdgeRule = (source: string, target: string) => ArchitectureDiagnostic | undefined;

const sharedDependencyRule: EdgeRule = (source, target) => {
  if (!source.startsWith('src/shared/')) return undefined;
  if (!/^(?:src\/app|src\/domains|src\/routes)\//u.test(target)) return undefined;
  return diagnostic(
    'shared-dependency-direction',
    source,
    target,
    `owner compartilhado não pode depender de ${target}`
  );
};

const routeTargetRule: EdgeRule = (source, target) => {
  if (!source.startsWith('src/routes/') || routeTargetIsAllowed(target)) return undefined;
  return diagnostic(
    'route-adapter-target',
    source,
    target,
    `adapter SvelteKit aponta para owner não permitido: ${target}`
  );
};

const domainRouteRule: EdgeRule = (source, target) => {
  if (!domainOwner(source) || !target.startsWith('src/routes/')) return undefined;
  return diagnostic(
    'domain-depends-on-route-adapter',
    source,
    target,
    `domínio não pode depender do adapter ${target}`
  );
};

const domainAppRule: EdgeRule = (source, target) => {
  if (!domainOwner(source) || !target.startsWith('src/app/')) return undefined;
  if (target.startsWith('src/app/locale/')) return undefined;
  return diagnostic(
    'domain-depends-on-app-composition',
    source,
    target,
    `domínio só pode consumir o owner global de locale, não ${target}`
  );
};

const crossDomainRule: EdgeRule = (source, target) => {
  const sourceDomain = domainOwner(source);
  const targetDomain = domainOwner(target);
  if (!sourceDomain || !targetDomain || sourceDomain === targetDomain) return undefined;
  if (isDomainRoute(source)) return undefined;
  return diagnostic(
    'cross-domain-dependency',
    source,
    target,
    `dependência entre domínios deve partir de um route composer: ${target}`
  );
};

const appRouteRule: EdgeRule = (source, target) => {
  if (!source.startsWith('src/app/') || !target.startsWith('src/routes/')) return undefined;
  return diagnostic(
    'app-depends-on-route-adapter',
    source,
    target,
    `owner global não pode depender do adapter ${target}`
  );
};

const EDGE_RULES: ReadonlyArray<EdgeRule> = [
  sharedDependencyRule,
  routeTargetRule,
  domainRouteRule,
  domainAppRule,
  crossDomainRule,
  appRouteRule
];

const edgeDiagnostics = (
  graph: ReadonlyMap<string, ReadonlyArray<string>>
): ReadonlyArray<ArchitectureDiagnostic> =>
  [...graph.entries()].flatMap(([source, targets]) =>
    targets.flatMap((target) =>
      EDGE_RULES.map((rule) => rule(source, target)).filter(
        (finding): finding is ArchitectureDiagnostic => finding !== undefined
      )
    )
  );

const crossDomainNonSourceDiagnostics = (
  graph: ReadonlyMap<string, ReadonlyArray<string>>
): ReadonlyArray<ArchitectureDiagnostic> =>
  [...graph.entries()].flatMap(([source, targets]) =>
    targets
      .map((target) => crossDomainRule(source, target))
      .filter((finding): finding is ArchitectureDiagnostic => finding !== undefined)
  );

const routeContentDiagnostics = (
  sources: ReadonlyArray<FrontendSource>
): ReadonlyArray<ArchitectureDiagnostic> =>
  sources
    .filter(({ path }) => path.startsWith('src/routes/'))
    .flatMap(({ content, imports, path }) => {
      const findings: ArchitectureDiagnostic[] = [];
      const forbiddenImports = imports.filter(
        (specifier) =>
          /^(?:\.|\$lib\/)/u.test(specifier) &&
          /(?:^|\/)(?:renderers|services|state)(?:\/|$)/u.test(specifier)
      );

      forbiddenImports.forEach((specifier) => {
        findings.push(
          diagnostic(
            'route-adapter-workflow-import',
            path,
            specifier,
            `adapter SvelteKit importa workflow diretamente: ${specifier}`
          )
        );
      });

      if (/\$state(?:\.raw)?\s*\(/u.test(content)) {
        findings.push(
          diagnostic(
            'route-adapter-state',
            path,
            '$state',
            'adapter SvelteKit contém estado de workflow'
          )
        );
      }
      if (/import\s*\{[^}]*\bonMount\b[^}]*\}\s*from\s*['"]svelte['"]/su.test(content)) {
        findings.push(
          diagnostic(
            'route-adapter-lifecycle',
            path,
            'onMount',
            'adapter SvelteKit contém lifecycle'
          )
        );
      }
      if (
        imports.includes('@tauri-apps/api/core') ||
        /\binvoke\s*(?:<[^>]+>)?\s*\(/u.test(content)
      ) {
        findings.push(
          diagnostic('route-adapter-invoke', path, 'invoke', 'adapter SvelteKit contém IPC direto')
        );
      }
      return findings;
    });

const invokeCommands = (source: FrontendSource): ReadonlyArray<string> => {
  const commands = new Set<string>();
  const visit = (node: ts.Node): void => {
    if (
      ts.isCallExpression(node) &&
      ts.isIdentifier(node.expression) &&
      node.expression.text === 'invoke' &&
      node.arguments.length > 0 &&
      ts.isStringLiteral(node.arguments[0])
    ) {
      commands.add(node.arguments[0].text);
    }
    ts.forEachChild(node, visit);
  };
  source.sourceFiles.forEach((parsed) => visit(parsed));
  return [...commands].sort();
};

const invokeDiagnostics = (
  sources: ReadonlyArray<FrontendSource>
): ReadonlyArray<ArchitectureDiagnostic> => {
  const findings: ArchitectureDiagnostic[] = [];
  const owners = new Map<string, string[]>();
  const canonicalTransport = 'src/shared/ipc/services/invokeParsedCommand.ts';

  for (const source of sources) {
    const importsInvoke =
      source.imports.includes('@tauri-apps/api/core') && /\binvoke\b/u.test(source.content);
    if (importsInvoke && !/(?:^|\/)services\//u.test(source.path)) {
      findings.push(
        diagnostic(
          'invoke-outside-service',
          source.path,
          '@tauri-apps/api/core',
          'invoke deve permanecer em um service tipado'
        )
      );
    }
    if (importsInvoke && source.path !== canonicalTransport) {
      findings.push(
        diagnostic(
          'raw-invoke-outside-canonical-transport',
          source.path,
          '@tauri-apps/api/core',
          `invoke direto pertence somente a ${canonicalTransport}`
        )
      );
    }

    invokeCommands(source).forEach((command) => {
      owners.set(command, [...(owners.get(command) ?? []), source.path]);
    });
  }

  for (const [command, paths] of owners) {
    const uniquePaths = [...new Set(paths)].sort();
    if (uniquePaths.length < 2) continue;
    findings.push(
      diagnostic(
        'duplicate-invoke-owner',
        uniquePaths[0],
        `${command}:${uniquePaths.join(',')}`,
        `comando ${command} possui wrappers duplicados: ${uniquePaths.join(', ')}`
      )
    );
  }
  return findings;
};

const sharedOwnerDiagnostics = (root: string): ReadonlyArray<ArchitectureDiagnostic> => {
  const shared = join(root, 'src', 'shared');
  if (!existsSync(shared)) return [];

  return readdirSync(shared, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && GENERIC_SHARED_OWNERS.has(entry.name))
    .map((entry) =>
      diagnostic(
        'generic-shared-owner',
        `src/shared/${entry.name}`,
        entry.name,
        `src/shared deve ser owner-first; agrupador genérico encontrado: ${entry.name}`
      )
    );
};

export const collectArchitectureDiagnostics = (
  root: string
): ReadonlyArray<ArchitectureDiagnostic> => {
  if (existsSync(join(root, 'Cargo.toml')) || existsSync(join(root, 'src-tauri', 'Cargo.toml'))) {
    throw new Error('Frontend adapter only: select a frontend source root and configure a separate native Rust architecture task. Rust regex validation was retired.');
  }
  const sources = frontendSources(root);
  if (sources.length === 0) throw new Error('No supported frontend sources found; architecture analysis incomplete');
  const graph = dependencyGraph(root, sources);
  const nonSourceGraph = nonSourceDependencyGraph(root, sources);
  return [
    ...cycleDiagnostics(graph),
    ...dependencyFanOutDiagnostics(graph, nonSourceGraph),
    ...edgeDiagnostics(graph),
    ...crossDomainNonSourceDiagnostics(nonSourceGraph),
    ...routeContentDiagnostics(sources),
    ...invokeDiagnostics(sources),
    ...sharedOwnerDiagnostics(root)
  ].sort(
    (left, right) =>
      left.path.localeCompare(right.path) ||
      left.code.localeCompare(right.code) ||
      left.detail.localeCompare(right.detail)
  );
};

const diagnosticIsKnown = (
  finding: ArchitectureDiagnostic,
  allowed: ReadonlySet<string>
): boolean => {
  if (finding.code === 'frontend-dependency-fan-out') return false;
  return allowed.has(diagnosticIdentity(finding));
};

export const evaluateArchitectureDiagnostics = (
  diagnostics: ReadonlyArray<ArchitectureDiagnostic>,
  allowedDiagnostics: ReadonlyArray<string>
): ArchitectureEvaluation => {
  const allowed = new Set(allowedDiagnostics);
  const present = new Set(diagnostics.map(diagnosticIdentity));
  const isKnown = (finding: ArchitectureDiagnostic): boolean => diagnosticIsKnown(finding, allowed);
  return {
    errors: diagnostics.filter((finding) => !isKnown(finding)),
    known: diagnostics.filter(isKnown),
    staleBaseline: [...allowed].filter((identity) => !present.has(identity)).sort()
  };
};

const readBaseline = (path: string): ArchitectureBaseline => {
  const value: unknown = JSON.parse(readFileSync(path, 'utf8'));
  if (
    typeof value !== 'object' ||
    value === null ||
    !('version' in value) ||
    value.version !== 1 ||
    !('allowedDiagnostics' in value) ||
    !Array.isArray(value.allowedDiagnostics) ||
    !value.allowedDiagnostics.every((entry) => typeof entry === 'string')
  ) {
    throw new Error(`baseline arquitetural inválido: ${path}`);
  }
  return value as ArchitectureBaseline;
};

const run = (): void => {
  const root = resolve(import.meta.dir, '../../..');
  const baselinePath = join(import.meta.dir, '../baselines/architecture.json');
  const baseline = readBaseline(baselinePath);
  const evaluation = evaluateArchitectureDiagnostics(
    collectArchitectureDiagnostics(root),
    baseline.allowedDiagnostics
  );

  evaluation.known.forEach((finding) => {
    console.log(`WARN ${finding.code} ${finding.path}: ${finding.message} [baseline]`);
  });
  evaluation.staleBaseline.forEach((identity) => {
    console.log(`INFO baseline arquitetural pode ser reduzido: ${identity}`);
  });
  evaluation.errors.forEach((finding) => {
    console.error(`ERROR ${finding.code} ${finding.path}: ${finding.message}`);
  });

  console.log(
    `Architecture guard: ${evaluation.errors.length} error(s), ${evaluation.known.length} baseline warning(s).`
  );
  process.exitCode = evaluation.errors.length === 0 ? 0 : 1;
};

if (import.meta.main) run();
