#!/usr/bin/env bash
set -euo pipefail
# Project root/config are explicit CLI arguments. Original contract: baseline.tar.gz.
LIBRARY_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
exec python3 "$LIBRARY_DIR/automate.py" run --task setup-git-hooks "$@"
