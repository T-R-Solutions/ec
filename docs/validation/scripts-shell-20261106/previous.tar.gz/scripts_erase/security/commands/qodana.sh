#!/usr/bin/env bash

set -uo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../../.." && pwd)"
JS_QODANA_IMAGE="oryvin-nexus/qodana-js:2026.2"
RUST_QODANA_IMAGE="oryvin-nexus/qodana-rust:2026.2-eap"
JS_QODANA_DOCKERFILE="scripts/checks/security/containers/qodana/ts.Dockerfile"
RUST_QODANA_DOCKERFILE="scripts/checks/security/containers/qodana/rust.Dockerfile"
RUST_PROJECT_DIR="src-tauri"
RUST_QODANA_CONFIG="qodana.yaml"
JS_BASELINE="qodana-js-baseline.sarif.json"
EXPECTED_QODANA_SERIES="2026.2"
source "$ROOT_DIR/scripts/lib/failure-log.sh"

TEMP_ROOT="$ROOT_DIR/.local/tmp/qodana"
mkdir -p "$TEMP_ROOT"
RUN_DIR="$(mktemp -d "$TEMP_ROOT/run.XXXXXX")"
JS_OUTPUT_ROOT="$RUN_DIR/js"
RUST_OUTPUT_ROOT="$RUN_DIR/rust"
JS_COVERAGE_DIR="$JS_OUTPUT_ROOT/coverage"
JS_LOG="$RUN_DIR/qodana-js.log"
RUST_LOG="$RUN_DIR/qodana-rust.log"
EVIDENCE_ROOT="$ROOT_DIR/.local/evidence/qodana"

normalize_qodana_run_ownership() {
  if [ ! -d "$RUN_DIR" ]; then
    return 0
  fi

  # The Rust IDE must run as root, so normalize every mounted artifact before
  # the host copies evidence or removes the per-run staging directory.
  docker run \
    --rm \
    --user root \
    --volume "$RUN_DIR:/qodana-run" \
    --entrypoint chown "$RUST_QODANA_IMAGE" \
    -R "$(id -u):$(id -g)" /qodana-run \
    >/dev/null 2>&1 || true
}

cleanup_qodana_run() {
  if [ ! -d "$RUN_DIR" ]; then
    return 0
  fi

  normalize_qodana_run_ownership
  rm -rf -- "$RUN_DIR"
}

trap cleanup_qodana_run EXIT

mkdir -p \
  "$JS_OUTPUT_ROOT/results" \
  "$JS_OUTPUT_ROOT/cache" \
  "$JS_OUTPUT_ROOT/reports" \
  "$JS_OUTPUT_ROOT/tmp" \
  "$RUST_OUTPUT_ROOT/results" \
  "$RUST_OUTPUT_ROOT/cache" \
  "$RUST_OUTPUT_ROOT/reports" \
  "$RUST_OUTPUT_ROOT/tmp"

cd "$ROOT_DIR"

require_qodana() {
  local token="$1"
  local token_name="$2"

  if [ -z "$token" ]; then
    echo "ERRO: defina $token_name com o token do projeto Qodana." >&2
    return 2
  fi

  if ! command -v qodana >/dev/null 2>&1; then
    echo "ERRO: comando nao encontrado: qodana" >&2
    return 127
  fi

  if ! command -v jq >/dev/null 2>&1; then
    echo "ERRO: comando nao encontrado: jq" >&2
    return 127
  fi

  local qodana_version
  qodana_version="$(qodana -v)"
  if [[ "$qodana_version" != *" $EXPECTED_QODANA_SERIES."* ]]; then
    echo "ERRO: Qodana CLI $EXPECTED_QODANA_SERIES.x e obrigatorio; encontrado: $qodana_version" >&2
    return 1
  fi
}

require_clean_rust_sanity() {
  local sanity_report="$RUST_OUTPUT_ROOT/reports/results/sanity.json"

  if [ ! -s "$sanity_report" ]; then
    echo "ERRO: Qodana Rust nao produziu o relatorio de sanidade esperado." >&2
    return 1
  fi

  if ! jq -e '.listProblem | length == 0' "$sanity_report" >/dev/null; then
    echo "ERRO: Qodana Rust reportou problemas de sanidade; o gate permanece inconclusivo." >&2
    return 1
  fi
}

publish_qodana_failure_evidence() {
  local language="$1"
  local output_root="$2"
  local exit_code="$3"

  if [ "$exit_code" -eq 0 ]; then
    return 0
  fi

  normalize_qodana_run_ownership

  local timestamp
  local destination
  local relative_path
  local copied=0
  timestamp="$(date '+%Y%m%d_%H%M%S_%N')"
  destination="$EVIDENCE_ROOT/${language}-${timestamp}-$$"

  for relative_path in \
    reports/results/qodana.sarif.json \
    reports/results/sanity.json \
    reports/results/metaInformation.json; do
    if [ ! -s "$output_root/$relative_path" ]; then
      continue
    fi

    if [ "$copied" -eq 0 ]; then
      mkdir -p "$destination" || return 1
    fi
    cp -- "$output_root/$relative_path" "$destination/$(basename "$relative_path")" || return 1
    copied=1
  done

  if [ -d "$output_root/reports/results/projectStructure" ]; then
    if [ "$copied" -eq 0 ]; then
      mkdir -p "$destination" || return 1
    fi
    cp -R -- "$output_root/reports/results/projectStructure" "$destination/projectStructure" || return 1
    copied=1
  fi

  if [ "$copied" -eq 0 ]; then
    return 0
  fi

  {
    printf 'language=%s\n' "$language"
    printf 'exit_code=%s\n' "$exit_code"
    printf 'qodana_cli=%s\n' "$(qodana -v)"
  } > "$destination/run.txt" || return 1

  echo "Evidencia estruturada Qodana: $destination" >&2
}

run_javascript_qodana() {
  require_qodana "${QODANA_ORYVIN_JS_TOKEN:-}" "QODANA_ORYVIN_JS_TOKEN" || return $?

  if [ ! -s "$ROOT_DIR/$JS_BASELINE" ]; then
    echo "ERRO: baseline Qodana JS ausente ou vazia: $JS_BASELINE" >&2
    return 1
  fi

  echo "Executando analise Qodana JavaScript..."
  ORYVIN_COVERAGE_OUTPUT_DIR="$JS_COVERAGE_DIR" \
    ORYVIN_KEEP_COVERAGE=1 \
    "$ROOT_DIR/scripts/checks/frontend/commands/coverage.sh" || return $?

  docker build \
    --pull \
    --file "$JS_QODANA_DOCKERFILE" \
    --tag "$JS_QODANA_IMAGE" \
    scripts/checks/security/containers/qodana || return $?

  TMPDIR="$JS_OUTPUT_ROOT/tmp" QODANA_TOKEN="$QODANA_ORYVIN_JS_TOKEN" qodana scan \
    --config qodana-js.yaml \
    --image "$JS_QODANA_IMAGE" \
    --skip-pull \
    --coverage-dir "$JS_COVERAGE_DIR" \
    --results-dir "$JS_OUTPUT_ROOT/results" \
    --cache-dir "$JS_OUTPUT_ROOT/cache" \
    --report-dir "$JS_OUTPUT_ROOT/reports" \
    --baseline "$JS_BASELINE" \
    --print-problems \
    --log-level info
}

run_rust_qodana() {
  require_qodana "${QODANA_ORYVIN_RUST_TOKEN:-}" "QODANA_ORYVIN_RUST_TOKEN" || return $?

  echo "Executando analise Qodana Rust..."
  docker build \
    --pull \
    --file "$RUST_QODANA_DOCKERFILE" \
    --tag "$RUST_QODANA_IMAGE" \
    scripts/checks/security/containers/qodana || return $?

  # RustRover EAP requires root for its internal IDE directories; Docker remaps it.
  local scan_status
  TMPDIR="$RUST_OUTPUT_ROOT/tmp" QODANA_TOKEN="$QODANA_ORYVIN_RUST_TOKEN" qodana scan \
    --project-dir "$RUST_PROJECT_DIR" \
    --repository-root "$ROOT_DIR" \
    --config "$RUST_QODANA_CONFIG" \
    --image "$RUST_QODANA_IMAGE" \
    --skip-pull \
    --results-dir "$RUST_OUTPUT_ROOT/results" \
    --cache-dir "$RUST_OUTPUT_ROOT/cache" \
    --report-dir "$RUST_OUTPUT_ROOT/reports" \
    --property=idea.headless.enable.statistics=false \
    --user root \
    -e CARGO_HOME=/data/cache/cargo \
    -e CARGO_TARGET_DIR=/data/cache/cargo-target \
    -e XDG_RUNTIME_DIR=/tmp/qodana-runtime-root \
    --print-problems \
    --log-level info
  scan_status=$?

  if [ "$scan_status" -ne 0 ]; then
    return "$scan_status"
  fi

  require_clean_rust_sanity
}

run_javascript_qodana 2>&1 | tee "$JS_LOG"
js_status=${PIPESTATUS[0]}

run_rust_qodana 2>&1 | tee "$RUST_LOG"
rust_status=${PIPESTATUS[0]}

publish_qodana_failure_evidence "javascript" "$JS_OUTPUT_ROOT" "$js_status"
js_evidence_status=$?
publish_qodana_failure_evidence "rust" "$RUST_OUTPUT_ROOT" "$rust_status"
rust_evidence_status=$?

publish_issue_log "$ROOT_DIR" "qodana/js" "$JS_LOG" "$js_status"
js_publish_status=$?
publish_issue_log "$ROOT_DIR" "qodana/rust" "$RUST_LOG" "$rust_status"
rust_publish_status=$?

echo
echo "Resultado Qodana:"
echo "  JavaScript: codigo $js_status"
echo "  Rust:       codigo $rust_status"

if [ "$js_evidence_status" -ne 0 ] || [ "$rust_evidence_status" -ne 0 ] || \
  [ "$js_publish_status" -ne 0 ] || [ "$rust_publish_status" -ne 0 ]; then
  exit 2
fi

if [ "$js_status" -ne 0 ] || [ "$rust_status" -ne 0 ]; then
  exit 1
fi
