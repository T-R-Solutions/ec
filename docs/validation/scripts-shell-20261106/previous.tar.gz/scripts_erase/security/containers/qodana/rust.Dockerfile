FROM jetbrains/qodana-rust:2026.2-eap

USER root

RUN apt-get update \
    && DEBIAN_FRONTEND=noninteractive apt-get install --yes --no-install-recommends \
        build-essential \
        libayatana-appindicator3-dev \
        libdbus-1-dev \
        librsvg2-dev \
        libssl-dev \
        libwebkit2gtk-4.1-dev \
        libxdo-dev \
        pkg-config \
    && rm -rf /var/lib/apt/lists/* \
    && install -d --owner=root --group=root --mode=0700 /tmp/qodana-runtime-root

USER 1000:1000
