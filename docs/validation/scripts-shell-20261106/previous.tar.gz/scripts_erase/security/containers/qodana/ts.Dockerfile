FROM jetbrains/qodana-js:2026.2

USER 1000:1000
