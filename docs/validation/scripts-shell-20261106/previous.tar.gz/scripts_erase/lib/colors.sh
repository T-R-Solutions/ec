#!/usr/bin/env bash

if [ -n "${NO_COLOR:-}" ]; then
  ORYVIN_COLOR_BLUE=''
  ORYVIN_COLOR_RED=''
  ORYVIN_COLOR_GREEN=''
  ORYVIN_COLOR_ORANGE=''
  ORYVIN_COLOR_BLACK=''
  ORYVIN_BACKGROUND_ORANGE=''
  ORYVIN_COLOR_BOLD=''
  ORYVIN_COLOR_RESET=''
elif [ "${ORYVIN_FORCE_COLOR:-0}" = "1" ] || { [ "${TERM:-}" != "dumb" ] && [ -t 1 ]; }; then
  ORYVIN_COLOR_BLUE=$'\033[1;34m'
  ORYVIN_COLOR_RED=$'\033[1;31m'
  ORYVIN_COLOR_GREEN=$'\033[1;32m'
  ORYVIN_COLOR_ORANGE=$'\033[38;5;208m'
  ORYVIN_COLOR_BLACK=$'\033[30m'
  ORYVIN_BACKGROUND_ORANGE=$'\033[48;5;208m'
  ORYVIN_COLOR_BOLD=$'\033[1m'
  ORYVIN_COLOR_RESET=$'\033[0m'
else
  ORYVIN_COLOR_BLUE=''
  ORYVIN_COLOR_RED=''
  ORYVIN_COLOR_GREEN=''
  ORYVIN_COLOR_ORANGE=''
  ORYVIN_COLOR_BLACK=''
  ORYVIN_BACKGROUND_ORANGE=''
  ORYVIN_COLOR_BOLD=''
  ORYVIN_COLOR_RESET=''
fi

readonly ORYVIN_COLOR_BLUE ORYVIN_COLOR_RED ORYVIN_COLOR_GREEN ORYVIN_COLOR_ORANGE
readonly ORYVIN_COLOR_BLACK ORYVIN_BACKGROUND_ORANGE ORYVIN_COLOR_BOLD ORYVIN_COLOR_RESET

oryvin_color_line() {
  local color="$1"
  shift
  printf '%b%s%b\n' "$color" "$*" "$ORYVIN_COLOR_RESET"
}

oryvin_log_rule() {
  oryvin_color_line "$ORYVIN_COLOR_BLUE" "========================================"
}

oryvin_log_step() {
  printf '%b %s %b\n' \
    "${ORYVIN_COLOR_BOLD}${ORYVIN_COLOR_BLACK}${ORYVIN_BACKGROUND_ORANGE}" \
    "$*" \
    "$ORYVIN_COLOR_RESET"
}

oryvin_log_info() {
  oryvin_color_line "$ORYVIN_COLOR_BLUE" "$*"
}

oryvin_log_success() {
  oryvin_color_line "$ORYVIN_COLOR_GREEN" "$*"
}

oryvin_log_warning() {
  oryvin_color_line "$ORYVIN_COLOR_ORANGE" "$*"
}

oryvin_log_error() {
  oryvin_color_line "$ORYVIN_COLOR_RED" "$*"
}

oryvin_log_error_rule() {
  oryvin_color_line "$ORYVIN_COLOR_RED" "========================================"
}
