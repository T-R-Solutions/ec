#!/usr/bin/env bash

prune_log_entries() {
  local logs_root="$1"
  local log_directory="$2"
  local maximum_entries="${3:-2}"
  local resolved_root
  local resolved_directory
  local excess_count
  local entry
  local index
  local -a entries=()

  resolved_root="$(realpath "$logs_root")"
  resolved_directory="$(realpath "$log_directory")"

  if [ "$resolved_directory" = "$resolved_root" ]; then
    echo "ERRO: a retencao nao pode remover entradas da raiz de logs." >&2
    return 2
  fi

  case "$resolved_directory" in
    "$resolved_root"/*) ;;
    *)
      echo "ERRO: pasta de logs fora da raiz permitida: $resolved_directory" >&2
      return 2
      ;;
  esac

  if ! [[ "$maximum_entries" =~ ^[1-9][0-9]*$ ]]; then
    echo "ERRO: limite de retencao invalido: $maximum_entries" >&2
    return 2
  fi

  mapfile -d '' entries < <(
    find "$resolved_directory" -mindepth 1 -maxdepth 1 -printf '%T@ %p\0' \
      | sort -z -n
  )

  excess_count=$((${#entries[@]} - maximum_entries))
  if [ "$excess_count" -le 0 ]; then
    return 0
  fi

  for ((index = 0; index < excess_count; index++)); do
    entry="${entries[$index]#* }"
    rm -rf -- "$entry"
  done
}
