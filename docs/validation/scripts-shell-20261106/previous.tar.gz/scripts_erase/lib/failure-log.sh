#!/usr/bin/env bash

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/log-retention.sh"

issue_log_owner_is_valid() {
  local owner="$1"

  [[ "$owner" =~ ^[a-z0-9][a-z0-9_-]*$ ]] ||
    [[ "$owner" =~ ^qodana/(js|rust)$ ]]
}

issue_log_has_issue() {
  local signal_log="$1"
  local issue_pattern
  local non_issue_pattern

  # Mensagens diagnosticas usam a palavra-sinal como token. Nomes de artefato como
  # `fallbacks/error.svelte.js` nao sao diagnosticos e nao devem publicar falso issue.
  issue_pattern='(^|[[:space:]])(warnings?|warn|errors?|err|fails?|failed|failures?|panic|denied|rejected|aborted|avisos?|erros?|falhou)([[:space:]:=,]|$)'
  non_issue_pattern='(^|[[:space:]])(0|no|none|nenhum|nenhuma|nenhuns|nenhumas)[[:space:]]+(known[[:space:]]+)?(warnings?|errors?|fails?|failures?|vulnerabilities?|issues?|avisos?|erros?)([[:space:][:punct:]]|$)|(warnings?|errors?|fails?|failures?|vulnerabilities?|issues?|avisos?|erros?)[[:space:]]*[:=][[:space:]]*0([[:space:][:punct:]]|$)'

  grep -Eiv "$non_issue_pattern" "$signal_log" |
    grep -Eiq "$issue_pattern"
}

publish_issue_log() {
  local project_root="$1"
  local owner="$2"
  local evidence_log="$3"
  local exit_code="$4"
  local signal_log="${5:-$evidence_log}"

  if ! issue_log_owner_is_valid "$owner"; then
    echo "ERRO: owner de log invalido: $owner" >&2
    return 2
  fi

  if ! [[ "$exit_code" =~ ^[0-9]+$ ]]; then
    echo "ERRO: codigo de saida invalido para log: $exit_code" >&2
    return 2
  fi

  if [ ! -f "$evidence_log" ] || [ ! -f "$signal_log" ]; then
    echo "ERRO: evidencia temporaria de log ausente." >&2
    return 2
  fi

  if [ "$exit_code" -eq 0 ] && ! issue_log_has_issue "$signal_log"; then
    return 0
  fi

  local logs_root="$project_root/.local/logs"
  local owner_directory="$logs_root/$owner"
  local owner_name="${owner##*/}"
  local timestamp
  local destination

  timestamp="$(date '+%Y%m%d_%H%M%S_%N')"
  destination="$owner_directory/${owner_name}-${timestamp}-$$.log"

  mkdir -p "$owner_directory"
  {
    printf '\n[oryvin-log]\n'
    printf 'owner=%s\n' "$owner"
    printf 'exit_code=%s\n' "$exit_code"
  } >> "$evidence_log"
  mv -- "$evidence_log" "$destination"
  prune_log_entries "$logs_root" "$owner_directory" 2

  echo "Log de issue: $destination" >&2
}

capture_failure_log() {
  local project_root="$1"
  local owner="$2"
  shift 2

  if ! issue_log_owner_is_valid "$owner"; then
    echo "ERRO: owner de log invalido: $owner" >&2
    return 2
  fi

  local temporary_log
  local exit_code
  local temporary_root="$project_root/.local/tmp/failure-log"
  local errexit_was_enabled=0

  mkdir -p "$temporary_root"
  temporary_log="$(mktemp "$temporary_root/oryvin-${owner##*/}.XXXXXX.log")"

  if [[ $- == *e* ]]; then
    errexit_was_enabled=1
  fi

  set +e
  "$@" 2>&1 | tee "$temporary_log"
  exit_code=${PIPESTATUS[0]}
  if [ "$errexit_was_enabled" -eq 1 ]; then
    set -e
  fi

  publish_issue_log "$project_root" "$owner" "$temporary_log" "$exit_code"
  local publish_exit=$?
  if [ "$publish_exit" -ne 0 ]; then
    rm -f -- "$temporary_log"
    return "$publish_exit"
  fi

  rm -f -- "$temporary_log"
  return "$exit_code"
}
