import { mkdirSync, mkdtempSync } from 'node:fs';
import { join, resolve } from 'node:path';

export const repositoryRoot = resolve(import.meta.dir, '../..');

export const createProjectTestTempDirectory = (owner: string): string => {
  const ownerRoot = join(repositoryRoot, '.local', 'tests', owner);
  mkdirSync(ownerRoot, { recursive: true });
  return mkdtempSync(join(ownerRoot, 'run-'));
};
