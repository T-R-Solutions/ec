#!/usr/bin/env bash

ORYVIN_BUN_TMP_DIR="$ROOT_DIR/.local/tmp/bun"
mkdir -p -- "$ORYVIN_BUN_TMP_DIR"
export TMPDIR="$ORYVIN_BUN_TMP_DIR"

resolve_bun_bin() {
  local candidate="${BUN_BIN:-}"

  if [ -z "$candidate" ]; then
    candidate="$(command -v bun || true)"
  fi

  if [ -z "$candidate" ] && [ -x "$HOME/.bun/bin/bun" ]; then
    candidate="$HOME/.bun/bin/bun"
  fi

  if [ -z "$candidate" ]; then
    echo "ERRO: Bun nao encontrado. Instale Bun ou defina BUN_BIN." >&2
    return 127
  fi

  printf '%s\n' "$candidate"
}
