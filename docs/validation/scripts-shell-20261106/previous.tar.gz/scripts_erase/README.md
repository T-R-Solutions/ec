# Biblioteca de scripts

Automação organizada por tecnologia e responsabilidade. Este catálogo descreve os
arquivos ativos, seus cenários e pré-requisitos; mudar uma pasta não torna regras
específicas de um produto automaticamente válidas em outro.

## Escolher o caminho de execução

```mermaid
flowchart TD
    A[Escolher raiz e projetos] --> B[automate.py plan]
    B --> C{Configuração revisada?}
    C -->|Não| D[Revisar comandos, políticas, ferramentas e hashes]
    D --> B
    C -->|Sim| E[automate.py run]
    E --> F[Núcleo Python: validar pré-requisitos]
    F --> G{Disponíveis e íntegros?}
    G -->|Não| H[Bloqueado ou erro]
    G -->|Sim| I[Adapter de tecnologia ou segurança]
    I --> J[Executar com limites e preservar logs]
    J --> K[Parser e política]
    K --> L[Aprovado / achados / erro / bloqueado / não aplicável / omitido]
    L --> M[results.json]
    M --> N[reports/summarize.py]
    classDef shared fill:#e8f0ff,stroke:#3158a6,color:#182a4d
    classDef task fill:#e6f5ed,stroke:#28724f,color:#173d2b
    classDef result fill:#fff2dd,stroke:#ad7420,color:#583c13
    class B,E,F shared
    class I,J,K task
    class H,L,M,N result
```

Python 3.11+ e stdlib são suficientes para o núcleo e os validadores genéricos.
A supervisão de processos é suportada/observada em Linux x86_64. Os adapters de
frontend que usam a API do compilador continuam em TypeScript; Node/Bun não são
requisito de governança, relatórios ou Rust isolado. PowerShell e ferramentas
nativas só são exigidos nos respectivos cenários.

## Uso inicial

Comandos a partir da raiz da biblioteca; a raiz de projeto pode ser outro diretório:

```bash
python3 scripts/automate.py plan --root /caminho/projeto --profile quick
python3 scripts/automate.py run --root /caminho/projeto --config automation.toml --profile quick
bash scripts/rust/commands/fmt.sh --root /caminho/projeto --config automation.toml
python3 scripts/reports/summarize.py /caminho/projeto/.local/automation/runs/run-ID/results.json
```

`plan` não executa comandos encontrados. `run` exige `--config` relativo à raiz,
sem travessia/symlinks. Exemplos em [automation/examples](automation/examples/).
Pins fictícios precisam ser substituídos após revisão. `--task` executa a seleção
pedida e não representa aprovação do perfil inteiro. Nenhum check instala pacotes,
publica release, importa certificado ou faz deploy implicitamente.

| Perfil | Cenário e cobertura |
| --- | --- |
| quick | Formatação, lint e tipagem pertinentes |
| full | Quick + testes, cobertura, build, arquitetura, performance e segurança |
| security | Segredos atuais/histórico, SAST, dependências, licenças/fontes, malware, integridade e CI |
| artifacts | SBOM, vulnerabilidades de artefatos, malware, proveniência e binding |

Capacidades sem comando/política/pré-requisito ficam bloqueadas. Não há limiar
universal de cobertura, arquitetura ou performance. Detalhes de configuração,
bases/offline, confiança, exceções e migração: [manual do núcleo](automation/README.md).

## Catálogo por script

**Entrada** = comando utilizável; **wrapper** = encaminha ao núcleo, sem implementar
a ferramenta; **módulo** = importado por um comando ou adapter. Os comandos de
wrappers abaixo acrescentam `--root ... --config ...`; tarefas não implementadas
pelo adapter exigem `[projects.tasks.NOME]` explícito. A existência do wrapper não
prova que o consumidor possui a ferramenta ou o script necessário.

| Arquivo | Tipo e finalidade | Cenário e limites | Pré-requisitos / interface |
| --- | --- | --- | --- |
| [architecture/commands/check.sh](architecture/commands/check.sh) | **Wrapper**. Encaminha `--task commands-architecture` ao núcleo. | Arquitetura por tarefa específica de linguagem/política. | Bash + Python; --task commands-architecture |
| [architecture/validators/check.ts](architecture/validators/check.ts) | **Módulo/adapter**. Analisa imports frontend com a API do compilador TypeScript, detecta ciclos, fanout e regras de direção de dependências. Recusa raízes Rust e parsing incompleto. | Auditar a arquitetura frontend com as políticas de origem explicitamente adotadas. Não é um validador universal; usa owners específicos, suporta .js/.ts/.svelte e não cobre Vue/TSX. | TypeScript + runtime JS; Svelte compiler somente para .svelte |
| [architecture/validators/svelte-scripts.ts](architecture/validators/svelte-scripts.ts) | **Módulo/adapter**. Extrai scripts instance/module usando o parser oficial svelte/compiler, sem renderizar componentes. | Adapter interno de check.ts para Svelte. Falta de compiler ou erro de parsing interrompe a análise. | Runtime JS + svelte/compiler com API modern |
| [automate.py](automate.py) | **Entrada**. Entrada principal de planejamento e execução; exige raiz explícita e configuração revisada para executar. | Usar de qualquer cwd em projeto isolado ou workspace misto. | Python 3.11; plan/run |
| [automation/__init__.py](automation/__init__.py) | **Módulo/adapter**. Identifica o pacote compartilhado de automação. | Importação do núcleo; não é comando standalone. | Python 3.11 |
| [automation/adapters/__init__.py](automation/adapters/__init__.py) | **Módulo/adapter**. Planeja tarefas Cargo, Gradle, JS/TS, Vue, Svelte, Shell, PowerShell e governança. | Exigir apenas ferramentas da tecnologia selecionada; ambiguidades exigem projetos separados. | Python 3.11; ferramentas só no run |
| [automation/adapters/security.py](automation/adapters/security.py) | **Módulo/adapter**. Planeja superfícies distintas de segredos, SAST, dependências, licenças, malware, SBOM e integridade. | Perfil security/artifacts sem Qodana obrigatório e sem instalar ferramentas automaticamente. | Python 3.11; scanners/bases fixados |
| [automation/cli.py](automation/cli.py) | **Módulo/adapter**. Interpreta raiz, configuração, projetos, tarefas e perfis; instala handlers de cancelamento durante run. | Chamado por automate.py. Plan não executa comandos descobertos. | Python 3.11 |
| [automation/metrics.py](automation/metrics.py) | **Módulo/adapter**. Avalia LCOV, XML Kover/JaCoCo, bytes/gzip, percentis e exceções escopadas. | Tarefas internas @coverage/@budget/@performance/@exceptions com políticas e inputs revisados. | Python 3.11; limites do consumidor |
| [automation/model.py](automation/model.py) | **Módulo/adapter**. Define tarefas/projetos/estados, lê configuração, detecta manifests e verifica caminhos e hashes. | Descoberta conservadora e validação de configuração sem executar código do consumidor. | Python 3.11 stdlib |
| [automation/powershell-lint.ps1](automation/powershell-lint.ps1) | **Módulo/adapter**. Faz parsing de arquivos PowerShell e chama PSScriptAnalyzer; não dot-source os alvos. | Adapter de lint PowerShell no runner. Módulo/runtime precisam ser verificados no ambiente. | PowerShell + PSScriptAnalyzer |
| [automation/reports.py](automation/reports.py) | **Módulo/adapter**. Centraliza contratos de JSON/SARIF para scanners e converte relatórios em contagem de findings. | Runner e check-report.py compartilham a mesma classificação. Não procura palavras em logs. | Python 3.11 |
| [automation/runtime.py](automation/runtime.py) | **Módulo/adapter**. Verifica ferramentas/inputs/bases, supervisiona subprocessos, limites, grupos de processo e evidências privadas. | Executar checks configurados em Linux, preservando códigos, logs e resultados parciais. Não substitui sandbox de OS. | Python 3.11; Linux; ferramentas pertinentes |
| [bun/commands/package-manager.sh](bun/commands/package-manager.sh) | **Wrapper**. Encaminha `--task commands-package-manager` ao núcleo. | Política de package manager Bun adotada pelo consumidor. | Bash + Python; --task commands-package-manager |
| [bun/lib/runtime.sh](bun/lib/runtime.sh) | **Módulo/adapter**. Resolve executável Bun e prepara TMPDIR local da integração legada. | Adapter frontend/Bun explicitamente adotado; não carregar em checks Rust/Kotlin isolados. | Bash + Bun |
| [frontend/analyzers/build-budget.ts](frontend/analyzers/build-budget.ts) | **Módulo/adapter**. Calcula payload bruto/gzip e limites por mídia/chunk do frontend de origem. | Adapter frontend quando esses budgets Svelte forem adotados; para orçamento genérico use @budget em Python. | Runtime JS; política específica versionada |
| [frontend/analyzers/eslint-ratchet.ts](frontend/analyzers/eslint-ratchet.ts) | **Módulo/adapter**. Executa ESLint e compara warnings de qualidade com baseline por arquivo/regra. | Evitar regressão de complexidade em frontend já configurado com ESLint. | Runtime JS + ESLint; configuração do consumidor |
| [frontend/commands/build-budget.sh](frontend/commands/build-budget.sh) | **Wrapper**. Encaminha `--task build-budget` ao núcleo. | Verificação frontend usando scripts reais escolhidos no package.json. | Bash + Python; --task build-budget |
| [frontend/commands/build.sh](frontend/commands/build.sh) | **Wrapper**. Encaminha `--task build` ao núcleo. | Verificação frontend usando scripts reais escolhidos no package.json. | Bash + Python; --task build |
| [frontend/commands/coverage.sh](frontend/commands/coverage.sh) | **Wrapper**. Encaminha `--task coverage` ao núcleo. | Verificação frontend usando scripts reais escolhidos no package.json. | Bash + Python; --task coverage |
| [frontend/commands/lint.sh](frontend/commands/lint.sh) | **Wrapper**. Encaminha `--task lint` ao núcleo. | Verificação frontend usando scripts reais escolhidos no package.json. | Bash + Python; --task lint |
| [frontend/commands/performance.sh](frontend/commands/performance.sh) | **Wrapper**. Encaminha `--task performance` ao núcleo. | Verificação frontend usando scripts reais escolhidos no package.json. | Bash + Python; --task performance |
| [frontend/commands/test.sh](frontend/commands/test.sh) | **Wrapper**. Encaminha `--task test` ao núcleo. | Verificação frontend usando scripts reais escolhidos no package.json. | Bash + Python; --task test |
| [frontend/commands/typecheck.sh](frontend/commands/typecheck.sh) | **Wrapper**. Encaminha `--task typecheck` ao núcleo. | Verificação frontend usando scripts reais escolhidos no package.json. | Bash + Python; --task typecheck |
| [frontend/dev.sh](frontend/dev.sh) | **Wrapper**. Encaminha `--task run-frontend-dev` ao núcleo. | Verificação frontend usando scripts reais escolhidos no package.json. | Bash + Python; --task run-frontend-dev |
| [frontend/setup.sh](frontend/setup.sh) | **Wrapper**. Encaminha `--task setup-frontend` ao núcleo. | Verificação frontend usando scripts reais escolhidos no package.json. | Bash + Python; --task setup-frontend |
| [frontend/verify.sh](frontend/verify.sh) | **Wrapper**. Encaminha `--profile full` ao núcleo. | Verificação frontend usando scripts reais escolhidos no package.json. | Bash + Python; --profile full |
| [git/setup-hooks.sh](git/setup-hooks.sh) | **Wrapper**. Encaminha `--task setup-git-hooks` ao núcleo. | Instalação de hooks somente conforme tarefa autorizada do consumidor. | Bash + Python; --task setup-git-hooks |
| [governance/commands/agents.sh](governance/commands/agents.sh) | **Wrapper**. Encaminha `--task commands-agents` ao núcleo. | Contratos de governança explicitamente declarados em governance.json. | Bash + Python; --task commands-agents |
| [governance/commands/skill-contract.sh](governance/commands/skill-contract.sh) | **Wrapper**. Encaminha `--task skill-contract` ao núcleo. | Contratos de governança explicitamente declarados em governance.json. | Bash + Python; --task skill-contract |
| [governance/validators/validate.py](governance/validators/validate.py) | **Entrada**. Valida arquivos exigidos, trechos obrigatórios/proibidos e budgets de palavras por regras JSON do consumidor. | Contratos AGENTS/skills/documentação sem presumir owners, pastas, notas ou ferramentas de outro projeto. | Python 3.11; --root e --policy |
| [graphify/analyzers/graph-state.ts](graphify/analyzers/graph-state.ts) | **Módulo/adapter**. Valida grafo, endpoints, hashes e freshness segundo o protocolo/corpus do índice de origem. | Integração Graphify explicitamente configurada; conserva contrato de corpus Svelte/Tauri específico. Não é dependência de Rust/Kotlin. | Runtime JS; grafo/manifest/configuração de origem |
| [graphify/benchmark.sh](graphify/benchmark.sh) | **Wrapper**. Encaminha `--task graphify-benchmark` ao núcleo. | Operações Graphify com protocolo e ferramenta revisados pelo consumidor. | Bash + Python; --task graphify-benchmark |
| [graphify/build.sh](graphify/build.sh) | **Wrapper**. Encaminha `--task graphify-build` ao núcleo. | Operações Graphify com protocolo e ferramenta revisados pelo consumidor. | Bash + Python; --task graphify-build |
| [graphify/status.sh](graphify/status.sh) | **Wrapper**. Encaminha `--task graphify-status` ao núcleo. | Operações Graphify com protocolo e ferramenta revisados pelo consumidor. | Bash + Python; --task graphify-status |
| [graphify/update.sh](graphify/update.sh) | **Wrapper**. Encaminha `--task graphify-update` ao núcleo. | Operações Graphify com protocolo e ferramenta revisados pelo consumidor. | Bash + Python; --task graphify-update |
| [lib/colors.sh](lib/colors.sh) | **Módulo/adapter**. Fornece funções de logging colorido respeitando terminal e NO_COLOR. | Helper Shell de compatibilidade; não decide aprovação. | Bash |
| [lib/failure-log.sh](lib/failure-log.sh) | **Módulo/adapter**. Captura stdout/stderr e exit com publisher de logs legado. | Compatibilidade das integrações preservadas, inclusive a fronteira excluída de Qodana. Novos fluxos usam runtime.py. | Bash; helper log-retention.sh |
| [lib/log-retention.sh](lib/log-retention.sh) | **Módulo/adapter**. Aplica retenção legada sob uma raiz validada. | Somente integrações antigas que adotem essa política; pode remover entradas antigas. O novo runner não o usa. | Bash e utilitários GNU |
| [lib/project-test-temp.ts](lib/project-test-temp.ts) | **Módulo/adapter**. Cria temporários exclusivos para testes JS dentro de .local/tests por owner. | Helper dos testes específicos; não é comando de produto. | Runtime JS |
| [release/generate-release-evidence.ts](release/generate-release-evidence.ts) | **Módulo/adapter**. Gera checksums e SBOM a partir dos locks Bun/Cargo no contrato de release original. | Preparação local de release Tauri/Bun; nome/estrutura específicos não são SBOM universal. Preferir Syft e binding do núcleo para adoção genérica. | Bun; locks e variáveis de release de origem |
| [release/import-windows-certificate.ps1](release/import-windows-certificate.ps1) | **Módulo/adapter**. Importa PFX fornecido no ambiente para store CurrentUser e exporta thumbprint para GitHub Env. | Somente signing Windows autorizado em runner isolado. Altera store e escreve material sensível. | Windows PowerShell; certificado; GITHUB_ENV |
| [release/prepare-tauri-updater-config.ts](release/prepare-tauri-updater-config.ts) | **Módulo/adapter**. Valida endpoint HTTPS, chave pública e dados de assinatura para overlay do updater Tauri. | Preparação local de release Tauri; não publica nem instala atualização. | Runtime JS; autoridades configuradas |
| [release/remove-windows-certificate.ps1](release/remove-windows-certificate.ps1) | **Módulo/adapter**. Remove certificado pelo thumbprint e material temporário do contrato original. | Limpeza da etapa Windows autorizada; não executar como check genérico. | Windows PowerShell; contexto correto da release |
| [release/verify-release-authority.ts](release/verify-release-authority.ts) | **Módulo/adapter**. Verifica presença de autoridades de assinatura/updater por plataforma. | Preflight de release Tauri; presença não prova validade do certificado nem assinatura real. | Runtime JS; ambiente de release |
| [reports/summarize.py](reports/summarize.py) | **Entrada**. Renderiza results.json observado em tabela Markdown, preservando erros, bloqueios e exit bruto. | Anexar resumo de uma execução a uma revisão sem inventar scores ou promover evidência antiga. | Python 3.11; results.json schema 1 |
| [rust/commands/audit.sh](rust/commands/audit.sh) | **Wrapper**. Encaminha `--task rust-audit` ao núcleo. | Verificações Cargo em projeto Rust, sem exigir Bun/Node/JVM. | Bash + Python; --task rust-audit |
| [rust/commands/clippy.sh](rust/commands/clippy.sh) | **Wrapper**. Encaminha `--task lint` ao núcleo. | Verificações Cargo em projeto Rust, sem exigir Bun/Node/JVM. | Bash + Python; --task lint |
| [rust/commands/coverage.sh](rust/commands/coverage.sh) | **Wrapper**. Encaminha `--task coverage` ao núcleo. | Verificações Cargo em projeto Rust, sem exigir Bun/Node/JVM. | Bash + Python; --task coverage |
| [rust/commands/deny.sh](rust/commands/deny.sh) | **Wrapper**. Encaminha `--task licenses` ao núcleo. | Verificações Cargo em projeto Rust, sem exigir Bun/Node/JVM. | Bash + Python; --task licenses |
| [rust/commands/fmt.sh](rust/commands/fmt.sh) | **Wrapper**. Encaminha `--task fmt` ao núcleo. | Verificações Cargo em projeto Rust, sem exigir Bun/Node/JVM. | Bash + Python; --task fmt |
| [rust/commands/geiger.sh](rust/commands/geiger.sh) | **Wrapper**. Encaminha `--task rust-geiger` ao núcleo. | Verificações Cargo em projeto Rust, sem exigir Bun/Node/JVM. | Bash + Python; --task rust-geiger |
| [rust/commands/machete.sh](rust/commands/machete.sh) | **Wrapper**. Encaminha `--task rust-machete` ao núcleo. | Verificações Cargo em projeto Rust, sem exigir Bun/Node/JVM. | Bash + Python; --task rust-machete |
| [rust/commands/test.sh](rust/commands/test.sh) | **Wrapper**. Encaminha `--task test` ao núcleo. | Verificações Cargo em projeto Rust, sem exigir Bun/Node/JVM. | Bash + Python; --task test |
| [rust/verify.sh](rust/verify.sh) | **Wrapper**. Encaminha `--profile full` ao núcleo. | Verificações Cargo em projeto Rust, sem exigir Bun/Node/JVM. | Bash + Python; --profile full |
| [security/analyzers/check-report.py](security/analyzers/check-report.py) | **Entrada**. Valida JSON/SARIF existente com os mesmos parsers conservadores do runner. | Gate após scanner; relatório inválido/incompleto retorna erro, resultados violadores retornam findings. Não executa scanner nem licencia CodeQL. | Python 3.11; --parser e arquivo |
| [security/analyzers/validate-exceptions.py](security/analyzers/validate-exceptions.py) | **Entrada**. Confere registro normalizado de exceções com pacote/componente, ferramenta, achado, owner, revisão, expiração e controle. | Revisar exceções antes de aplicar uma política específica. Não gera argumentos --ignore nem suprime achados. | Python 3.11; registry JSON |
| [security/commands/advisory-policy.sh](security/commands/advisory-policy.sh) | **Wrapper**. Encaminha `--task advisory-policy` ao núcleo. | Segurança conforme ferramentas, bases e políticas fixadas do consumidor. | Bash + Python; --task advisory-policy |
| [security/commands/bun-audit.sh](security/commands/bun-audit.sh) | **Wrapper**. Encaminha `--task bun-audit` ao núcleo. | Segurança conforme ferramentas, bases e políticas fixadas do consumidor. | Bash + Python; --task bun-audit |
| [security/commands/codeql-js-ts.sh](security/commands/codeql-js-ts.sh) | **Wrapper**. Encaminha `--task licensed-codeql` ao núcleo. | Segurança conforme ferramentas, bases e políticas fixadas do consumidor. | Bash + Python; --task licensed-codeql |
| [security/commands/gitleaks.sh](security/commands/gitleaks.sh) | **Wrapper**. Encaminha `--task secrets` ao núcleo. | Segurança conforme ferramentas, bases e políticas fixadas do consumidor. | Bash + Python; --task secrets |
| [security/commands/opengrep.sh](security/commands/opengrep.sh) | **Wrapper**. Encaminha `--task sast` ao núcleo. | Segurança conforme ferramentas, bases e políticas fixadas do consumidor. | Bash + Python; --task sast |
| [security/commands/osv-scanner.sh](security/commands/osv-scanner.sh) | **Wrapper**. Encaminha `--task dependencies` ao núcleo. | Segurança conforme ferramentas, bases e políticas fixadas do consumidor. | Bash + Python; --task dependencies |
| [security/commands/trivy.sh](security/commands/trivy.sh) | **Wrapper**. Encaminha `--task legacy-trivy` ao núcleo. | Segurança conforme ferramentas, bases e políticas fixadas do consumidor. | Bash + Python; --task legacy-trivy |
| [security/verify.sh](security/verify.sh) | **Wrapper**. Encaminha `--profile security` ao núcleo. | Segurança conforme ferramentas, bases e políticas fixadas do consumidor. | Bash + Python; --profile security |
| [tauri/analyzers/desktop-navigation-performance.ts](tauri/analyzers/desktop-navigation-performance.ts) | **Módulo/adapter**. Avalia mediana, p95 e máximo de amostras de navegação contra budget. | Helper de performance de navegação Tauri da aplicação instrumentada. | Runtime JS; amostras reais |
| [tauri/analyzers/desktop-startup-performance.ts](tauri/analyzers/desktop-startup-performance.ts) | **Módulo/adapter**. Mede amostras de início até marker de superfície útil de processo Tauri confiável. | Benchmark desktop instrumentado e isolado, com binário conhecido. Nunca usar em amostra suspeita. | Bun; binário instrumentado; display |
| [tauri/cli.sh](tauri/cli.sh) | **Wrapper**. Encaminha `--task run-tauri-cli` ao núcleo. | Aplicação desktop Tauri e seus pré-requisitos nativos explicitamente configurados. | Bash + Python; --task run-tauri-cli |
| [tauri/commands/desktop-e2e.sh](tauri/commands/desktop-e2e.sh) | **Wrapper**. Encaminha `--task desktop-e2e` ao núcleo. | Aplicação desktop Tauri e seus pré-requisitos nativos explicitamente configurados. | Bash + Python; --task desktop-e2e |
| [tauri/commands/desktop-portable-e2e.sh](tauri/commands/desktop-portable-e2e.sh) | **Wrapper**. Encaminha `--task desktop-portable-e2e` ao núcleo. | Aplicação desktop Tauri e seus pré-requisitos nativos explicitamente configurados. | Bash + Python; --task desktop-portable-e2e |
| [tauri/commands/desktop-startup-performance.sh](tauri/commands/desktop-startup-performance.sh) | **Wrapper**. Encaminha `--task desktop-startup-performance` ao núcleo. | Aplicação desktop Tauri e seus pré-requisitos nativos explicitamente configurados. | Bash + Python; --task desktop-startup-performance |
| [tauri/verify.sh](tauri/verify.sh) | **Wrapper**. Encaminha `--profile full` ao núcleo. | Aplicação desktop Tauri e seus pré-requisitos nativos explicitamente configurados. | Bash + Python; --profile full |
| [verify/full.sh](verify/full.sh) | **Wrapper**. Encaminha `--profile full` ao núcleo. | Agregação dos projetos e tecnologias explicitamente selecionados. | Bash + Python; --profile full |

## Governança e relatórios genéricos

```bash
python3 scripts/governance/validators/validate.py --root /caminho/projeto --policy governance.json
python3 scripts/security/analyzers/check-report.py --parser sarif /caminho/relatorio.sarif
python3 scripts/security/analyzers/check-report.py --parser opengrep /caminho/relatorio.json
python3 scripts/security/analyzers/validate-exceptions.py /caminho/exceptions.json
```

Exemplo de `governance.json` do consumidor, com correspondência literal (sem regex
executável, shell ou leitura implícita de um catálogo gerenciado):

```json
{
  "schema": 1,
  "rules": [
    {"id": "instrucoes", "path": "AGENTS.md", "contains": ["Validação"], "forbidden": ["eval("], "max_words": 2000}
  ]
}
```

Os valores são ilustrativos, não uma política obrigatória. Regras vazias/IDs
repetidos/configuração inválida/caminhos inseguros geram erro. Um arquivo exigido
ausente é achado. O adapter das tarefas `governance`, `commands-agents` e
`skill-contract` procura governance.json no projeto, requer o alias `python` fixado
em tools e inclui a política nos inputs revisados. Inclua também os arquivos-alvo
nos inputs da tarefa quando precisar vincular a observação ao conteúdo inspecionado.

Exceções exigem id, tool, finding, component exato, owner, reason, reviewed, expires
e control. O validador confere escopo/data, mas não suprime findings. As exceções
antigas de outro produto não foram transportadas como aceites deste consumidor.

## Configurações e dados auxiliares

| Arquivo/pasta | Função e cuidado de adoção |
| --- | --- |
| [automation/examples/](automation/examples/) | Modelos TOML Rust/Kotlin/Vue/misto; pins são placeholders a revisar |
| [automation/rules/gitleaks.toml](automation/rules/gitleaks.toml) | Regras default da CLI sem buscar registry remoto |
| [automation/rules/security.yml](automation/rules/security.yml) | Cinco indicadores locais SAST, cobertura estreita e explícita |
| [automation/rules/suspicious.yar](automation/rules/suspicious.yar) | Dois indicadores de comportamento para YARA-X; não prova intenção/malware universal |
| [security/rules/opengrep/](security/rules/opengrep/) | Regras preservadas da origem, algumas específicas de owners/Tauri; não herdadas pelo perfil genérico |
| [architecture/baselines/architecture.json](architecture/baselines/architecture.json) | Baseline do adapter frontend específico; não uma política arquitetural universal |
| [frontend/baselines/quality.json](frontend/baselines/quality.json) | Ratchet de qualidade ESLint por arquivo/regra |
| [typescript/tsconfig.json](typescript/tsconfig.json) | Configuração de integração TS; exige tsconfig/pacotes do consumidor, ausentes nesta biblioteca |
| [automation/LICENSE](automation/LICENSE) | Licença apenas do componente novo; não relicencia scripts de origem, ferramentas/regras/bases terceiras |

## Qodana: fronteira excluída

Os caminhos abaixo são apenas registrados; não foram analisados, executados,
atualizados ou removidos nesta migração:

- `security/commands/qodana.sh`
- `security/containers/qodana/rust.Dockerfile`
- `security/containers/qodana/ts.Dockerfile`
- `../src/tests/scripts/security/qodana-command.test.ts`

Permanecem preservados por hash e fora dos perfis genéricos. Helpers compartilhados
necessários à sua compatibilidade não foram apagados indiscriminadamente.

## Resultados, efeitos e segurança

| Estado | Significado | Exit agregado |
| --- | --- | --- |
| passed | Contrato/política satisfeitos nesta execução | 0 quando não houver impedimentos |
| findings | Achados violadores | 1 |
| error | Parser, comando, timeout ou relatório inválido | 2 |
| blocked | Pré-requisito, ferramenta, base ou pin indisponível/divergente | 3 |
| not_applicable | Inaplicável com razão explícita | Não bloqueia |
| omitted | Omitido explicitamente com razão | 3, sem aprovação completa |

Logs brutos e JSON por tarefa ficam em `.local/automation/runs/run-*/`, privados,
com hash/configuração/ferramentas e exit bruto. O resumo Markdown é visualização,
não nova evidência ou revisão de freshness. Os validadores standalone genéricos
usam 0 para aprovação, 1 para achados e 2 para erro; validate-exceptions usa 0/2.

Builds e scripts de package manager/Gradle podem executar terceiros. Use sandbox
externo e privilégios mínimos; o supervisor não bloqueia sozinho rede/memória/CPU.
Não compartilhe logs privados sem revisão. Arquivos compactados bloqueiam a análise
de malware padrão até existir extração isolada com limites. Assinatura/SBOM/hash não
prova segurança de todo código. Consulte o manual do núcleo para limites de scans,
symlinks, refs Git, bases e artefatos.

## Migração, retirada e validação

Os validadores TypeScript genéricos de governança, parsing JSON/SARIF e registro de
exceções foram substituídos pelos módulos Python acima. O gerador de relatórios com
aprovações fixas foi substituído por summarize.py. A análise Rust por regex e sua
tabela de layers do produto foram retiradas, sem fingir cobertura equivalente em
outro parser: arquitetura Rust exige tarefa nativa configurada pelo consumidor.
A capacidade frontend continua separada e falha em raízes Rust/sem fontes válidas.
Svelte usa [parser oficial](https://svelte.dev/docs/svelte/svelte-compiler), carregado
somente quando necessário; sua versão deve ser fixada pelo consumidor.

Arquivos defasados e testes acoplados a esses contratos foram removidos da árvore
ativa, com recuperação em [registro de retirada](../doc/structure/validator-migration-20261105/retired.json)
e baseline por conteúdo. Não foram apagadas evidências históricas. As limitações de
aplicações originais ausentes permanecem; não houve requalificação de release nativa,
Graphify, PowerShell nem todas as integrações de scanners.

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s src/tests/automation -v
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/run_sdd_checks.py
PYTHONDONTWRITEBYTECODE=1 python3 src/scripts/audit_library.py
```

Testes atuais: [src/tests/automation](../src/tests/automation/). Testes e fixtures
específicos de origem ainda pertinentes: [src/tests/scripts](../src/tests/scripts/)
e [src/fixtures/scripts](../src/fixtures/scripts/). O probe de arquitetura frontend
é `src/tests/scripts/architecture/frontend-probe.ts`: requer TypeScript instalado e
runtime JS. O corpus completo legado não é executável sem os consumidores originais.
Ao atualizar código/política/inputs, preserve os logs anteriores e reexecute os
checks afetados; não regenere apenas hashes de evidência antiga.
