"""Data contracts and conservative configuration loading. No discovery executes code."""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import tomllib
from dataclasses import asdict, dataclass, field
from pathlib import Path

STATES = ('passed', 'findings', 'error', 'blocked', 'not_applicable', 'omitted')
PROFILES = {
    'quick': ('fmt', 'lint', 'typecheck'),
    'full': ('fmt', 'lint', 'typecheck', 'test', 'coverage', 'build', 'architecture', 'performance',
             'secrets', 'history', 'sast', 'dependencies', 'licenses', 'malware', 'integrity', 'ci'),
    'security': ('secrets', 'history', 'sast', 'dependencies', 'licenses', 'malware', 'integrity', 'ci'),
    'artifacts': ('sbom', 'artifact-vulnerabilities', 'malware', 'provenance', 'artifact-binding'),
}
TECHNOLOGIES = {'rust', 'kotlin', 'javascript', 'typescript', 'vue', 'svelte', 'tauri', 'shell', 'powershell'}
ID = re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9._-]*$')
HASH = re.compile(r'^[0-9a-f]{64}$')


class ConfigError(ValueError):
    pass


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def inside(root: Path, value: str, *, exists: bool = True) -> Path:
    """Reject symlink components as well as lexical traversal, even for future outputs."""
    if not isinstance(value, str) or not value or '\0' in value:
        raise ConfigError('invalid path')
    part = Path(value)
    if part.is_absolute() or '..' in part.parts:
        raise ConfigError(f'path must be relative and contained: {value}')
    p = root
    for component in part.parts:
        p = p / component
        if p.is_symlink():
            raise ConfigError(f'symlink not permitted: {value}')
    resolved = p.resolve()
    if not resolved.is_relative_to(root.resolve()) or (exists and not resolved.exists()):
        raise ConfigError(f'path missing or outside root: {value}')
    return resolved


def json_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ConfigError(f'duplicate JSON key: {key}')
        result[key] = value
    return result


def read_json(path: Path):
    return json.loads(path.read_text(), object_pairs_hook=json_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ConfigError(f'invalid number {value}')))


def keys(obj, allowed, where):
    if not isinstance(obj, dict) or set(obj) - set(allowed):
        raise ConfigError(f'unknown keys or invalid table: {where}')


def strings(value, where, nonempty=False):
    if not isinstance(value, list) or any(not isinstance(x, str) or '\0' in x for x in value) or (nonempty and not value):
        raise ConfigError(f'{where} requires string array')
    return value


@dataclass
class Task:
    project: str
    name: str
    cwd: str
    argv: list[str] = field(default_factory=list)
    parser: str = 'exit'
    findings_codes: list[int] = field(default_factory=list)
    state: str | None = None
    reason: str = ''
    timeout: float = 300
    inputs: list[str] = field(default_factory=list)
    dataset: str = ''

    def data(self):
        return asdict(self)


@dataclass
class Project:
    id: str
    path: str
    technologies: list[str]
    manifests: list[str]
    options: dict = field(default_factory=dict)


def walk(root: Path, *, max_files=20000):
    """Bounded, deterministic discovery. No symlink following or hidden source authority."""
    ignored = {'.git', '.agents', '.codex', '.aws', '.local', 'node_modules', 'target', 'build', 'dist', '__pycache__'}
    files = []
    for directory, dirs, names in os.walk(root, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in ignored and not Path(directory, d).is_symlink())
        for name in sorted(names):
            p = Path(directory, name)
            if p.is_symlink():
                raise ConfigError(f'unscanned symlink: {p.relative_to(root)}')
            if not p.is_file():
                raise ConfigError(f'unsupported filesystem entry: {p}')
            if 'qodana' in str(p.relative_to(root)).lower():
                continue
            files.append(p)
            if len(files) > max_files:
                raise ConfigError('discovery file limit exceeded; select a narrower project')
    return files


def detect(root: Path, relative: str) -> Project:
    base = inside(root, relative)
    if not base.is_dir():
        raise ConfigError('project must be a directory')
    files = walk(base)
    names = {str(p.relative_to(base)) for p in files}
    tech, manifests = set(), []
    if 'Cargo.toml' in names:
        tomllib.loads((base / 'Cargo.toml').read_text())
        tech.add('rust'); manifests.append('Cargo.toml')
    builds = names & {'build.gradle', 'build.gradle.kts', 'pom.xml'}
    if builds:
        # A Gradle manifest alone is not proof of Kotlin. Use Kotlin sources/plugin text.
        kotlin = any(p.suffix in {'.kt', '.kts'} for p in files) or any('kotlin' in (base / p).read_text() for p in builds)
        if kotlin:
            tech.add('kotlin'); manifests.extend(sorted(builds))
    if 'package.json' in names:
        package = read_json(base / 'package.json')
        if not isinstance(package, dict):
            raise ConfigError('package.json must be an object')
        deps = {**package.get('dependencies', {}), **package.get('devDependencies', {})}
        tech.add('javascript'); manifests.append('package.json')
        for dependency, technology in [('typescript', 'typescript'), ('vue', 'vue'), ('svelte', 'svelte'), ('@tauri-apps/cli', 'tauri')]:
            if dependency in deps:
                tech.add(technology)
    if any(p.suffix == '.sh' for p in files): tech.add('shell')
    if any(p.suffix == '.ps1' for p in files): tech.add('powershell')
    if any(p.name.startswith('tauri.conf.') for p in files): tech.add('tauri')
    return Project('project', relative, sorted(tech), [str(Path(relative) / p) for p in manifests])


def load(root: Path, config: Path | None):
    if config is None:
        return {}, [detect(root, '.')]
    if not config.is_file():
        raise ConfigError('configuration missing')
    raw = tomllib.loads(config.read_text())
    keys(raw, {'schema', 'projects', 'tools', 'datasets', 'inputs', 'env', 'limits'}, 'root')
    if raw.get('schema') != 1: raise ConfigError('schema must be 1')
    for section in ('tools', 'datasets', 'inputs', 'env', 'limits'):
        if not isinstance(raw.get(section, {}), dict): raise ConfigError(f'invalid {section}')
    for name, tool in raw.get('tools', {}).items():
        if not ID.fullmatch(name): raise ConfigError('invalid tool ID')
        keys(tool, {'path', 'sha256', 'version', 'version_args', 'provenance'}, name)
        if not all(isinstance(tool.get(k), str) and tool[k] for k in ('path', 'sha256', 'version', 'provenance')):
            raise ConfigError(f'tool {name} needs path, hash, exact version output, provenance')
        if not HASH.fullmatch(tool['sha256']) or not Path(tool['path']).is_absolute():
            raise ConfigError(f'invalid pin for {name}')
        strings(tool.get('version_args', ['--version']), 'version_args', True)
    for path, digest in raw.get('inputs', {}).items():
        inside(root, path)
        if not isinstance(digest, str) or not HASH.fullmatch(digest): raise ConfigError('invalid input hash')
    for name, ds in raw.get('datasets', {}).items():
        keys(ds, {'path', 'sha256', 'updated', 'max_age_days', 'license', 'source'}, name)
        if not all(isinstance(ds.get(k), str) and ds[k] for k in ('path', 'sha256', 'updated', 'license', 'source')):
            raise ConfigError('dataset requires identity/date/license/source')
        inside(root, ds['path'])
        if not HASH.fullmatch(ds['sha256']): raise ConfigError('invalid dataset hash')
        if type(ds.get('max_age_days')) is not int or ds['max_age_days'] < 0: raise ConfigError('invalid dataset age')
    if any(not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', k) or not isinstance(v, str) or '\0' in v for k, v in raw.get('env', {}).items()):
        raise ConfigError('invalid environment')
    keys(raw.get('limits', {}), {'timeout', 'log_bytes', 'file_bytes', 'total_bytes'}, 'limits')
    for key, value in raw.get('limits', {}).items():
        if type(value) not in (int, float) or not math.isfinite(value) or value <= 0: raise ConfigError(f'invalid limit {key}')
    projects = []
    entries = raw.get('projects')
    if not isinstance(entries, list) or not entries: raise ConfigError('projects required')
    for entry in entries:
        keys(entry, {'id', 'path', 'technologies', 'tasks', 'scripts', 'gradle_tasks', 'manager'}, 'project')
        if not isinstance(entry.get('id'), str) or not ID.fullmatch(entry['id']): raise ConfigError('invalid project ID')
        p = detect(root, entry.get('path', '.')); p.id = entry['id']; p.options = entry
        if 'technologies' in entry:
            explicit = strings(entry['technologies'], 'technologies', True)
            if set(explicit) - TECHNOLOGIES: raise ConfigError('unknown technology')
            if set(explicit) - set(p.technologies): raise ConfigError('technology not evidenced by manifests/sources')
            p.technologies = explicit
        for mapping in ('tasks', 'scripts', 'gradle_tasks'):
            if not isinstance(entry.get(mapping, {}), dict): raise ConfigError(f'invalid {mapping}')
        for name, task in entry.get('tasks', {}).items():
            keys(task, {'argv', 'parser', 'findings_codes', 'timeout', 'inputs', 'dataset', 'state', 'reason'}, name)
            if not ID.fullmatch(name): raise ConfigError('invalid task ID')
            if 'argv' in task: strings(task['argv'], 'argv', True)
            if task.get('state') not in (None, 'not_applicable', 'omitted'): raise ConfigError('only explicit NA/omit permitted')
            if task.get('state') and (not task.get('reason') or 'argv' in task): raise ConfigError('disposition requires reason and no command')
            strings(task.get('inputs', []), 'inputs')
            codes = task.get('findings_codes', [])
            if not isinstance(codes, list) or any(type(c) is not int or not 1 <= c <= 126 for c in codes): raise ConfigError('invalid findings exit code')
            timeout = task.get('timeout', 300)
            if type(timeout) not in (int, float) or not math.isfinite(timeout) or timeout <= 0: raise ConfigError('invalid task timeout')
        projects.append(p)
    if len({p.id for p in projects}) != len(projects): raise ConfigError('duplicate project IDs')
    if len({(p.path, tuple(sorted(p.technologies))) for p in projects}) != len(projects): raise ConfigError('duplicate project selections')
    return raw, projects
