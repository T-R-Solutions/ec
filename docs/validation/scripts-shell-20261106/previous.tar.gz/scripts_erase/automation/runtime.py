"""Bounded POSIX process supervision and evidence retention; never installs software."""
from __future__ import annotations

import datetime as dt
import fcntl
import json
import os
import selectors
import shutil
import signal
import subprocess
import tempfile
import threading
import time
from pathlib import Path

from .model import ConfigError, Task, inside, read_json, sha256, walk
from .reports import findings


class Blocked(RuntimeError):
    pass


def save(path: Path, value):
    temp = path.with_name(path.name + '.tmp')
    with temp.open('x', encoding='utf8') as stream:
        os.chmod(temp, 0o600)
        json.dump(value, stream, ensure_ascii=False, indent=2); stream.write('\n')
        stream.flush(); os.fsync(stream.fileno())
    os.replace(temp, path)


def terminate(process):
    try: os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError: return
    try: process.wait(timeout=1)
    except subprocess.TimeoutExpired:
        try: os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError: pass
        process.wait(timeout=2)
    # Kill remaining descendants, even if their parent already exited on TERM.
    try: os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError: pass


def execute(argv, cwd, environment, directory, timeout, limit, cancel):
    """Byte-preserving stdout/stderr, bounded combined size; retain prefix on overflow."""
    started = time.monotonic(); status = None; cause = ''
    stdout_path, stderr_path = directory / 'stdout.log', directory / 'stderr.log'
    with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
        os.chmod(stdout_path, 0o600); os.chmod(stderr_path, 0o600)
        process = subprocess.Popen(argv, cwd=cwd, env=environment, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        selector = selectors.DefaultSelector()
        selector.register(process.stdout, selectors.EVENT_READ, stdout)
        selector.register(process.stderr, selectors.EVENT_READ, stderr)
        total = 0
        try:
            while selector.get_map() or process.poll() is None:
                if cancel.is_set(): cause = 'cancelled'
                elif time.monotonic() - started >= timeout: cause = 'timeout'
                if cause:
                    terminate(process); break
                for key, _ in selector.select(timeout=0.05):
                    data = os.read(key.fileobj.fileno(), 65536)
                    if not data:
                        selector.unregister(key.fileobj); continue
                    remaining = max(0, limit - total)
                    key.data.write(data[:remaining]); total += len(data)
                    if total > limit:
                        cause = 'log byte limit exceeded'; terminate(process); break
            if not cause:
                remaining = max(0.001, timeout - (time.monotonic() - started))
                try: process.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    cause = 'timeout'; terminate(process)
            status = process.returncode
        finally:
            if process.poll() is None: terminate(process)
            # A detached child that retained no pipes is still in the process group.
            try: os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            selector.close(); process.stdout.close(); process.stderr.close()
    return {'returncode': status, 'cause': cause, 'duration_seconds': round(time.monotonic() - started, 4),
            'stdout_sha256': sha256(stdout_path), 'stderr_sha256': sha256(stderr_path)}


class Runner:
    def __init__(self, root: Path, config: dict, config_path: Path, cancel=None):
        self.root, self.config = root, config
        self.cancel = cancel or threading.Event()
        parent = inside(root, '.local/automation/runs', exists=False)
        parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.directory = Path(tempfile.mkdtemp(prefix='run-', dir=parent))
        os.chmod(self.directory, 0o700)
        self.config_hash = sha256(config_path)
        self.limits = config.get('limits', {})
        self.results = []
        self.tools = {}
        self.library_inputs = {str(p.relative_to(Path(__file__).parent)): sha256(p) for p in Path(__file__).parent.rglob('*') if p.is_file() and '__pycache__' not in str(p)}
        self.environment = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
                            'NO_COLOR': '1', 'GIT_TERMINAL_PROMPT': '0',
                            'GRYPE_DB_AUTO_UPDATE': 'false', 'GRYPE_CHECK_FOR_APP_UPDATE': 'false',
                            'SYFT_CHECK_FOR_APP_UPDATE': 'false', 'OPENGREP_ENABLE_VERSION_CHECK': '0'}
        self.environment.update(config.get('env', {}))
        self.environment['TMPDIR'] = str(self.directory)
        self.environment['HOME'] = str(self.directory / 'home')
        Path(self.environment['HOME']).mkdir(mode=0o700)
        self.lock = None

    def acquire(self):
        lockpath = inside(self.root, '.local/automation/workspace.lock', exists=False)
        fd = os.open(lockpath, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        self.lock = os.fdopen(fd, 'r+')
        try: fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            self.lock.close(); self.lock = None
            raise Blocked('another automation run owns this root')

    def tool(self, alias):
        if alias in self.tools: return self.tools[alias]['path']
        spec = self.config.get('tools', {}).get(alias)
        if spec is None: raise Blocked(f'tool not pinned: {alias}')
        requested = Path(spec['path'])
        if not requested.is_file() or not os.access(requested, os.X_OK): raise Blocked(f'tool unavailable: {alias}')
        # Symlink tool paths are explicit authority; pin target bytes and record both identities.
        if sha256(requested) != spec['sha256']: raise Blocked(f'tool hash mismatch: {alias}')
        version_dir = self.directory / f'tool-{alias}'; version_dir.mkdir(mode=0o700)
        outcome = execute([str(requested), *spec.get('version_args', ['--version'])], self.root,
                          self.environment, version_dir, 10, 65536, self.cancel)
        actual = (version_dir / 'stdout.log').read_text(errors='replace').strip()
        if outcome['cause'] or outcome['returncode'] != 0 or actual != spec['version']:
            raise Blocked(f'tool version unavailable/incompatible: {alias}')
        self.tools[alias] = {**spec, 'resolved': str(requested.resolve()), 'version_observation': outcome}
        return str(requested)

    def input_hashes(self, paths):
        output = {}
        for name in sorted(set(paths)):
            p = inside(self.root, name)
            if not p.is_file(): raise Blocked(f'input is not a file: {name}')
            digest = sha256(p)
            expected = self.config.get('inputs', {}).get(name)
            if expected is None: raise Blocked(f'input not reviewed/pinned: {name}')
            if digest != expected: raise Blocked(f'input changed since review: {name}')
            output[name] = digest
        return output

    def dataset(self, name):
        if not name: return None
        ds = self.config.get('datasets', {}).get(name)
        if ds is None: raise Blocked(f'dataset not pinned: {name}')
        updated = dt.datetime.fromisoformat(ds['updated'].replace('Z', '+00:00'))
        if updated.tzinfo is None: raise ConfigError('dataset timestamp needs timezone')
        age = dt.datetime.now(dt.timezone.utc) - updated
        if age.total_seconds() < 0 or age > dt.timedelta(days=ds['max_age_days']): raise Blocked('dataset expired/future timestamp')
        path = inside(self.root, ds['path'])
        if sha256(path) != ds['sha256']: raise Blocked('dataset hash mismatch')
        manifest = read_json(path)
        if manifest.get('schema') != 1 or not isinstance(manifest.get('files'), dict) or not manifest['files']:
            raise ConfigError('dataset manifest needs nonempty files')
        cache = inside(self.root, manifest['cache_root'])
        for name, digest in manifest['files'].items():
            if sha256(inside(cache, name)) != digest: raise Blocked('dataset file hash mismatch')
        return {**ds, 'cache_root': str(cache), 'files': manifest['files']}

    def snapshot(self, task, directory):
        source = inside(self.root, task.cwd)
        target = directory / 'source'; target.mkdir(mode=0o700)
        files = walk(source)
        if task.name in {'secrets', 'sast', 'dependencies'} and any(p.name in {'.gitleaksignore', '.semgrepignore', '.opengrepignore', 'osv-scanner.toml'} for p in files):
            raise Blocked('project scanner suppression/config needs explicit reviewed task; not inherited')
        total = 0; manifest = {}
        for p in files:
            size = p.stat().st_size; total += size
            if size > self.limits.get('file_bytes', 32 * 1024 * 1024) or total > self.limits.get('total_bytes', 256 * 1024 * 1024):
                raise Blocked('scan file/total byte limit exceeded; no silent omission')
            if task.name == 'malware' and p.suffix.lower() in {'.zip', '.gz', '.xz', '.bz2', '.7z', '.rar', '.tar', '.jar', '.war'}:
                raise Blocked('archive requires bounded isolated extraction policy; not recursively unpacked')
            rel = p.relative_to(source)
            copy = target / rel; copy.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(p, copy); os.chmod(copy, 0o600)
            digest = sha256(copy)
            if digest != sha256(p): raise Blocked('source changed during snapshot')
            manifest[str(p.relative_to(self.root))] = digest
        if not manifest: raise Blocked('empty scan target')
        save(directory / 'source-inputs.json', manifest)
        return target

    def internal(self, task):
        if task.argv[0] in {'@coverage', '@budget', '@performance', '@exceptions'}:
            from .metrics import measure
            if len(task.argv) != 2: raise ConfigError('measurement requires policy path')
            result = measure(self.root, task.argv[0], task.argv[1])
            return result
        if task.argv == ['@integrity']:
            # Pins are pre-install review evidence; lockfiles alone do not authenticate dependencies.
            pins = self.config.get('inputs', {})
            if not pins: raise Blocked('no reviewed dependency/wrapper/config inputs')
            return self.input_hashes(list(pins))
        if task.argv == ['@artifact-binding']:
            # Caller supplies an attestation with exact source and artifact identities, never generate one from claims.
            path = inside(self.root, str(Path(task.cwd) / 'automation-artifacts.json'))
            doc = read_json(path)
            if doc.get('schema') != 1 or not doc.get('artifacts') or not doc.get('inputs'):
                raise ConfigError('invalid artifact binding')
            for category in ('inputs', 'artifacts'):
                for name, digest in doc[category].items():
                    if sha256(inside(self.root, name)) != digest: raise ConfigError('artifact/input identity mismatch')
            if not doc.get('provenance_bundle'): raise Blocked('signed build provenance bundle required')
            if not any(r['task'] == 'provenance' and r['state'] == 'passed' for r in self.results):
                raise Blocked('provenance must pass before artifact binding')
            return doc
        raise ConfigError('unknown internal operation')

    def run_task(self, task: Task):
        index = len(self.results)
        directory = self.directory / f'{index:03}-{task.project}-{task.name}'
        directory.mkdir(mode=0o700)
        result = {'project': task.project, 'task': task.name, 'state': task.state or 'error',
                  'reason': task.reason, 'returncode': None, 'inputs': {}, 'dataset': None}
        try:
            if self.cancel.is_set(): raise Blocked('cancelled before task start')
            if task.state:
                return result
            if task.argv[0] in {'@coverage', '@budget', '@performance', '@exceptions'}:
                if len(task.argv) != 2 or task.argv[1] not in task.inputs: raise Blocked('measurement policy must be a pinned task input')
                if task.argv[0] != '@exceptions':
                    policy = read_json(inside(self.root, task.argv[1]))
                    if 'report' in policy and policy['report'] not in task.inputs: raise Blocked('measurement report must be a pinned task input')
            result['inputs'] = self.input_hashes(task.inputs)
            result['dataset'] = self.dataset(task.dataset)
            if task.argv[0].startswith('@'):
                result['evidence'] = self.internal(task)
                evidence = result['evidence']
                decisions = [v['passed'] for v in evidence.values() if isinstance(v, dict) and 'passed' in v]
                result['state'] = 'findings' if evidence.get('passed') is False or False in decisions else 'passed'
                return result
            executable = self.tool(task.argv[0])
            argv = [executable, *[a.replace('{root}', str(self.root)).replace('{project}', str(inside(self.root, task.cwd))).replace('{report}', str(directory / 'report.json')) for a in task.argv[1:]]]
            environment = dict(self.environment)
            if task.name == 'dependencies':
                ds = result['dataset']; environment['OSV_SCANNER_LOCAL_DB_CACHE_DIRECTORY'] = ds['cache_root']
            if task.name == 'artifact-vulnerabilities':
                ds = result['dataset']; environment['GRYPE_DB_CACHE_DIR'] = ds['cache_root']
            cwd = inside(self.root, task.cwd)
            if task.name == 'history':
                if any('qodana' in str(p.relative_to(cwd)).lower() for p in cwd.rglob('*')):
                    raise Blocked('history with excluded Qodana paths requires reviewed path-filtered history task')
                git = self.tool('git')
                check_dir = directory / 'git'; check_dir.mkdir(mode=0o700)
                check = execute([git, 'rev-parse', '--is-shallow-repository'], cwd, environment, check_dir, 10, 65536, self.cancel)
                if check['returncode'] != 0: raise Blocked('Git history unavailable')
                if (check_dir / 'stdout.log').read_text().strip() != 'false': raise Blocked('shallow Git history; obtain required refs separately')
                result['history_limit'] = 'local refs only; no fetch; unreachable/unobtained objects not covered'
            if task.name in {'secrets', 'sast', 'dependencies', 'malware', 'sbom', 'artifact-vulnerabilities'}:
                cwd = self.snapshot(task, directory)
            result['argv'] = argv
            result.update(execute(argv, cwd, environment, directory, task.timeout,
                                  int(self.limits.get('log_bytes', 8 * 1024 * 1024)), self.cancel))
            rc = result['returncode']
            if result['cause']: result['state'] = 'error'; result['reason'] = result['cause']; return result
            if rc != 0 and rc not in task.findings_codes:
                result['state'] = 'error'; result['reason'] = 'tool operational failure'; return result
            if task.parser != 'exit':
                report = directory / 'report.json'
                if not report.exists(): report = directory / 'stdout.log'
                if report.stat().st_size > self.limits.get('log_bytes', 8 * 1024 * 1024): raise ConfigError('report too large')
                count = findings(task.parser, read_json(report))
                result['finding_count'] = count
                if rc in task.findings_codes and not count: raise ConfigError('exit/report inconsistency')
                result['state'] = 'findings' if count else 'passed'
            else:
                result['state'] = 'findings' if rc in task.findings_codes else 'passed'
            # Recheck observed inputs after processes that could mutate configuration/build sources.
            if result['inputs'] != self.input_hashes(task.inputs): raise ConfigError('inputs changed during execution')
        except Blocked as error:
            result['state'] = 'blocked'; result['reason'] = str(error)
        except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
            result['state'] = 'error'; result['reason'] = str(error)
        finally:
            save(directory / 'result.json', result)
            self.results.append(result)
            self.publish()
        return result

    def publish(self):
        states = {r['state'] for r in self.results}
        code = 2 if 'error' in states else 3 if states & {'blocked', 'omitted'} else 1 if 'findings' in states else 0
        save(self.directory / 'results.json', {'schema': 1, 'root': str(self.root), 'config_sha256': self.config_hash,
             'platform': os.uname().sysname + ' ' + os.uname().machine, 'tools': self.tools,
             'results': self.results, 'exit_code': code, 'complete': not bool(states & {'error', 'blocked', 'omitted'}),
             'library_inputs': self.library_inputs,
             'limits': self.limits, 'network': 'no isolation implied; scanner defaults offline; project commands need external sandbox'})
        return code

    def close(self):
        if self.lock:
            self.lock.close(); self.lock = None
