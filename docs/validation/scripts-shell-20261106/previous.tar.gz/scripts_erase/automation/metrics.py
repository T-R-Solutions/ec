"""Reusable measurements. Thresholds and scoped exceptions are consumer policy."""
import datetime as dt
import gzip
import math
from pathlib import Path
from .model import ConfigError, inside, read_json, sha256, walk


def lcov(source, minimum):
    if set(minimum) - {'lines', 'functions'}: raise ConfigError('unsupported LCOV metric')
    totals = {'LF': 0, 'LH': 0, 'FNF': 0, 'FNH': 0}
    records = 0
    for line in source.splitlines():
        if line == 'end_of_record': records += 1
        key, _, value = line.partition(':')
        if key in totals:
            if not value.isdecimal(): raise ConfigError('invalid LCOV counter')
            totals[key] += int(value)
    if not records: raise ConfigError('LCOV has no complete records')
    result = {}
    for key, numerator, denominator in [('lines','LH','LF'),('functions','FNH','FNF')]:
        if key not in minimum: continue
        threshold = minimum[key]
        if type(threshold) not in (int,float) or not math.isfinite(threshold) or not 0 <= threshold <= 100: raise ConfigError('invalid coverage threshold')
        if not totals[denominator] or totals[numerator] > totals[denominator]: raise ConfigError('invalid coverage denominator')
        actual = totals[numerator]*100/totals[denominator]
        result[key]={'actual':actual,'minimum':threshold,'passed':actual>=threshold}
    if not result: raise ConfigError('coverage policy empty')
    return result


def coverage_xml(source, minimum):
    import xml.etree.ElementTree as ET
    if '<!DOCTYPE' in source.upper() or '<!ENTITY' in source.upper(): raise ConfigError('XML external/entities declarations forbidden')
    report = ET.fromstring(source)
    if report.tag != 'report' or set(minimum) - {'lines', 'functions'}: raise ConfigError('unsupported coverage XML')
    counters = {}
    for counter in report.findall('counter'):
        kind = counter.get('type')
        if kind in counters: raise ConfigError('duplicate aggregate coverage counter')
        missed, covered = int(counter.get('missed', '-1')), int(counter.get('covered', '-1'))
        if missed < 0 or covered < 0: raise ConfigError('negative coverage counter')
        counters[kind] = (covered, missed + covered)
    output = {}
    for metric, threshold in minimum.items():
        if type(threshold) not in (int, float) or not math.isfinite(threshold) or not 0 <= threshold <= 100: raise ConfigError('invalid coverage threshold')
        covered, total = counters.get({'lines':'LINE','functions':'METHOD'}[metric], (0,0))
        if not total: raise ConfigError('missing aggregate coverage denominator')
        actual = covered * 100 / total
        output[metric] = {'actual':actual, 'minimum':threshold, 'passed':actual >= threshold}
    if not output: raise ConfigError('empty coverage policy')
    return output


def budget(root, maximum):
    files=walk(root); output=[]; total=0
    if not files: raise ConfigError('empty build output')
    for p in files:
        data=p.read_bytes(); total+=len(data)
        output.append({'path':str(p.relative_to(root)),'bytes':len(data),'gzip_bytes':len(gzip.compress(data,mtime=0)),'sha256':sha256(p)})
    if type(maximum) is not int or maximum<=0: raise ConfigError('invalid byte budget')
    return {'total_bytes':total,'maximum_bytes':maximum,'passed':total<=maximum,'artifacts':output}


def performance(samples, p95_limit, maximum):
    if not isinstance(samples,list) or not samples or any(type(v) not in (int,float) or not math.isfinite(v) or v<0 for v in samples): raise ConfigError('invalid performance samples')
    if any(type(v) not in (int,float) or not math.isfinite(v) or v<=0 for v in (p95_limit,maximum)): raise ConfigError('invalid performance budgets')
    ordered=sorted(samples);p95=ordered[math.ceil(len(samples)*.95)-1]
    return {'p95':p95,'maximum':max(samples),'passed':p95<=p95_limit and max(samples)<=maximum,'samples':len(samples)}


def exceptions(document, today=None):
    today=today or dt.date.today(); seen=set()
    if not isinstance(document,list): raise ConfigError('exceptions require array')
    for row in document:
        if not isinstance(row,dict): raise ConfigError('invalid exception')
        required={'id','tool','finding','component','owner','reason','reviewed','expires','control'}
        if set(row)!=required or any(not isinstance(v,str) or not v.strip() for v in row.values()): raise ConfigError('exception metadata missing/unknown')
        identity=(row['tool'],row['finding'],row['component'])
        if identity in seen: raise ConfigError('duplicate scoped exception')
        seen.add(identity)
        if dt.date.fromisoformat(row['reviewed'])>today or dt.date.fromisoformat(row['expires'])<=today: raise ConfigError('expired/future exception')
    return {'valid':len(document),'passed':True,'applied':False}


def measure(root, operation, policy_path):
    policy=read_json(inside(root,policy_path))
    if operation=='@coverage':
        source = inside(root,policy['report']).read_text()
        if policy.get('format') == 'jacoco': return coverage_xml(source, policy['minimum'])
        if policy.get('format', 'lcov') != 'lcov': raise ConfigError('unsupported coverage format')
        return lcov(source,policy['minimum'])
    if operation=='@budget':return budget(inside(root,policy['directory']),policy['maximum_bytes'])
    if operation=='@performance':return performance(read_json(inside(root,policy['report']))['samples'],policy['p95_limit'],policy['maximum'])
    if operation=='@exceptions':return exceptions(policy)
    raise ConfigError('unknown measurement')
