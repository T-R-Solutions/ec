# Automação reutilizável

Python 3.11+ e biblioteca padrão. Copie `scripts/automate.py` e a pasta `scripts/automation/` juntas. Não há instalação de dependências nem comandos de projeto durante descoberta/planning. A execução supervisionada está implementada e validada em Linux x86_64; macOS/Windows não estão declarados suportados. Shell legado exige Bash; PowerShell exige seu runtime e módulo de análise verificado.

## Planejar e executar

```bash
python3 /caminho/biblioteca/scripts/automate.py plan --root /caminho/projeto --profile quick
python3 /caminho/biblioteca/scripts/automate.py plan --root /caminho/projeto --config automation.toml --profile full
python3 /caminho/biblioteca/scripts/automate.py run --root /caminho/projeto --config automation.toml --profile quick
python3 /caminho/biblioteca/scripts/automate.py run --root /caminho/projeto --config automation.toml --project backend --task test
```

`--root` é obrigatório e independente de cwd/Git/localização da biblioteca. `--config` é relativo à raiz, sem symlinks nem travessia. `plan` é somente leitura; `run` exige configuração explicitamente indicada. Não há busca ascendente implícita de configuração. TOML inválido, chaves desconhecidas e seleções duplicadas falham. `--task` seleciona uma tarefa; não equivale ao perfil completo. `--project` pode repetir.

Uma entrada de projeto é um diretório e uma seleção de tecnologias comprovadas por manifests/fontes. O CLI mostra manifests e tecnologias observados no plano. Não infere membros de monorepos por heurística de nomes: liste os diretórios reais em `[[projects]]`, incluindo membros/workspaces Cargo, builds Gradle e pacotes frontend quando possuírem políticas independentes. Em raiz mista use seleções explícitas de tecnologias separadas para não confundir duas implementações de `lint`. Nenhum requisito de Git root único; repositórios independentes funcionam como projetos distintos.

## Configuração e autoridade

[Exemplo Rust](examples/rust.toml), [Kotlin](examples/kotlin.toml), [Vue](examples/vue.toml) e [workspace misto](examples/mixed.toml) são modelos de adoção, com pins **a preencher** e comandos a confirmar no consumidor. Os zeros não autenticam uma ferramenta e bloquearão a execução. `tools` mapeia aliases para caminhos absolutos, SHA-256 dos bytes, saída exata de versão, argumentos de versão e texto da revisão de procedência. O hash é conferido **antes** de invocar `--version`. Dependências do próprio executável (runtime, módulos, plugins, bibliotecas) também precisam de revisão; pin do launcher não autentica sua cadeia.

`inputs` mapeia caminhos relativos a hashes revisados. Manifests e inputs de tarefas precisam estar nessa tabela. Acrescente locks, scripts, wrappers, wrapper JAR/properties, configuração de verificação e todos os arquivos que o comando puder interpretar. Mudança de input bloqueia até nova revisão; o runtime verifica antes/depois e registra hashes. Logs incluem versão/configuração e identidade do código da biblioteca; snapshots de scanner têm inventário por hash. Isso não é assinatura nem proteção contra um autor malicioso concorrente: use uma cópia imutável e isolamento de OS para código hostil.

Em `[projects.tasks.nome]`, `argv` é uma lista de argumentos: primeiro um alias em `tools`, demais valores literais. Substituições permitidas: `{root}`, `{project}`, `{report}`. Não há `eval`, interpolação de shell ou busca de executável arbitrário no PATH. Um shell explicitamente configurado continua tendo os poderes do usuário. `scripts` mapeia nomes de tarefa para scripts **existentes** de package.json; `manager` escolhe bun/npm/pnpm/yarn. A configuração é autoridade para executar aquele script e seus hooks. Não usamos npx/bunx nem instalamos pacotes implicitamente. `gradle_tasks` aceita somente nomes reais revisados, por exemplo `test`/`compileKotlin` da fixture com plugin; não inventa detekt/ktlint/Kover/JaCoCo em projetos sem esses plugins.

`env` é uma allowlist explícita, substituindo o ambiente herdado. HOME e TMPDIR são privados por execução; não herda credenciais, BUN_BIN, NODE_OPTIONS, Gradle init scripts ou tokens. Para toolchains, configure PATH/JAVA_HOME/RUSTUP_HOME/CARGO_HOME/GRADLE_USER_HOME conforme o ambiente **revisado**. Isso pode reintroduzir configuração externa: registre seus hashes e restrinja cache writers. Nenhum scanner envia código a serviço externo por padrão; comandos customizados podem acessar rede. O supervisor **não é sandbox**. Execute builds de terceiros sem segredos, com filesystem/egress/CPU/memória limitados por container/VM/bwrap compatível com sua infraestrutura.

## Perfis, tarefas e resultados

| Perfil | Cobertura exigida |
| --- | --- |
| quick | fmt, lint, typecheck |
| full | quick + test, coverage, build, architecture, performance + security |
| security | secrets atuais, history Git, sast, dependencies, licenses/fontes/bans, malware, integrity, ci |
| artifacts | sbom, artifact-vulnerabilities, malware, provenance, artifact-binding |

Não há limiares universais de cobertura/performance nem política de licenças universal. Uma capacidade sem comando/política no consumidor fica `blocked`. Rust padrão usa Cargo fmt/clippy/test/build; Clippy não ativa todas as features arbitrariamente. Preserve flags/features/targets da aplicação configurando a tarefa. Typecheck separado é não aplicável ao Rust quando coberto pela compilação. Vue tem `vue-tsc --noEmit`; Svelte tem `svelte-check`; TS tem `tsc`. Fixe esses executáveis locais e suas dependências. Lint/test/build/coverage/performance/arquitetura frontend dependem dos scripts reais selecionados. Tauri é composição explícita de frontend + Rust + build nativo, sem instalar Bun no Rust isolado.

| Estado de tarefa | Significado | Efeito no exit agregado |
| --- | --- | --- |
| passed | comando/relatório válido satisfaz a política | 0 se todos decididos satisfatoriamente |
| findings | achados violam política | 1 |
| error | falha operacional/parser/relatório/timeout/cancelamento | 2, prioritário |
| blocked | ferramenta/base/input/pré-requisito ausente ou divergente | 3, prioritário a findings |
| not_applicable | tarefa inaplicável com razão explícita | não impede exit 0 |
| omitted | omissão explicitamente configurada com razão | 3; nunca aprovação completa |

As seis categorias são distintas dos cinco estados SDD usados na avaliação desta mudança. Exit bruto do subprocesso fica no resultado; não é perdido ao normalizar o agregado. Cargo 101 pode misturar falha de teste/compilação/infraestrutura, portanto é classificado conservadoramente como erro. `findings_codes` só deve listar códigos documentados de achados; não listar genericamente qualquer falha. Parsers disponíveis: exit, opengrep, osv, gitleaks, yara, sarif, shellcheck, pssa, syft, grype e json-findings. O último exige `{ "complete": true, "findings": [...] }`. SARIF exige invocações concluídas e runs/results válidos. JSON inválido, pacotes ausentes, parsing parcial ou skips operacionais não aprovam.

Resultados ficam em `.local/automation/runs/run-*/results.json`, com resultado por tarefa e stdout/stderr separados. Diretórios 0700, logs/resultados 0600, retenção indefinida até ação explícita do consumidor. Não há limpeza global, rm recursivo ou rotação concorrente. Cada run possui nome aleatório; lock exclusivo por raiz impede dois runs alterando o mesmo workspace. Raízes sobrepostas precisam de isolamento externo; o lock não identifica aliases físicos de subárvores. Timeout padrão 300s; versão 10s; logs combinados 8MiB. Limites ajustáveis em `[limits]`: timeout, log_bytes, file_bytes (32MiB), total_bytes (256MiB). Overflow preserva prefixo e resulta em erro. SIGINT/SIGTERM encerram o grupo, preservam o parcial e marcam tarefas restantes bloqueadas. Sem suporte a daemon que faça setsid para fugir do grupo: isolamento externo é obrigatório nesse caso.

Logs brutos são evidência sensível privada, nunca impressos automaticamente nem enviados. Gitleaks usa `--redact`; não passar segredo em argv/configuração. Ferramentas arbitrárias podem escrever segredos: revise antes de compartilhar; não publique a pasta de run como artefato público sem sanitização. A biblioteca não promete mascarar todos os formatos sem destruir bytes de diagnóstico.

## Segurança e bases

Segredos atuais e histórico são tarefas separadas. Sem Git ou em clone raso, histórico fica bloqueado; refs remotas não obtidas e objetos inalcançáveis não estão cobertos, não há fetch automático. Caminhos Qodana ficam fora dos scans de arquivos. Histórico com esses caminhos exige tarefa explicitamente filtrada; o padrão bloqueia a ambiguidade. Os arquivos dedicados foram realocados para scripts/security e src/tests/scripts/security com bytes preservados e nunca integram o perfil genérico.

Scanners de arquivos recebem snapshots limitados, sem seguir symlinks. Excluem `.git`, `.agents`, `.codex`, `.aws`, `.local`, node_modules, target, build, dist e caches Python, além de caminhos cujo nome inclui qodana. Essas áreas **não foram analisadas pelo scan de fonte**. Liste pacotes instalados/vendor/binaries/distribuições como projetos de artefatos explicitamente separados, com tamanhos/escopo revisados. Gradle plugins/buildscript, Cargo build.rs/proc-macros, scripts npm e bibliotecas nativas são código de terceiros executável: locks/CVEs não provam sua inocuidade. Faça a revisão estática antes de instalação/build; amplie com SBOM e scanner de bytes depois, em ambiente isolado. Não execute amostras suspeitas.

Gitleaks tem regras default locais; Opengrep usa `rules/security.yml` limitado a cinco padrões, com Rust/Kotlin/JS e inspeção textual SFC. **Isso não é cobertura SAST abrangente** nem análise completa de fluxo entre arquivos. Adote regras adicionais somente após verificar licença, versão, fixtures e cobertura das extensões/sourceSets. Não buscar registry `auto`/`p/*` por padrão. Supressões de scanner no consumidor não são herdadas silenciosamente: exigem tarefa explícita revisada. Não há whitelist global de achados.

OSV é o scanner padrão de locks offline; cargo-deny acrescenta licenças/fontes/bans quando `deny.toml` existe. Sem política de licença para Kotlin/JS, a tarefa bloqueia; configure inventário resolvido + avaliador de licença/bans, não uma allowlist inventada. Syft inventaria artefatos e Grype consulta CVEs nesse inventário/target; não duplicar OSV sem ganho de escopo. Binários Rust sem metadados auditable e bibliotecas estaticamente ligadas podem ficar sem identificação de dependências. YARA-X é camada distinta de indicadores; suas duas regras de demonstração não substituem corpus profissional revisado. Arquivos compactados bloqueiam malware até haver política de extração isolada com limites de profundidade/tamanho/tempo/recursos. Ausência de achados não garante ausência de malware; comportamento suspeito exige investigação humana.

`datasets.osv`/`datasets.grype` exigem `path`, `sha256`, `updated` ISO com timezone, `max_age_days`, `license`, `source`. `path` aponta para manifesto JSON `{ "schema": 1, "cache_root": "cache", "files": { "osv-scanner/npm/all.zip": "sha256..." } }`. O manifesto e cada base são conferidos; registre todas as bases dos ecossistemas usados. Cache_root é relativo à raiz. Data futura/expiração/base ausente/hash divergente bloqueia. Não atualizamos bases durante checks. Atualize em etapa separada, revise procedência/licença/delta e novos hashes; offline sem base nunca significa limpo. Online requer tarefa explícita: OSV transmite coordenadas/hash de dependências e pode resolver registries, não precisa transmitir o código inteiro. Documente destinos e metadados antes de habilitar.

Quando houver workflows, configure CI com zizmor offline + actionlint; o padrão bloqueia sem essa composição. Docker/IaC não têm artefatos não excluídos nesta entrada; não foram acrescentados adapters especulativos. Se aparecerem na adoção, configure ferramentas/regras pertinentes e invalide a avaliação de cobertura. CodeQL fica condicionado aos termos do consumidor; GitHub Secret Scanning/Push Protection é complementar condicionado ao plano e consentimento.

Procedência requer Cosign/verificador equivalente com identidade/issuer/builder/source esperados, bundle e digest exatos. `artifact-binding` valida `automation-artifacts.json` (schema=1, inputs e artifacts como mapas caminho/hash, provenance_bundle), depois de `provenance` aprovado. É vínculo de conteúdo, **não prova por si só que o build produziu o artefato nem valida a semântica do bundle**. A tarefa provenance do consumidor deve verificar a assinatura e a política de builder/processo/subject, incluindo correspondência do bundle, inputs e artefatos. Sem ela, bloqueia. Não há assinatura, publicação, importação de certificado ou deploy automáticos.

## Métricas e exceções reutilizáveis

Tarefas internas configuráveis: `argv=["@coverage","policy.json"]`, `@budget`, `@performance`, `@exceptions`. Políticas são inputs revisados da tarefa; também fixe os relatórios quando forem inputs de uma etapa posterior.

- coverage: `{ "report": "lcov.info", "minimum": { "lines": 80, "functions": 75 } }`; valores são exemplos, não defaults. Exige contadores e registros completos; sem denominador dá erro. Para XML de Kover/JaCoCo use `"format": "jacoco"`; só conta os agregados de LINE/METHOD na raiz, sem duplicar pacotes. DTD/entidades são rejeitados.
- budget: `{ "directory": "dist", "maximum_bytes": 33554432 }`; inventário de bytes/gzip/hash, sem heurística Svelte em Vue. Adicione budgets por asset/chunk no consumidor se necessários.
- performance: `{ "report": "samples.json", "p95_limit": 500, "maximum": 1000 }`; report contém samples numéricos. Medição do aplicativo continua no adapter específico, nunca executar binário suspeito como benchmark.
- exceptions: JSON array com id, tool, finding, component exato, owner, reason, reviewed, expires e control. Valida escopo/expiração/duplicidade; **não aplica supressões**. A aplicação deve ser específica no parser/política do consumidor com testes de permissão e rejeição. Registros antigos de exceções de Oryvin não são aceites para outro projeto.

## Migração e contratos preservados

Os wrappers estão em `scripts/rust/`, `scripts/security/`, `scripts/frontend/`, `scripts/tauri/` e nas demais pastas por responsabilidade; encaminham ao núcleo com `--root/--config` obrigatórios. Os caminhos antigos foram substituídos, sem aliases `one/`/`two/`. Veja o [mapa atual](../../doc/structure/automation-layout-20261105/paths.json) e o [mapa histórico de tarefas](../../doc/automation/2026-11-05/compatibility.json). Testes e fixtures das origens estão em `src/tests/scripts/` e `src/fixtures/scripts/`. Posicionais antigos de owners/filtros, env ORYVIN_* e cálculo implícito de raiz foram substituídos por projetos/configuração; argumentos não reconhecidos falham com exit 2. Agregadores não instalam dependências nem exigem ferramentas de tecnologias não selecionadas. `legacy-trivy` e `licensed-codeql` exigem tarefas explícitas; não são selecionados pelo perfil.

Os validadores genéricos de governança, relatórios e exceções foram consolidados em Python. As versões antigas e seus testes defasados saíram da árvore ativa e estão no arquivo de recuperação indicado em scripts/README.md. Analisadores específicos de frontend/desktop, regras e PowerShell permanecem por tecnologia. Guard de layers/owners, budgets específicos, E2E com keyring, Graphify e release signing precisam de política e implementação de adaptação do consumidor; configure tarefas explícitas revisadas ou extraia as funções puras. O gerador com aprovações fixas foi retirado; `scripts/reports/summarize.py` renderiza somente resultados observados. A arquitetura Rust por regex foi retirada: configure uma tarefa nativa separada; o adapter TypeScript cobre somente frontend, com parser oficial Svelte quando há componentes Svelte. O pacote TS antigo depende de ESLint/TypeScript/Bun e de arquivos do aplicativo ausentes; sua suíte não é executável integralmente aqui. A baseline recupera os comandos originais com seus hashes; nenhuma fonte histórica foi descartada.

Atualização: comparar diffs, preservar config/pins/políticas locais, atualizar versões em revisão separada, verificar assinaturas quando disponíveis, rodar testes e requalificar contratos de relatórios antes de mudar pins. SHA do mesmo canal é integridade/reprodutibilidade e não autenticação independente. Nenhuma recomendação de versão da pesquisa é atualizada automaticamente no consumidor.
