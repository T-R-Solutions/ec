"""Explicit read-only planning and configured execution."""
import argparse
import json
import os
import signal
import sys
import threading
from pathlib import Path
from .model import ConfigError, PROFILES, inside, load, sha256
from .adapters import plan


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['plan', 'run'])
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--config', type=Path, help='reviewed TOML, relative to --root')
    parser.add_argument('--profile', choices=list(PROFILES), default='quick')
    parser.add_argument('--project', action='append', default=[])
    parser.add_argument('--task', action='append', default=[])
    args = parser.parse_args(argv)
    runner = None; previous = {}
    try:
        root = args.root.resolve(strict=True)
        if not root.is_dir(): raise ConfigError('root must be a directory')
        if args.config and args.config.is_absolute(): raise ConfigError('config must be relative to --root')
        config_path = inside(root, str(args.config)) if args.config else None
        config, projects = load(root, config_path)
        if args.project:
            if set(args.project) - {p.id for p in projects}: raise ConfigError('unknown project selection')
            projects = [p for p in projects if p.id in args.project]
        names = args.task or PROFILES[args.profile]
        if any(not name or not all(c.isalnum() or c in '._-' for c in name) for name in names): raise ConfigError('invalid task name')
        tasks = [t for p in projects for t in plan(root, p, names, config)]
        if not tasks: raise ConfigError('empty task selection')
        if args.operation == 'plan':
            print(json.dumps({'schema': 1, 'root': str(root), 'projects': [p.__dict__ for p in projects],
                              'profile': args.profile, 'tasks': [t.data() for t in tasks],
                              'executed': False}, indent=2, ensure_ascii=False)); return 0
        if config_path is None: raise ConfigError('run requires explicit --config; plan never grants execution authority')
        if sys.platform != 'linux': raise ConfigError('process supervision currently validated/supported on Linux only')
        from .runtime import Runner, Blocked
        cancellation = threading.Event()
        for sig in (signal.SIGINT, signal.SIGTERM):
            previous[sig] = signal.signal(sig, lambda *_: cancellation.set())
        runner = Runner(root, config, config_path, cancellation)
        runner.acquire()
        for task in tasks:
            runner.run_task(task)
        code = runner.publish()
        print(json.dumps({'results': str(runner.directory / 'results.json'), 'exit_code': code}))
        return code
    except (ConfigError, OSError, ValueError, TypeError, KeyError) as error:
        print(json.dumps({'state': 'error', 'reason': str(error)}), file=sys.stderr); return 2
    except RuntimeError as error:
        print(json.dumps({'state': 'blocked', 'reason': str(error)}), file=sys.stderr); return 3
    finally:
        if runner: runner.close()
        for sig, handler in previous.items(): signal.signal(sig, handler)
