"""Technology-specific plans. Project policy is never inferred from source names."""
from pathlib import Path
import tomllib
from ..model import ConfigError, Project, Task, inside, read_json, walk

SECURITY = {'secrets', 'history', 'sast', 'dependencies', 'licenses', 'malware', 'integrity', 'ci',
            'sbom', 'artifact-vulnerabilities', 'artifact-binding', 'provenance'}


def plan(root: Path, project: Project, names: tuple | list, config: dict) -> list[Task]:
    base = inside(root, project.path)
    files = walk(base)
    tech = set(project.technologies)
    primary = int('rust' in tech) + int('kotlin' in tech) + int(bool(tech & {'javascript', 'typescript', 'vue', 'svelte', 'tauri'}))
    if primary > 1 or (not primary and {'shell', 'powershell'} <= tech):
        raise ConfigError('ambiguous task owners; declare separate projects with explicit technologies, even at the same path')
    result = []
    for name in names:
        task = Task(project.id, name, project.path, state='blocked', reason='consumer task/policy not configured')
        task.inputs = list(project.manifests)
        if name in {'commands-agents', 'skill-contract', 'governance'}:
            policy = base / 'governance.json'
            if policy.is_file():
                task.argv = ['python', str(Path(__file__).parents[2] / 'governance/validators/validate.py'), '--root', '.', '--policy', 'governance.json']
                task.parser = 'json-findings'; task.findings_codes = [1]
                task.inputs.append(str(policy.relative_to(root)))
                task.state = None; task.reason = ''
        elif name in SECURITY:
            from .security import security_task
            security_task(root, project, task, files, config)
        elif 'rust' in tech and name in {'fmt', 'lint', 'test', 'build'}:
            commands = {'fmt': ['fmt', '--all', '--', '--check'],
                        'lint': ['clippy', '--locked', '--all-targets', '--', '-D', 'warnings'],
                        'test': ['test', '--locked', '--all-targets'], 'build': ['build', '--locked']}
            task.argv = ['cargo', *commands[name]]
            task.state = None; task.reason = ''
            # Cargo exit 101 includes both compiler/test failure and operational failure.
            # Treat as error conservatively; never call missing build dependencies findings.
        elif name == 'typecheck' and tech <= {'rust', 'shell', 'powershell'}:
            task.state = 'not_applicable'; task.reason = 'compiler/lint covers this technology; no separate SFC/TS typecheck'
        elif 'kotlin' in tech:
            tasks = project.options.get('gradle_tasks', {}).get(name)
            if tasks is not None:
                if not isinstance(tasks, list) or not tasks or any(not isinstance(t, str) or not t or t.startswith('-') for t in tasks):
                    raise ConfigError('gradle_tasks must list reviewed task names, not options')
                task.argv = ['gradle-wrapper', '--offline', '--no-daemon', *tasks]
                task.state = None; task.reason = ''
                task.inputs.extend(str(p.relative_to(root)) for p in files if p.suffix in {'.gradle', '.kts'} or p.name in {'gradle-wrapper.properties', 'gradle-wrapper.jar', 'gradlew', 'gradle.lockfile', 'verification-metadata.xml'})
        elif tech & {'javascript', 'typescript', 'vue', 'svelte', 'tauri'}:
            package = read_json(base / 'package.json') if (base / 'package.json').is_file() else {}
            script = project.options.get('scripts', {}).get(name)
            if script is not None:
                if not isinstance(script, str) or script.startswith('-') or script not in package.get('scripts', {}):
                    raise ConfigError(f'package script absent or invalid: {script}')
                manager = project.options.get('manager')
                if manager not in {'bun', 'npm', 'pnpm', 'yarn'}: raise ConfigError('select explicit package manager')
                # Never use npx/bunx: these could fetch packages during a check.
                task.argv = [manager, 'run', script]; task.state = None; task.reason = ''
            elif name == 'typecheck' and 'vue' in tech:
                task.argv = ['vue-tsc', '--noEmit']; task.state = None; task.reason = ''
            elif name == 'typecheck' and 'svelte' in tech:
                task.argv = ['svelte-check', '--fail-on-warnings']; task.state = None; task.reason = ''
            elif name == 'typecheck' and 'typescript' in tech:
                task.argv = ['tsc', '--noEmit']; task.state = None; task.reason = ''
        elif 'shell' in tech and name == 'lint':
            task.argv = ['shellcheck', '--format=json', *[str(p.relative_to(base)) for p in files if p.suffix == '.sh']]
            task.parser = 'shellcheck'; task.findings_codes = [1]; task.state = None; task.reason = ''
        elif 'powershell' in tech and name == 'lint':
            # Fixed, shipped script parses AST; never dot-sources target scripts.
            task.argv = ['pwsh', '-NoProfile', '-NonInteractive', '-File', str(Path(__file__).parents[1] / 'powershell-lint.ps1'), str(base)]
            task.parser = 'pssa'; task.findings_codes = [1]; task.state = None; task.reason = ''
        override = project.options.get('tasks', {}).get(name)
        if override is not None:
            for key, value in override.items(): setattr(task, key, value)
            if 'argv' in override: task.state = None; task.reason = ''
        task.timeout = min(task.timeout, config.get('limits', {}).get('timeout', 300))
        if task.parser not in {'exit', 'opengrep', 'osv', 'gitleaks', 'yara', 'sarif', 'shellcheck', 'pssa', 'syft', 'grype', 'json-findings'}:
            raise ConfigError(f'unknown report parser: {task.parser}')
        result.append(task)
    return result
