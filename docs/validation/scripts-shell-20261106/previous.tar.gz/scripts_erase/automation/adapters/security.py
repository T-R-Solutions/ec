"""Separate security surfaces. No online registry rules or implicit installation."""
from pathlib import Path
from ..model import inside


def security_task(root, project, task, files, config):
    name = task.name
    base = inside(root, project.path)
    relative = [str(p.relative_to(base)) for p in files]
    rules = Path(__file__).parents[1] / 'rules'
    commands = {
        'secrets': (['gitleaks', 'dir', '--config', str(rules / 'gitleaks.toml'), '--redact', '--exit-code', '10', '--report-format', 'json', '--report-path', '{report}', '.'], 'gitleaks', [10]),
        'sast': (['opengrep', 'scan', '--config', str(rules / 'security.yml'), '--disable-version-check', '--metrics=off', '--strict', '--no-git-ignore', '--disable-nosem', '--error', '--json', '.'], 'opengrep', [1]),
        'dependencies': (['osv-scanner', 'scan', 'source', '--offline', '--recursive', '--format', 'json', '.'], 'osv', [1]),
        'sbom': (['syft', 'scan', 'dir:.', '-o', 'syft-json'], 'syft', []),
        'artifact-vulnerabilities': (['grype', 'dir:.', '--fail-on', 'low', '-o', 'json'], 'grype', [2]),
    }
    if name in commands:
        task.argv, task.parser, task.findings_codes = commands[name]
        task.state = None; task.reason = ''
        if name in {'dependencies', 'artifact-vulnerabilities'}:
            task.dataset = 'osv' if name == 'dependencies' else 'grype'
    if name == 'history':
        # Actual git validity and shallow status are checked with a pinned git at runtime.
        task.argv = ['gitleaks', 'git', '--redact', '--exit-code', '10', '--report-format', 'json', '--report-path', '{report}', '--log-opts=--all', '.']
        task.parser = 'gitleaks'; task.findings_codes = [10]; task.state = None; task.reason = ''
    if name == 'malware':
        task.argv = ['yr', 'scan', '--output-format', 'json', '--recursive', str(rules / 'suspicious.yar'), '.']
        task.parser = 'yara'; task.state = None; task.reason = ''
    if name == 'licenses' and 'rust' in project.technologies:
        if (base / 'deny.toml').is_file():
            task.argv = ['cargo-deny', '--offline', 'check', 'licenses', 'bans', 'sources']
            task.inputs.append(str((base / 'deny.toml').relative_to(root)))
            task.state = None; task.reason = ''
    if name == 'integrity':
        task.argv = ['@integrity']; task.state = None; task.reason = ''
    if name == 'artifact-binding':
        task.argv = ['@artifact-binding']; task.state = None; task.reason = ''
    if name == 'ci':
        workflows = [p for p in relative if p.startswith('.github/workflows/') and p.endswith(('.yml', '.yaml'))]
        if workflows:
            # A composite task must be supplied to run both; never silently drop actionlint.
            task.reason = 'configure ci task to run pinned zizmor offline and actionlint; both contracts required'
        else:
            task.state = 'not_applicable'; task.reason = 'no non-excluded CI workflows in selected project'
