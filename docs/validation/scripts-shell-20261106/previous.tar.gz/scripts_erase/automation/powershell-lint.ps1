# SPDX-License-Identifier: MIT
param([Parameter(Mandatory=$true)][string]$Root)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
try {
    Import-Module PSScriptAnalyzer -ErrorAction Stop
    $files = @(Get-ChildItem -LiteralPath $Root -Recurse -File -Filter '*.ps1' |
        Where-Object { $_.FullName -notmatch '[\\/](\.git|node_modules|\.local|qodana)[\\/]' })
    $results = @()
    foreach ($file in $files) {
        if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Symlink target refused' }
        $tokens = $null
        $errors = $null
        $null = [System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
        if ($errors.Count -gt 0) { throw 'PowerShell parse errors' }
        $results += @(Invoke-ScriptAnalyzer -LiteralPath $file.FullName -Severity Warning,Error -ErrorAction Stop)
    }
    ConvertTo-Json -InputObject @($results) -Depth 8 -Compress
    if ($results.Count -gt 0) { exit 1 }
    exit 0
} catch {
    Write-Error $_
    exit 2
}
