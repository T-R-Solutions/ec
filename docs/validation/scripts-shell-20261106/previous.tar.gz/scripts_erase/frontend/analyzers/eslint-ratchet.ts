import { readFileSync } from 'node:fs';
import { join, relative, resolve, sep } from 'node:path';
import { ESLint } from 'eslint';

type LintResult = ESLint.LintResult;

const QUALITY_RULES = [
  'complexity',
  'max-depth',
  'max-lines',
  'max-lines-per-function',
  'max-statements'
] as const;

type QualityRule = (typeof QUALITY_RULES)[number];

type QualityBaseline = Readonly<{
  allowances: Readonly<Record<string, Readonly<Partial<Record<QualityRule, number>>>>>;
  version: 1;
}>;

export type QualityCount = Readonly<{
  count: number;
  path: string;
  rule: QualityRule;
}>;

export type QualityRatchetComparison = Readonly<{
  improvements: ReadonlyArray<QualityCount>;
  regressions: ReadonlyArray<QualityCount>;
}>;

const qualityRuleSet: ReadonlySet<string> = new Set(QUALITY_RULES);
const normalizePath = (path: string): string => path.split(sep).join('/');

const isQualityRule = (rule: string | null): rule is QualityRule =>
  rule !== null && qualityRuleSet.has(rule);

const countKey = (path: string, rule: QualityRule): string => `${path}:${rule}`;

export const collectQualityCounts = (
  root: string,
  results: ReadonlyArray<LintResult>
): ReadonlyArray<QualityCount> => {
  const counts = new Map<string, QualityCount>();

  for (const result of results) {
    const path = normalizePath(relative(root, result.filePath));
    for (const message of result.messages) {
      if (message.severity !== 1 || !isQualityRule(message.ruleId)) continue;
      const key = countKey(path, message.ruleId);
      const current = counts.get(key);
      counts.set(key, {
        count: (current?.count ?? 0) + 1,
        path,
        rule: message.ruleId
      });
    }
  }

  return [...counts.values()].sort(
    (left, right) => left.path.localeCompare(right.path) || left.rule.localeCompare(right.rule)
  );
};

const baselineCounts = (baseline: QualityBaseline): ReadonlyArray<QualityCount> =>
  Object.entries(baseline.allowances).flatMap(([path, rules]) =>
    QUALITY_RULES.flatMap((rule) => {
      const count = rules[rule];
      return count === undefined ? [] : [{ count, path, rule }];
    })
  );

export const compareQualityCounts = (
  actual: ReadonlyArray<QualityCount>,
  baseline: QualityBaseline
): QualityRatchetComparison => {
  const actualByKey = new Map(actual.map((entry) => [countKey(entry.path, entry.rule), entry]));
  const baselineByKey = new Map(
    baselineCounts(baseline).map((entry) => [countKey(entry.path, entry.rule), entry])
  );
  const regressions = actual.filter(
    (entry) => entry.count > (baselineByKey.get(countKey(entry.path, entry.rule))?.count ?? 0)
  );
  const improvements = [...baselineByKey.values()].filter(
    (entry) => (actualByKey.get(countKey(entry.path, entry.rule))?.count ?? 0) < entry.count
  );
  return { improvements, regressions };
};

const isQualityRuleRecord = (value: unknown): boolean => {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false;
  return Object.entries(value).every(
    ([rule, count]) => qualityRuleSet.has(rule) && Number.isInteger(count) && Number(count) >= 0
  );
};

const readBaseline = (path: string): QualityBaseline => {
  const value: unknown = JSON.parse(readFileSync(path, 'utf8'));
  if (
    typeof value !== 'object' ||
    value === null ||
    !('version' in value) ||
    value.version !== 1 ||
    !('allowances' in value) ||
    typeof value.allowances !== 'object' ||
    value.allowances === null ||
    Array.isArray(value.allowances) ||
    !Object.values(value.allowances).every(isQualityRuleRecord)
  ) {
    throw new Error(`baseline de qualidade inválido: ${path}`);
  }
  return value as QualityBaseline;
};

const formatCount = ({ count, path, rule }: QualityCount): string => `${path} ${rule}: ${count}`;

const lintErrorCount = (results: ReadonlyArray<LintResult>): number =>
  results.reduce((total, result) => total + result.errorCount + result.fatalErrorCount, 0);

const run = async (): Promise<void> => {
  const root = resolve(import.meta.dir, '../../..');
  const baseline = readBaseline(join(import.meta.dir, '../baselines/quality.json'));
  const eslint = new ESLint({ cwd: root });
  const results = await eslint.lintFiles(['.']);
  const formatter = await eslint.loadFormatter('stylish');
  const formatted = await formatter.format(results);
  if (formatted.trim()) console.log(formatted);

  const comparison = compareQualityCounts(collectQualityCounts(root, results), baseline);
  comparison.improvements.forEach((entry) => {
    console.log(`INFO baseline de qualidade pode ser reduzido: ${formatCount(entry)}`);
  });
  comparison.regressions.forEach((entry) => {
    console.error(`ERROR regressão de qualidade: ${formatCount(entry)}`);
  });

  const errorCount = lintErrorCount(results);
  console.log(
    `ESLint ratchet: ${errorCount} lint error(s), ${comparison.regressions.length} quality regression(s).`
  );
  process.exitCode = errorCount === 0 && comparison.regressions.length === 0 ? 0 : 1;
};

if (import.meta.main) await run();
