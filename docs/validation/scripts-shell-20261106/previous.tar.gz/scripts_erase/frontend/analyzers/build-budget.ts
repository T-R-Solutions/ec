import { gzipSync } from 'node:zlib';
import { readFileSync, readdirSync } from 'node:fs';
import { join, relative, resolve, sep } from 'node:path';

export type BuildArtifact = Readonly<{
  gzipBytes: number | null;
  path: string;
  rawBytes: number;
}>;

export type BuildBudget = Readonly<{
  maxIndividualAudioBytes: number;
  maxIndividualRasterBytes: number;
  maxIndividualSvgGzipBytes: number;
  maxLazyChunkGzipBytes: number;
  maxLazyChunkRawBytes: number;
  maxTotalAudioBytes: number;
  maxTotalBytes: number;
  maxTotalJavaScriptGzipBytes: number;
}>;

export type BuildBudgetEvaluation = Readonly<{
  errors: readonly string[];
  oversizedLazyChunks: readonly BuildArtifact[];
  totalAudioBytes: number;
  totalBytes: number;
  totalJavaScriptGzipBytes: number;
}>;

export const FRONTEND_BUILD_BUDGET: BuildBudget = Object.freeze({
  maxIndividualAudioBytes: 4 * 1024 * 1024,
  maxIndividualRasterBytes: 1280 * 1024,
  maxIndividualSvgGzipBytes: 450 * 1024,
  maxLazyChunkGzipBytes: 250 * 1024,
  maxLazyChunkRawBytes: 900 * 1024,
  maxTotalAudioBytes: 7 * 1024 * 1024,
  maxTotalBytes: 32 * 1024 * 1024,
  maxTotalJavaScriptGzipBytes: 1792 * 1024
});

const normalizePath = (path: string): string => path.split(sep).join('/').replaceAll('\\', '/');

export const isLazyChunkPath = (path: string): boolean =>
  /^_app\/immutable\/chunks\/[^/]+\.js$/.test(normalizePath(path));

const hasExtension = (path: string, pattern: RegExp): boolean =>
  pattern.test(normalizePath(path).toLowerCase());

const isAudioPath = (path: string): boolean => hasExtension(path, /\.(?:aac|flac|m4a|mp3|ogg|wav)$/);
const isJavaScriptPath = (path: string): boolean => hasExtension(path, /\.js$/);
const isRasterPath = (path: string): boolean =>
  hasExtension(path, /\.(?:avif|gif|jpe?g|png|webp)$/);
const isSvgPath = (path: string): boolean => hasExtension(path, /\.svg$/);
const shouldGzipPath = (path: string): boolean =>
  hasExtension(path, /\.(?:css|html|js|json|svg)$/);

const collectFiles = (directory: string): readonly string[] =>
  readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) return collectFiles(path);
    return entry.isFile() ? [path] : [];
  });

export const collectBuildArtifacts = (outputRoot: string): readonly BuildArtifact[] =>
  collectFiles(outputRoot)
    .map((absolutePath) => {
      const contents = readFileSync(absolutePath);
      const path = normalizePath(relative(outputRoot, absolutePath));
      return {
        gzipBytes: shouldGzipPath(path) ? gzipSync(contents, { level: 9 }).byteLength : null,
        path,
        rawBytes: contents.byteLength
      };
    })
    .sort((left, right) => left.path.localeCompare(right.path));

const formatMebibytes = (bytes: number): string => `${(bytes / 1024 / 1024).toFixed(2)} MiB`;
const formatKibibytes = (bytes: number): string => `${(bytes / 1024).toFixed(2)} KiB`;

export const evaluateBuildBudget = (
  artifacts: readonly BuildArtifact[],
  budget: BuildBudget = FRONTEND_BUILD_BUDGET
): BuildBudgetEvaluation => {
  const totalBytes = artifacts.reduce((total, entry) => total + entry.rawBytes, 0);
  const totalAudioBytes = artifacts
    .filter((entry) => isAudioPath(entry.path))
    .reduce((total, entry) => total + entry.rawBytes, 0);
  const totalJavaScriptGzipBytes = artifacts
    .filter((entry) => isJavaScriptPath(entry.path))
    .reduce((total, entry) => total + (entry.gzipBytes ?? 0), 0);
  const oversizedLazyChunks = artifacts.filter(
    (entry) =>
      isLazyChunkPath(entry.path) &&
      (entry.rawBytes > budget.maxLazyChunkRawBytes ||
        (entry.gzipBytes !== null && entry.gzipBytes > budget.maxLazyChunkGzipBytes))
  );
  const errors = [
    ...(totalBytes <= budget.maxTotalBytes
      ? []
      : [
          `payload estatico ${formatMebibytes(totalBytes)} excede ${formatMebibytes(budget.maxTotalBytes)}`
        ]),
    ...(totalAudioBytes <= budget.maxTotalAudioBytes
      ? []
      : [
          `audio total ${formatMebibytes(totalAudioBytes)} excede ${formatMebibytes(budget.maxTotalAudioBytes)}`
        ]),
    ...(totalJavaScriptGzipBytes <= budget.maxTotalJavaScriptGzipBytes
      ? []
      : [
          `JavaScript gzip total ${formatMebibytes(totalJavaScriptGzipBytes)} excede ${formatMebibytes(budget.maxTotalJavaScriptGzipBytes)}`
        ]),
    ...artifacts.flatMap((entry) =>
      isAudioPath(entry.path) && entry.rawBytes > budget.maxIndividualAudioBytes
        ? [
            `audio ${entry.path} (${formatMebibytes(entry.rawBytes)}) excede ${formatMebibytes(budget.maxIndividualAudioBytes)}`
          ]
        : []
    ),
    ...artifacts.flatMap((entry) =>
      isRasterPath(entry.path) && entry.rawBytes > budget.maxIndividualRasterBytes
        ? [
            `raster ${entry.path} (${formatMebibytes(entry.rawBytes)}) excede ${formatMebibytes(budget.maxIndividualRasterBytes)}`
          ]
        : []
    ),
    ...artifacts.flatMap((entry) =>
      isSvgPath(entry.path) &&
      entry.gzipBytes !== null &&
      entry.gzipBytes > budget.maxIndividualSvgGzipBytes
        ? [
            `SVG ${entry.path} (${formatKibibytes(entry.gzipBytes)} gzip) excede ${formatKibibytes(budget.maxIndividualSvgGzipBytes)}`
          ]
        : []
    ),
    ...oversizedLazyChunks.flatMap((entry) => [
      ...(entry.rawBytes <= budget.maxLazyChunkRawBytes
        ? []
        : [
            `chunk lazy ${entry.path} (${formatKibibytes(entry.rawBytes)} raw) excede ${formatKibibytes(budget.maxLazyChunkRawBytes)}`
          ]),
      ...(entry.gzipBytes === null || entry.gzipBytes <= budget.maxLazyChunkGzipBytes
        ? []
        : [
            `chunk lazy ${entry.path} (${formatKibibytes(entry.gzipBytes)} gzip) excede ${formatKibibytes(budget.maxLazyChunkGzipBytes)}`
          ])
    ])
  ];
  return {
    errors,
    oversizedLazyChunks,
    totalAudioBytes,
    totalBytes,
    totalJavaScriptGzipBytes
  };
};

export const runBuildBudget = (outputRoot: string): number => {
  let artifacts: readonly BuildArtifact[];
  try {
    artifacts = collectBuildArtifacts(outputRoot);
  } catch (error) {
    console.error(`ERROR build budget: saida estatica ilegivel em ${outputRoot}: ${String(error)}`);
    return 2;
  }

  const evaluation = evaluateBuildBudget(artifacts);
  evaluation.errors.forEach((error) => console.error(`ERROR build budget: ${error}`));
  console.log(
    `Build budget: payload ${formatMebibytes(evaluation.totalBytes)} / ${formatMebibytes(FRONTEND_BUILD_BUDGET.maxTotalBytes)}; JavaScript ${formatMebibytes(evaluation.totalJavaScriptGzipBytes)} / ${formatMebibytes(FRONTEND_BUILD_BUDGET.maxTotalJavaScriptGzipBytes)} gzip; audio ${formatMebibytes(evaluation.totalAudioBytes)} / ${formatMebibytes(FRONTEND_BUILD_BUDGET.maxTotalAudioBytes)}; ${evaluation.oversizedLazyChunks.length} chunk(s) lazy acima dos limites.`
  );
  return evaluation.errors.length === 0 ? 0 : 1;
};

if (import.meta.main) {
  const root = resolve(import.meta.dir, '../../..');
  process.exitCode = runBuildBudget(resolve(root, Bun.argv[2] ?? '.local/build'));
}
