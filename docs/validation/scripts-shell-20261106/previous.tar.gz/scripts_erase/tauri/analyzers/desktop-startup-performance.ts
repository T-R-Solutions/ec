import { createHash } from 'node:crypto';
import { spawn, type ChildProcess } from 'node:child_process';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { join, resolve } from 'node:path';

export type DesktopStartupBudget = Readonly<{
  maxMilliseconds: number;
  maxP95Milliseconds: number;
}>;

export type DesktopStartupEvaluation = Readonly<{
  errors: readonly string[];
  maximumMilliseconds: number;
  medianMilliseconds: number;
  p95Milliseconds: number;
}>;

export type DesktopStartupMarker = Readonly<{
  elapsedMs: number;
  outcome: 'ready' | 'fallback';
  runIndex: number;
}>;

export const DESKTOP_STARTUP_BUDGET: DesktopStartupBudget = Object.freeze({
  maxMilliseconds: 5_000,
  maxP95Milliseconds: 3_000
});

const SAMPLE_RUNS = 20;
const WARMUP_RUNS = 1;
const POLL_INTERVAL_MILLISECONDS = 20;
const MARKER_TIMEOUT_MILLISECONDS = 10_000;
const MARKER_FILE_NAME = 'desktop-startup-marker.json';
type WindowBackend = 'x11' | 'wayland';

export const selectDesktopWindowBackend = (environment: NodeJS.ProcessEnv): WindowBackend => {
  const configured = environment.GDK_BACKEND;
  if (configured !== undefined && configured !== 'x11' && configured !== 'wayland') {
    throw new Error(`GDK_BACKEND nao suportado pelo benchmark: ${configured}`);
  }
  const selected = configured ?? (environment.WAYLAND_DISPLAY ? 'wayland' : 'x11');
  if (selected === 'x11' && !environment.DISPLAY) {
    throw new Error('DISPLAY ausente para o benchmark X11');
  }
  if (selected === 'wayland' && !environment.WAYLAND_DISPLAY) {
    throw new Error('WAYLAND_DISPLAY ausente para o benchmark Wayland');
  }
  return selected;
};

const nearestRank = (samples: readonly number[], percentile: number): number => {
  const ordered = [...samples].sort((left, right) => left - right);
  return ordered[Math.ceil(ordered.length * percentile) - 1]!;
};

export const evaluateDesktopStartup = (
  samples: readonly number[],
  budget: DesktopStartupBudget = DESKTOP_STARTUP_BUDGET
): DesktopStartupEvaluation => {
  if (samples.length === 0 || samples.some((sample) => !Number.isFinite(sample) || sample < 0)) {
    throw new Error('amostras de startup invalidas');
  }
  const maximumMilliseconds = Math.max(...samples);
  const p95Milliseconds = nearestRank(samples, 0.95);
  return {
    errors: [
      ...(p95Milliseconds <= budget.maxP95Milliseconds
        ? []
        : [
            `startup desktop p95 ${p95Milliseconds.toFixed(2)} ms excede ${budget.maxP95Milliseconds.toFixed(2)} ms`
          ]),
      ...(maximumMilliseconds <= budget.maxMilliseconds
        ? []
        : [
            `startup desktop maximo ${maximumMilliseconds.toFixed(2)} ms excede ${budget.maxMilliseconds.toFixed(2)} ms`
          ])
    ],
    maximumMilliseconds,
    medianMilliseconds: nearestRank(samples, 0.5),
    p95Milliseconds
  };
};

export const parseDesktopStartupMarker = (
  value: unknown,
  expectedRunIndex: number
): DesktopStartupMarker => {
  if (!isRecord(value)) throw new Error('marker de startup deve ser um objeto');
  if (value.schemaVersion !== 1) throw new Error('schema do marker de startup invalido');
  if (value.marker !== 'firstUsefulSurface') {
    throw new Error('endpoint do marker nao representa a primeira superficie util');
  }
  if (
    typeof value.elapsedMs !== 'number' ||
    !Number.isFinite(value.elapsedMs) ||
    value.elapsedMs < 0
  ) {
    throw new Error('elapsedMs do marker de startup invalido');
  }
  if (value.outcome !== 'ready' && value.outcome !== 'fallback') {
    throw new Error('outcome do marker de startup invalido');
  }
  if (value.runIndex !== expectedRunIndex) {
    throw new Error(
      `runIndex do marker de startup invalido: esperado ${expectedRunIndex}, recebido ${String(value.runIndex)}`
    );
  }

  return Object.freeze({
    elapsedMs: value.elapsedMs,
    outcome: value.outcome,
    runIndex: value.runIndex
  });
};

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

const waitForExit = (child: ChildProcess, timeoutMilliseconds: number): Promise<boolean> =>
  new Promise((resolveExit) => {
    if (child.exitCode !== null || child.signalCode !== null) {
      resolveExit(true);
      return;
    }
    const timeout = setTimeout(() => resolveExit(false), timeoutMilliseconds);
    child.once('exit', () => {
      clearTimeout(timeout);
      resolveExit(true);
    });
  });

const stopChild = async (child: ChildProcess): Promise<void> => {
  if (child.exitCode !== null || child.signalCode !== null) return;
  child.kill('SIGTERM');
  if (await waitForExit(child, 1_000)) return;
  child.kill('SIGKILL');
  await waitForExit(child, 1_000);
};

const waitForUsefulSurfaceMarker = async (
  child: ChildProcess,
  markerPath: string,
  runIndex: number
): Promise<DesktopStartupMarker> => {
  const startedAt = performance.now();
  while (performance.now() - startedAt <= MARKER_TIMEOUT_MILLISECONDS) {
    if (existsSync(markerPath)) {
      let payload: unknown;
      try {
        payload = JSON.parse(readFileSync(markerPath, 'utf8'));
      } catch (error) {
        throw new Error('marker de startup ausente ou com JSON invalido', { cause: error });
      }
      return parseDesktopStartupMarker(payload, runIndex);
    }
    if (child.exitCode !== null || child.signalCode !== null) {
      throw new Error(
        `processo desktop encerrou antes do marker util: ${String(child.exitCode ?? child.signalCode)}`
      );
    }
    await Bun.sleep(POLL_INTERVAL_MILLISECONDS);
  }
  throw new Error(`marker de superficie util ausente apos ${MARKER_TIMEOUT_MILLISECONDS} ms`);
};

const measureUsefulSurfaceStartup = async (
  binary: string,
  temporaryRoot: string,
  runIndex: number,
  windowBackend: WindowBackend
): Promise<DesktopStartupMarker> => {
  const runDirectory = mkdtempSync(
    join(temporaryRoot, `sample-${runIndex.toString().padStart(2, '0')}-`)
  );
  const evidenceDirectory = join(runDirectory, 'evidence');
  mkdirSync(evidenceDirectory, { recursive: true });
  const child = spawn(binary, [], {
    env: {
      ...process.env,
      GDK_BACKEND: windowBackend,
      ORYVIN_E2E_EVIDENCE_DIR: evidenceDirectory,
      ORYVIN_E2E_RUN_INDEX: String(runIndex),
      XDG_CACHE_HOME: join(runDirectory, 'cache'),
      XDG_CONFIG_HOME: join(runDirectory, 'config'),
      XDG_DATA_HOME: join(runDirectory, 'data')
    },
    stdio: 'ignore'
  });
  if (child.pid === undefined) throw new Error('processo desktop nao iniciou');
  try {
    return await waitForUsefulSurfaceMarker(
      child,
      join(evidenceDirectory, MARKER_FILE_NAME),
      runIndex
    );
  } finally {
    await stopChild(child);
    rmSync(runDirectory, { recursive: true, force: true });
  }
};

export const runDesktopStartupPerformance = async (
  binaryPath: string,
  jsonOutputPath: string
): Promise<number> => {
  const windowBackend = selectDesktopWindowBackend(process.env);
  const binary = resolve(binaryPath);
  const root = resolve(import.meta.dir, '../../..');
  const temporaryRoot = join(root, '.local/e2e/desktop-startup');
  mkdirSync(temporaryRoot, { recursive: true });
  for (let index = 0; index < WARMUP_RUNS; index += 1) {
    await measureUsefulSurfaceStartup(binary, temporaryRoot, index, windowBackend);
  }
  const markers: DesktopStartupMarker[] = [];
  for (let index = 0; index < SAMPLE_RUNS; index += 1) {
    markers.push(
      await measureUsefulSurfaceStartup(binary, temporaryRoot, WARMUP_RUNS + index, windowBackend)
    );
  }
  const samples = markers.map(({ elapsedMs }) => elapsedMs);
  const evaluation = evaluateDesktopStartup(samples);
  const evidence = {
    benchmark: 'tauri-process-to-first-useful-surface',
    budget: DESKTOP_STARTUP_BUDGET,
    environment: {
      architecture: process.arch,
      binarySha256: createHash('sha256').update(readFileSync(binary)).digest('hex'),
      display: windowBackend === 'x11' ? process.env.DISPLAY : process.env.WAYLAND_DISPLAY,
      platform: process.platform
    },
    evaluation,
    outcomes: markers.map(({ outcome, runIndex }) => ({ outcome, runIndex })),
    samplesMilliseconds: samples,
    workload: {
      isolatedProfilePerSample: true,
      marker: 'firstUsefulSurface',
      pollIntervalMilliseconds: POLL_INTERVAL_MILLISECONDS,
      sampleRuns: SAMPLE_RUNS,
      warmupRuns: WARMUP_RUNS,
      windowBackend
    }
  } as const;
  await Bun.write(resolve(jsonOutputPath), `${JSON.stringify(evidence, null, 2)}\n`);
  evaluation.errors.forEach((error) => console.error(`ERROR performance budget: ${error}`));
  console.log(
    `Startup desktop util: p50 ${evaluation.medianMilliseconds.toFixed(2)} ms, p95 ${evaluation.p95Milliseconds.toFixed(2)} / ${DESKTOP_STARTUP_BUDGET.maxP95Milliseconds.toFixed(2)} ms, max ${evaluation.maximumMilliseconds.toFixed(2)} / ${DESKTOP_STARTUP_BUDGET.maxMilliseconds.toFixed(2)} ms.`
  );
  return evaluation.errors.length === 0 ? 0 : 1;
};

if (import.meta.main) {
  const binaryPath = Bun.argv[2];
  const jsonOutputPath = Bun.argv[3];
  if (binaryPath === undefined || jsonOutputPath === undefined) {
    throw new Error('uso: desktop-startup-performance.ts <binario-e2e> <evidencia.json>');
  }
  process.exitCode = await runDesktopStartupPerformance(binaryPath, jsonOutputPath);
}
