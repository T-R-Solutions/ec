export type DesktopNavigationBudget = Readonly<{
  maxMilliseconds: number;
  maxP95Milliseconds: number;
}>;

export type DesktopNavigationEvaluation = Readonly<{
  errors: readonly string[];
  maximumMilliseconds: number;
  medianMilliseconds: number;
  p95Milliseconds: number;
}>;

export const DESKTOP_NAVIGATION_BUDGET: DesktopNavigationBudget = Object.freeze({
  maxMilliseconds: 1_000,
  maxP95Milliseconds: 500
});

const nearestRank = (samples: readonly number[], percentile: number): number => {
  const ordered = [...samples].sort((left, right) => left - right);
  return ordered[Math.ceil(ordered.length * percentile) - 1]!;
};

export const evaluateDesktopNavigation = (
  samples: readonly number[],
  budget: DesktopNavigationBudget = DESKTOP_NAVIGATION_BUDGET
): DesktopNavigationEvaluation => {
  if (samples.length === 0 || samples.some((sample) => !Number.isFinite(sample) || sample < 0)) {
    throw new Error('amostras de navegação desktop inválidas');
  }
  const maximumMilliseconds = Math.max(...samples);
  const p95Milliseconds = nearestRank(samples, 0.95);
  return {
    errors: [
      ...(p95Milliseconds <= budget.maxP95Milliseconds
        ? []
        : [
            `navegação desktop p95 ${p95Milliseconds.toFixed(2)} ms excede ${budget.maxP95Milliseconds.toFixed(2)} ms`
          ]),
      ...(maximumMilliseconds <= budget.maxMilliseconds
        ? []
        : [
            `navegação desktop máxima ${maximumMilliseconds.toFixed(2)} ms excede ${budget.maxMilliseconds.toFixed(2)} ms`
          ])
    ],
    maximumMilliseconds,
    medianMilliseconds: nearestRank(samples, 0.5),
    p95Milliseconds
  };
};
