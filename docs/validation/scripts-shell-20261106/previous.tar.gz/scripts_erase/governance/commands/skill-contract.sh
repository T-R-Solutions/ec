#!/usr/bin/env bash
set -euo pipefail
LIBRARY_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)"
exec python3 "$LIBRARY_DIR/automate.py" run --task skill-contract "$@"
