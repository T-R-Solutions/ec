#!/usr/bin/env python3
"""Validate explicit consumer file contracts without executing inspected content."""
import argparse
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from automation.model import ConfigError, inside, read_json


def validate(root, policy):
    if not isinstance(policy, dict) or set(policy) != {'schema', 'rules'} or policy['schema'] != 1:
        raise ConfigError('policy requires schema=1 and rules')
    if not isinstance(policy['rules'], list) or not policy['rules']:
        raise ConfigError('nonempty rules required')
    results = []
    identifiers = set()
    for rule in policy['rules']:
        if not isinstance(rule, dict) or set(rule) - {'id', 'path', 'contains', 'forbidden', 'max_words'}:
            raise ConfigError('invalid rule keys')
        if not isinstance(rule.get('id'), str) or not rule['id'] or rule['id'] in identifiers:
            raise ConfigError('unique nonempty rule id required')
        identifiers.add(rule['id'])
        # Missing declared file is a finding; traversal/symlinks are configuration errors.
        path = inside(root, rule.get('path'), exists=False)
        if not path.is_file():
            results.append({'rule': rule['id'], 'path': rule['path'], 'reason': 'required file missing'})
            continue
        if path.stat().st_size > 2 * 1024 * 1024:
            raise ConfigError('governance input exceeds 2 MiB')
        text = path.read_text(encoding='utf8')
        for key in ('contains', 'forbidden'):
            patterns = rule.get(key, [])
            if not isinstance(patterns, list) or any(not isinstance(p, str) or not p for p in patterns):
                raise ConfigError('patterns require nonempty strings')
            # Literal matching is deliberate: no consumer regex with unbounded backtracking.
            for pattern in patterns:
                matched = pattern in text
                if (key == 'contains' and not matched) or (key == 'forbidden' and matched):
                    results.append({'rule': rule['id'], 'path': rule['path'], 'reason': key, 'pattern': pattern})
        maximum = rule.get('max_words')
        if maximum is not None:
            if type(maximum) is not int or maximum <= 0:
                raise ConfigError('max_words must be a positive integer')
            if len(text.split()) > maximum:
                results.append({'rule': rule['id'], 'path': rule['path'], 'reason': 'word budget exceeded'})
    return results


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--policy', required=True, help='JSON relative to root')
    args = parser.parse_args(argv)
    try:
        root = args.root.resolve(strict=True)
        if not root.is_dir(): raise ConfigError('root must be a directory')
        results = validate(root, read_json(inside(root, args.policy)))
        print(json.dumps({'complete': True, 'findings': results}, ensure_ascii=False))
        return int(bool(results))
    except (OSError, ValueError, TypeError) as error:
        print(json.dumps({'complete': False, 'state': 'error', 'reason': str(error)}))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
