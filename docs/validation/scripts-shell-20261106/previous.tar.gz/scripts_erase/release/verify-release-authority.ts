export type ReleaseAuthorityInput = {
  readonly platform: string | undefined;
  readonly updaterPrivateKey: string | undefined;
  readonly updaterPrivateKeyPassword: string | undefined;
  readonly appleCertificate: string | undefined;
  readonly appleCertificatePassword: string | undefined;
  readonly appleSigningIdentity: string | undefined;
  readonly appleId: string | undefined;
  readonly applePassword: string | undefined;
  readonly appleTeamId: string | undefined;
  readonly windowsCertificate: string | undefined;
  readonly windowsCertificatePassword: string | undefined;
};

export const findMissingReleaseAuthorities = (input: ReleaseAuthorityInput): readonly string[] => {
  const required = [
    ['TAURI_SIGNING_PRIVATE_KEY', input.updaterPrivateKey],
    ['TAURI_SIGNING_PRIVATE_KEY_PASSWORD', input.updaterPrivateKeyPassword]
  ] as const;

  const platformRequired =
    input.platform === 'macos'
      ? ([
          ['APPLE_CERTIFICATE', input.appleCertificate],
          ['APPLE_CERTIFICATE_PASSWORD', input.appleCertificatePassword],
          ['APPLE_SIGNING_IDENTITY', input.appleSigningIdentity],
          ['APPLE_ID', input.appleId],
          ['APPLE_PASSWORD', input.applePassword],
          ['APPLE_TEAM_ID', input.appleTeamId]
        ] as const)
      : input.platform === 'windows'
        ? ([
            ['WINDOWS_CERTIFICATE', input.windowsCertificate],
            ['WINDOWS_CERTIFICATE_PASSWORD', input.windowsCertificatePassword]
          ] as const)
        : ([] as const);

  return [...required, ...platformRequired]
    .filter(([, value]) => value?.trim().length === 0 || value === undefined)
    .map(([name]) => name);
};

const verifyReleaseAuthority = (): void => {
  const missing = findMissingReleaseAuthorities({
    platform: process.env.ORYVIN_RELEASE_PLATFORM,
    updaterPrivateKey: process.env.TAURI_SIGNING_PRIVATE_KEY,
    updaterPrivateKeyPassword: process.env.TAURI_SIGNING_PRIVATE_KEY_PASSWORD,
    appleCertificate: process.env.APPLE_CERTIFICATE,
    appleCertificatePassword: process.env.APPLE_CERTIFICATE_PASSWORD,
    appleSigningIdentity: process.env.APPLE_SIGNING_IDENTITY,
    appleId: process.env.APPLE_ID,
    applePassword: process.env.APPLE_PASSWORD,
    appleTeamId: process.env.APPLE_TEAM_ID,
    windowsCertificate: process.env.WINDOWS_CERTIFICATE,
    windowsCertificatePassword: process.env.WINDOWS_CERTIFICATE_PASSWORD
  });
  if (missing.length > 0) {
    throw new Error(`Missing release authorities: ${missing.join(', ')}`);
  }
};

if (import.meta.main) verifyReleaseAuthority();
