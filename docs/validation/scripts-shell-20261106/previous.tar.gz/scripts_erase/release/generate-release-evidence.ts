import { createHash } from 'node:crypto';
import { mkdir, readFile, stat, writeFile } from 'node:fs/promises';
import { basename, relative, resolve, sep } from 'node:path';

type CycloneDxHash = { readonly alg: 'SHA-256' | 'SHA-512'; readonly content: string };
type CycloneDxComponent = {
  readonly type: 'application' | 'library';
  readonly 'bom-ref': string;
  readonly name: string;
  readonly version: string;
  readonly purl?: string;
  readonly hashes?: readonly CycloneDxHash[];
};

type BunLock = {
  readonly workspaces?: Readonly<Record<string, { readonly name?: string }>>;
  readonly packages?: Readonly<Record<string, readonly unknown[]>>;
};

type CargoLock = {
  readonly package?: readonly {
    readonly name?: unknown;
    readonly version?: unknown;
    readonly checksum?: unknown;
  }[];
};

export const createReleaseSbom = (
  bunLock: BunLock,
  cargoLock: CargoLock,
  appVersion: string
): Readonly<Record<string, unknown>> => {
  const components = [...createBunComponents(bunLock), ...createCargoComponents(cargoLock)].sort(
    (left, right) => left['bom-ref'].localeCompare(right['bom-ref'])
  );
  const application: CycloneDxComponent = {
    type: 'application',
    'bom-ref': `pkg:cargo/oryvin-nexus@${appVersion}`,
    name: 'oryvin-nexus',
    version: appVersion
  };

  return {
    bomFormat: 'CycloneDX',
    specVersion: '1.6',
    version: 1,
    metadata: { component: application },
    components,
    dependencies: [
      {
        ref: application['bom-ref'],
        dependsOn: components.map((component) => component['bom-ref'])
      }
    ]
  };
};

const createBunComponents = (lock: BunLock): readonly CycloneDxComponent[] =>
  Object.values(lock.packages ?? {}).flatMap((entry) => {
    const resolution = entry[0];
    const integrity = entry[3];
    if (typeof resolution !== 'string') return [];
    const separator = resolution.lastIndexOf('@');
    if (separator <= 0 || separator === resolution.length - 1) return [];
    const name = resolution.slice(0, separator);
    const version = resolution.slice(separator + 1);
    const hash = toBunIntegrityHash(integrity);
    return [
      {
        type: 'library',
        'bom-ref': `pkg:npm/${encodeURIComponent(name)}@${version}`,
        name,
        version,
        purl: `pkg:npm/${encodeURIComponent(name)}@${version}`,
        ...(hash === null ? {} : { hashes: [hash] })
      }
    ];
  });

const createCargoComponents = (lock: CargoLock): readonly CycloneDxComponent[] =>
  (lock.package ?? []).flatMap((entry) => {
    if (typeof entry.name !== 'string' || typeof entry.version !== 'string') return [];
    const purl = `pkg:cargo/${entry.name}@${entry.version}`;
    const checksum =
      typeof entry.checksum === 'string' && /^[a-f\d]{64}$/u.test(entry.checksum)
        ? ([{ alg: 'SHA-256', content: entry.checksum }] as const)
        : undefined;
    return [
      {
        type: 'library',
        'bom-ref': purl,
        name: entry.name,
        version: entry.version,
        purl,
        ...(checksum === undefined ? {} : { hashes: checksum })
      }
    ];
  });

const toBunIntegrityHash = (integrity: unknown): CycloneDxHash | null => {
  if (typeof integrity !== 'string' || !integrity.startsWith('sha512-')) return null;
  const base64 = integrity.slice('sha512-'.length);
  try {
    return { alg: 'SHA-512', content: Buffer.from(base64, 'base64').toString('hex') };
  } catch {
    return null;
  }
};

const parseArtifactPaths = (value: string | undefined): readonly string[] => {
  if (value === undefined) throw new Error('ORYVIN_RELEASE_ARTIFACT_PATHS is required');
  const parsed: unknown = JSON.parse(value);
  if (
    !Array.isArray(parsed) ||
    parsed.length === 0 ||
    parsed.some((item) => typeof item !== 'string')
  ) {
    throw new Error('ORYVIN_RELEASE_ARTIFACT_PATHS must be a non-empty JSON string array');
  }
  return parsed;
};

const safeIdentifier = (value: string | undefined, name: string): string => {
  if (value === undefined || !/^[a-z0-9_-]+$/u.test(value)) {
    throw new Error(
      `${name} must contain only lowercase letters, numbers, hyphens, or underscores`
    );
  }
  return value;
};

const generateReleaseEvidence = async (): Promise<void> => {
  const root = resolve('.');
  const cargoTarget = resolve(root, '.local/cargo/target');
  const platform = safeIdentifier(process.env.ORYVIN_RELEASE_PLATFORM, 'ORYVIN_RELEASE_PLATFORM');
  const target = safeIdentifier(process.env.ORYVIN_RELEASE_TARGET, 'ORYVIN_RELEASE_TARGET');
  const appVersion = process.env.ORYVIN_RELEASE_VERSION?.trim();
  if (appVersion === undefined || appVersion.length === 0) {
    throw new Error('ORYVIN_RELEASE_VERSION is required');
  }

  const artifactPaths = parseArtifactPaths(process.env.ORYVIN_RELEASE_ARTIFACT_PATHS).map((path) =>
    resolve(root, path)
  );
  const checksums = await Promise.all(
    artifactPaths.map(async (path) => {
      const relativeToTarget = relative(cargoTarget, path);
      if (relativeToTarget.startsWith(`..${sep}`) || relativeToTarget === '..') {
        throw new Error('Release artifact escaped .local/cargo/target');
      }
      if (!(await stat(path)).isFile()) throw new Error('Release artifact must be a file');
      return `${createHash('sha256')
        .update(await readFile(path))
        .digest('hex')}  ${basename(path)}`;
    })
  );

  const bunLock = Bun.JSONC.parse(await readFile(resolve(root, 'bun.lock'), 'utf8')) as BunLock;
  const cargoLock = Bun.TOML.parse(
    await readFile(resolve(root, 'src-tauri/Cargo.lock'), 'utf8')
  ) as CargoLock;
  const outputDirectory = resolve(root, `.local/release/evidence/${platform}-${target}`);
  await mkdir(outputDirectory, { recursive: true });
  await writeFile(
    resolve(outputDirectory, `oryvin-nexus-${appVersion}-${platform}-${target}.sha256`),
    `${checksums.sort().join('\n')}\n`,
    { mode: 0o600 }
  );
  await writeFile(
    resolve(outputDirectory, `oryvin-nexus-${appVersion}-${platform}-${target}.cdx.json`),
    `${JSON.stringify(createReleaseSbom(bunLock, cargoLock, appVersion), null, 2)}\n`,
    { mode: 0o600 }
  );
};

if (import.meta.main) await generateReleaseEvidence();
