$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if (-not [string]::IsNullOrWhiteSpace($env:ORYVIN_WINDOWS_CERTIFICATE_THUMBPRINT)) {
  $certificatePath = Join-Path `
    'Cert:\CurrentUser\My' `
    $env:ORYVIN_WINDOWS_CERTIFICATE_THUMBPRINT
  if (Test-Path $certificatePath) {
    Remove-Item -Force $certificatePath
  }
}

$certificateDirectory = Join-Path '.local' 'release/certificate'
if (Test-Path $certificateDirectory) {
  Remove-Item -Recurse -Force $certificateDirectory
}
