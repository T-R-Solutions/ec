import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

export type UpdaterConfigInput = {
  readonly endpoint: string | undefined;
  readonly publicKey: string | undefined;
  readonly releaseChannel: string | undefined;
  readonly platform: string | undefined;
  readonly windowsCertificateThumbprint?: string | undefined;
  readonly windowsTimestampUrl?: string | undefined;
};

type TauriUpdaterOverlay = {
  readonly bundle: {
    readonly createUpdaterArtifacts: true;
    readonly windows?: {
      readonly certificateThumbprint: string;
      readonly digestAlgorithm: 'sha256';
      readonly timestampUrl: string;
    };
  };
  readonly plugins: {
    readonly updater: {
      readonly endpoints: readonly [string];
      readonly pubkey: string;
      readonly dangerousInsecureTransportProtocol: false;
    };
  };
};

export const createTauriUpdaterConfig = (input: UpdaterConfigInput): TauriUpdaterOverlay => {
  const endpoint = requireHttpsUrl(input.endpoint, 'ORYVIN_UPDATER_ENDPOINT');
  const publicKey = requireValue(input.publicKey, 'ORYVIN_UPDATER_PUBLIC_KEY');
  const releaseChannel = requireValue(input.releaseChannel, 'ORYVIN_RELEASE_CHANNEL');
  if (releaseChannel !== 'stable') {
    throw new Error('ORYVIN_RELEASE_CHANNEL must be stable');
  }

  const windows =
    input.platform === 'windows'
      ? {
          certificateThumbprint: requireValue(
            input.windowsCertificateThumbprint,
            'ORYVIN_WINDOWS_CERTIFICATE_THUMBPRINT'
          ),
          digestAlgorithm: 'sha256' as const,
          timestampUrl: requireHttpsUrl(input.windowsTimestampUrl, 'ORYVIN_WINDOWS_TIMESTAMP_URL')
        }
      : undefined;

  return {
    bundle: {
      createUpdaterArtifacts: true,
      ...(windows === undefined ? {} : { windows })
    },
    plugins: {
      updater: {
        endpoints: [endpoint],
        pubkey: publicKey,
        dangerousInsecureTransportProtocol: false
      }
    }
  };
};

const requireValue = (value: string | undefined, name: string): string => {
  const normalized = value?.trim();
  if (normalized === undefined || normalized.length === 0) {
    throw new Error(`${name} is required`);
  }
  return normalized;
};

const requireHttpsUrl = (value: string | undefined, name: string): string => {
  const normalized = requireValue(value, name);
  let url: URL;
  try {
    url = new URL(normalized);
  } catch {
    throw new Error(`${name} must be a valid URL`);
  }

  if (
    url.protocol !== 'https:' ||
    url.username.length > 0 ||
    url.password.length > 0 ||
    url.hash.length > 0
  ) {
    throw new Error(`${name} must be an HTTPS URL without credentials or fragment`);
  }
  return normalized;
};

const writeUpdaterConfig = async (): Promise<void> => {
  const config = createTauriUpdaterConfig({
    endpoint: process.env.ORYVIN_UPDATER_ENDPOINT,
    publicKey: process.env.ORYVIN_UPDATER_PUBLIC_KEY,
    releaseChannel: process.env.ORYVIN_RELEASE_CHANNEL,
    platform: process.env.ORYVIN_RELEASE_PLATFORM,
    windowsCertificateThumbprint: process.env.ORYVIN_WINDOWS_CERTIFICATE_THUMBPRINT,
    windowsTimestampUrl: process.env.ORYVIN_WINDOWS_TIMESTAMP_URL
  });
  const outputDirectory = resolve('.local/release');
  await mkdir(outputDirectory, { recursive: true });
  await writeFile(
    resolve(outputDirectory, 'tauri.updater.conf.json'),
    `${JSON.stringify(config, null, 2)}\n`,
    { mode: 0o600 }
  );
};

if (import.meta.main) {
  await writeUpdaterConfig();
}
