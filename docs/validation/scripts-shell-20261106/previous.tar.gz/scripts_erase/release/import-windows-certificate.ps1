$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if ([string]::IsNullOrWhiteSpace($env:WINDOWS_CERTIFICATE)) {
  throw 'WINDOWS_CERTIFICATE is required.'
}
if ([string]::IsNullOrWhiteSpace($env:WINDOWS_CERTIFICATE_PASSWORD)) {
  throw 'WINDOWS_CERTIFICATE_PASSWORD is required.'
}
if ([string]::IsNullOrWhiteSpace($env:GITHUB_ENV)) {
  throw 'GITHUB_ENV is required.'
}

$certificateDirectory = Join-Path '.local' 'release/certificate'
$certificatePath = Join-Path $certificateDirectory 'certificate.pfx'
New-Item -ItemType Directory -Force -Path $certificateDirectory | Out-Null
[IO.File]::WriteAllBytes(
  $certificatePath,
  [Convert]::FromBase64String($env:WINDOWS_CERTIFICATE)
)
$password = ConvertTo-SecureString `
  -String $env:WINDOWS_CERTIFICATE_PASSWORD `
  -Force `
  -AsPlainText
$certificate = Import-PfxCertificate `
  -FilePath $certificatePath `
  -CertStoreLocation 'Cert:\CurrentUser\My' `
  -Password $password

if ($null -eq $certificate -or [string]::IsNullOrWhiteSpace($certificate.Thumbprint)) {
  throw 'The Windows signing certificate could not be imported.'
}

"ORYVIN_WINDOWS_CERTIFICATE_THUMBPRINT=$($certificate.Thumbprint)" |
  Out-File -FilePath $env:GITHUB_ENV -Append -Encoding utf8
