# Jornadas da interface

Estado: diretório reservado; não há cenários executáveis.

Reservado a fluxos de navegador cujo escopo seja a interface. Classificar explicitamente como interface com API simulada ou interface integrada com backend real. Ponta a ponta da plataforma com Agent pertence a `application/integration/tests/e2e/`; não reproduzir aqui o mesmo cenário.

Runner, fixtures, dependências de ambiente, descoberta e comandos permanecem pendentes. Não criar testes vazios para preencher este diretório.

[Política de testes](../../../../../docs/development/testing.md) · [Organização](../../../../../docs/architecture/application-layout.md).
