# ec-server-extensions — Integrações e extensões

Estado: estrutura documental criada; código e testes de produto ainda não implementados.

## Responsabilidade e limite

Conectores VCS, referências a credenciais, webhooks/triggers e gestão de manifests, compatibilidade e ciclo de vida de plugins, em módulos internos distintos.

Plugin instalado não significa ativo, confiável ou isolado. Integração não concede execução arbitrária no Server.

Derivação: [norma de produto](../../../../../docs/EC-REGRAS-DE-DESIGN-E-PRODUTO.md), §§11, 18, 23; [contexto arquitetural](../../../../../docs/architecture/context.md).

## Dependências e interface pública planejadas

Dependências diretas permitidas entre crates Ec: **ec-server-access, ec-server-configuration, ec-server-projects, ec-server-orchestration**. Bibliotecas externas ainda não foram escolhidas. Nunca depender do crate de composição.

Validadores dos recursos de integração/plugin, recepção autenticada de eventos e comandos de gestão de extensões. Nomes de tipos, assinaturas, schema e serialização permanecem pendentes. Expor contratos mínimos pela raiz da biblioteca; módulos de implementação permanecem privados. Adaptadores de I/O ficam internos ao domínio proprietário, implementam portas desse domínio e são conectados pela composição.

## Organização e testes

- `src/`: código futuro e testes unitários próximos ao código, sob `#[cfg(test)]`.
- `tests/`: integração futura pela interface pública; testes com fronteira de processo explícita podem ter escopo ponta a ponta do componente.
- Cenários de integração entre crates do mesmo monólito pertencem ao `tests/` do crate de composição; entre Server e Agent pertencem a `application/integration/tests/`.

Cenários a especificar e implementar: Rejeitar evento inválido e versão incompatível; execução de plugins externos depende de evidência específica de isolamento. Ainda não há testes executáveis ou cobertura.

## Referências e manutenção

[Organização da aplicação](../../../../../docs/architecture/application-layout.md) · [Política de testes](../../../../../docs/development/testing.md) · [Autoridades](../../../../../docs/constitution.md).

Atualize este README quando mudar a responsabilidade, a interface pública, uma dependência permitida ou o modo de verificar este módulo. Comandos de produto só serão incluídos após implementação e execução verificadas.
