# ec-agent-execution — Execução de etapas

Estado: estrutura documental criada; código e testes de produto ainda não implementados.

## Responsabilidade e limite

Ciclo de vida de processos, saída drenada, deadlines, cancelamento e aplicação da política de isolamento e limites.

Não implementa scheduler global nem garante segurança apenas por executar em processo separado.

Derivação: [norma de produto](../../../../docs/EC-REGRAS-DE-DESIGN-E-PRODUTO.md), context.md; norma de produto §§20, 22, 23; [contexto arquitetural](../../../../docs/architecture/context.md).

## Dependências e interface pública planejadas

Dependências diretas permitidas entre crates Ec: **ec-agent-workspace, ec-agent-reporting**. Bibliotecas externas ainda não foram escolhidas. Nunca depender do crate de composição.

Pedido de execução identificado por tentativa e revisão, sinais de controle e resultado local com causa de término. Nomes de tipos, assinaturas, schema e serialização permanecem pendentes. Expor contratos mínimos pela raiz da biblioteca; módulos de implementação permanecem privados. Adaptadores de I/O ficam internos ao domínio proprietário, implementam portas desse domínio e são conectados pela composição.

## Organização e testes

- `src/`: código futuro e testes unitários próximos ao código, sob `#[cfg(test)]`.
- `tests/`: integração futura pela interface pública; testes com fronteira de processo explícita podem ter escopo ponta a ponta do componente.
- Cenários de integração entre crates do mesmo monólito pertencem ao `tests/` do crate de composição; entre Server e Agent pertencem a `application/integration/tests/`.

Cenários a especificar e implementar: Exercitar saída volumosa, timeout, cancelamento e falha de preparação sem mascarar o estado final. Ainda não há testes executáveis ou cobertura.

## Referências e manutenção

[Organização da aplicação](../../../../docs/architecture/application-layout.md) · [Política de testes](../../../../docs/development/testing.md) · [Autoridades](../../../../docs/constitution.md).

Atualize este README quando mudar a responsabilidade, a interface pública, uma dependência permitida ou o modo de verificar este módulo. Comandos de produto só serão incluídos após implementação e execução verificadas.
