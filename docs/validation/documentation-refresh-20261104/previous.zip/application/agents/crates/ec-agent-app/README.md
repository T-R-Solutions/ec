# ec-agent-app — composição

Estado: estrutura documental criada; código e testes de produto ainda não implementados.

Crate técnico reservado ao ponto de entrada do monólito, inicialização, construção de adaptadores e conexão das interfaces dos domínios. Sua existência separa composição de regras de negócio; não cria outro serviço.

## Dependências e interface pública planejadas

Pode depender dos crates `ec-agent-control`, `ec-agent-workspace`, `ec-agent-execution`, `ec-agent-reporting`. Nenhum deles pode depender deste crate. A superfície pública será o ciclo de vida do executável; argumentos, configuração de bootstrap e sinais suportados ainda precisam de especificação. Não concentrar regras de negócio no ponto de entrada.

## Organização e testes

`src/` receberá composição e testes unitários de suas decisões locais. `tests/` receberá integração entre domínios/adaptadores deste monólito e cenários de processo do componente. A descoberta destes testes será configurada no workspace futuro. Jornadas que atravessam Server/Agent/frontend pertencem ao `application/integration/tests/`.

## Referências e manutenção

[Organização da aplicação](../../../../docs/architecture/application-layout.md) · [Política de testes](../../../../docs/development/testing.md) · [Autoridades](../../../../docs/constitution.md).

Atualize este README quando mudar a responsabilidade, a interface pública, uma dependência permitida ou o modo de verificar este módulo. Comandos de produto só serão incluídos após implementação e execução verificadas.
