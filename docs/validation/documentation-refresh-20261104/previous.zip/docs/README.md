# Documentação do Ec

Leitura vigente em 2026-11-04. O produto está em pesquisa e estrutura documental; os utilitários de governança são executáveis. A [entrada do repositório](../README.md) apresenta o estado e os comandos disponíveis.

## Produto, arquitetura e contratos

| Documento | Pergunta que responde |
| --- | --- |
| [Visão funcional e técnica](architecture/application-overview.md) | O que é o Ec, quais funcionalidades prevê e onde cada responsabilidade será implementada? |
| [Contratos](architecture/contracts.md) | Quais invariantes estão estabelecidos e o que ainda falta especificar e demonstrar? |
| [Contexto arquitetural](architecture/context.md) | Quais são os componentes e as decisões pendentes? |
| [Organização física](architecture/application-layout.md) | Onde ficam módulos, composição, dependências e testes? |
| [Estado e escopo](../sdd/project.md) | O que existe efetivamente neste checkout? |

## Autoridades e decisões

As [autoridades](constitution.md) definem a precedência documental. A síntese de contratos não substitui as [normas de produto](EC-REGRAS-DE-DESIGN-E-PRODUTO.md) nem as [normas de telas e imagens](EC-REGRAS-CRIACAO-DE-TELAS-E-IMAGENS.md).

- [ADR-001](decisions/ADR-001-skills-sdd-adoption.md): adoção de skills e SDD; decisões de retenção das fontes.
- [ADR-002](decisions/ADR-002-application-layout.md): organização inicial da aplicação e correções de caminhos.
- [Proposta de comunicação e validação](ec-arquitetura-comunicacao-e-validacao.md): gRPC/Protobuf, SQLite local e ensaios de escala; não adotados nem implementados.

## Contribuição e verificações

- [AGENTS.md](../AGENTS.md), [workflow SDD](../sdd/workflow.md) e [evidências](../sdd/evidence.md).
- [Política de testes](development/testing.md): localização, escopo e comandos reais.
- [Análise das skills](development/skills-analysis.md), [instalação](development/skill-installation.md) e [catálogo de seleção](../sdd/chain/README.md).
- [Análise desta revisão](validation/application-analysis-20261104/report.md) e [auditoria dos caminhos](validation/application-path-audit-20261104/report.md).

## Pesquisa e registros preservados

A [pesquisa TeamCity](../reverse_engineering_teamcity/ci-platform-research/README.md), a [reavaliação das skills](reavaliacao-skills-ec-dois-monolitos-atualizada.md) e os relatórios em `validation/` conservam suas observações e limitações originais. Referências antigas a JSON como configuração Ec, UI tardia ou caminhos `rea/` não substituem os contratos atuais. A [cópia importada da skill de README](readme-lifecycle-engineering-SKILL.md) é fonte preservada; seus recursos relativos estão no pacote instalado indicado pelo catálogo.

Manter este índice quando surgir uma nova referência vigente. Atualizar as entradas funcionais e de contratos ao implementar comportamento; preservar os relatórios anteriores e produzir nova evidência quando seus inputs mudarem.
