# Ec

Plataforma independente de CI/CD em fase de pesquisa, governança e documentação da aplicação. Arquitetura definida: Ec Server e Ec Agent como monólitos modulares Rust; frontend Vue 3 + TypeScript + Pinia. A estrutura de diretórios está criada, mas ainda não há servidor, agente ou interface de produto executáveis neste checkout.

## Começar pelo repositório

- Para conhecer o produto: [estado do projeto](sdd/project.md) e [normas e autoridades](docs/constitution.md).
- Para contribuir: [AGENTS.md](AGENTS.md), [organização da aplicação](docs/architecture/application-layout.md) e [política de testes](docs/development/testing.md).
- Para implementar: [Agent](application/agents/README.md), [Server](application/server/README.md), [backend](application/server/backend/README.md) e [frontend](application/server/frontend/README.md).
- Para entender a governança: [SDD](sdd/README.md) e [análise das skills](docs/development/skills-analysis.md).

## Mapa do repositório

| Caminho | Responsabilidade |
| --- | --- |
| `application/agents/crates/` | Domínios e composição do Ec Agent em Rust |
| `application/server/backend/crates/` | Domínios e composição do Ec Server em Rust |
| `application/server/frontend/` | Aplicação Vue 3/TypeScript/Pinia organizada por domínios |
| `application/integration/tests/` | Integração e ponta a ponta entre componentes da plataforma |
| `docs/` | Normas, arquitetura, decisões, desenvolvimento e validação |
| `sdd/` | Workflow, contexto, pontes, features e evidências |
| `config/governance/` e `tools/governance/` | Catálogo, fontes, hashes e verificadores |
| `reverse_engineering_teamcity/` | Pesquisa histórica preservada |

A [pesquisa histórica](reverse_engineering_teamcity/ci-platform-research/README.md) e seu protótipo não constituem a aplicação Ec; comandos antigos `rea/` não correspondem ao layout atual.

## Verificações disponíveis

Com Python 3.11+ disponível, execute da raiz:

```bash
python3 tools/governance/validate.py
python3 sdd/tools/validate.py --root .
python3 -m unittest discover -s tools/governance/tests -v
```

São verificações de governança, não testes do produto. Os testes usam cópias temporárias e precisam de um diretório temporário gravável. Não há manifests Cargo/npm, toolchain fixada ou comandos de build/run do Ec. Consulte a [política de testes](docs/development/testing.md) para escopos, limites e verificações adicionais.

As 67 skills estão instaladas em `.codex/skills/`, com 594 arquivos conferidos; a preparação local foi preservada para recuperação. Consulte o [procedimento](docs/development/skill-installation.md) e o [relatório da adoção](docs/validation/skills-adoption/report.md).

## Contratos e próximos passos

YAML é a configuração declarativa canônica planejada, com Visual/Formulário/YAML semanticamente equivalentes. PostgreSQL guarda estado operacional; HTTP versionado é o transporte vigente. gRPC/Protobuf e SQLite por Agent permanecem propostas. Capacidade de 1.000 agentes não foi demonstrada.

A [ADR-002](docs/decisions/ADR-002-application-layout.md) registra a organização física inicial. Antes de implementar, especificar schemas e interfaces, fronteiras transacionais, revisões e contratos de tentativa/lease; selecionar toolchains, dependências e runners de teste; demonstrar autorização, isolamento, recuperação e acessibilidade nos fluxos pertinentes. A criação das pastas não resolve essas pendências.

Não há release, instalador de produto ou licença própria definida por esta integração. A [auditoria de limpeza](docs/validation/workspace-cleanup-20261103/report.md) preserva o histórico de entradas removidas; a [validação desta estrutura](docs/validation/application-layout-20261103/report.md) registra a observação documental inicial.

A estrutura vigente usa `application/agents/`, `application/server/` e `application/integration/tests/`. A [auditoria dos caminhos](docs/validation/application-path-audit-20261104/report.md) consolida a conferência atual; os relatórios anteriores preservam as observações de cada etapa.
