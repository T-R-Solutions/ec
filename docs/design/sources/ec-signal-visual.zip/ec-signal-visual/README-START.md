# Ec / Signal — Visual Workbench Preview

**Status:** editable visual prototype derived from the supplied Ec v0.10 source package (not an independent production implementation).

## Open

1. Extract this archive.
2. In the extracted `ec-signal-visual/` folder, run `python3 -m http.server 8080` (or another static local HTTP server).
3. Open `http://localhost:8080/index.html`.
4. Open `design-system-ec.html` to inspect the proposed palette, typography and components.

## What changed

- Kept Ec navigation, workspaces, configuration-mode labeling, and current demonstration fixtures.
- Applied the source-of-truth `DESIGN.md` visual direction: Ox institutional palette, IBM Plex Sans/Mono typography with local fallback, Ec workbench structure.
- Added visual demonstration surfaces for Infrastructure, Deliveries, Extensions and Administration. These are not proof of real integrations.
- Preserved `projects`, `overview`, `pipelines`, `executions`, and `people` layouts as editable baseline and extended their styling.

## Files

- `index.html`: prototype entrypoint
- `ec-enterprise.css`: theme and component refinements
- `ec-enterprise.js`: new demonstration surfaces and local-only interactions
- `signal.css`, `projects.css`, `workbench.css`, and JS files: Ec baseline composition
- `design-system-ec.html`: proposed visual design-system inspection
- `DESIGN.md`: visual source of truth
- `QA-STATIC-RESULTS.json`: static tests (not a browser, user or accessibility test)

## Limits

- Light and Dark styles are proposed based on documented roles. 18 opaque text/background color pairs were statically checked; this is not full WCAG certification.
- New domain content is demonstrative. No authenticated server, actual CI/CD execution, plugin installation, deployment or YAML parser is connected.
- The source archive did not contain the full Ec v0.11 glyph library; original icons are preserved when available.
- Font binaries are not redistributed. The CSS attempts to load IBM Plex from Google Fonts when online and falls back to local system sans/monospace when offline.
- No browser-based screenshot comparison, screen reader testing or end-to-end functional verification was performed in this package.

## Source priority

1. EC visual and product normative documents.
2. `DESIGN.md` for appearance.
3. Actual Ec baseline files for existing features and conventions.
4. Other design references as optional methodology only.
