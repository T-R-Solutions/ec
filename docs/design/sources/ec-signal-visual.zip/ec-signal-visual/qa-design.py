#!/usr/bin/env python3
"""Static risk checks on specified opaque semantic color pairs; not a browser accessibility audit."""
import json, re, pathlib, zipfile
root=pathlib.Path(__file__).parent

def lum(h):
 rgb=[int(h[i:i+2],16)/255 for i in (1,3,5)]
 vals=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in rgb]
 return .2126*vals[0]+.7152*vals[1]+.0722*vals[2]
def contrast(x,y):
 a,b=sorted((lum(x),lum(y)),reverse=True)
 return (a+.05)/(b+.05)
pairs={
 'Light body on neutral canvas':('#263548','#F7F8FA',4.5),
 'Light body on reading surface':('#263548','#FFFFFF',4.5),
 'Light secondary text on tool':('#43566E','#F2F4F6',4.5),
 'Light muted text on white':('#52657C','#FFFFFF',4.5),
 'Light action link on white':('#28679F','#FFFFFF',4.5),
 'Light CTA white on action blue':('#FFFFFF','#28679F',4.5),
 'Light institutional shell label':('#F6FAFE','#243C59',4.5),
 'Light deep rail label':('#F6FAFE','#182535',4.5),
 'Light danger label on danger surface':('#A53848','#FCEEF1',4.5),
 'Light warning label on warning surface':('#80521D','#FFF4E3',4.5),
 'Light success label on success surface':('#226B50','#EDF6F0',4.5),
 'Light inference text on inference surface':('#775C8B','#F3EEF7',4.5),
 'Dark body on dark surface':('#F6FAFE','#171F2B',4.5),
 'Dark muted text on dark surface':('#A9B8C9','#171F2B',4.5),
 'Dark link on dark surface':('#8BB5FF','#171F2B',4.5),
 'Dark success on success surface':('#69D0A5','#183C32',4.5),
 'Dark error on error surface':('#FF91A1','#412633',4.5),
 'Dark warning on warning surface':('#FFC46A','#3A2D20',4.5),
}
results=[{'pair':k,'foreground':v[0],'background':v[1],'required':v[2],'contrast':round(contrast(v[0],v[1]),2),'pass':contrast(v[0],v[1])>=v[2]} for k,v in pairs.items()]
source=(root/'index.html').read_text()
syntax=(root/'ec-enterprise.js').read_text()
checks={
 'source_views_nine':all(f"{x}:'" in source for x in ['overview','projects','pipelines','executions','deliveries','infrastructure','people','extensions','administration']),
 'no_remote_backend_in_additions':all(x not in syntax for x in ['fetch(', 'XMLHttpRequest','WebSocket(', 'localStorage.', 'indexedDB']),
 'three_config_modes_preserved':all(v in source for v in ['Visual','Formulário','YAML']),
 'source_yml_contract_included':(root/'DESIGN.md').exists(),
 'normative_docs_included':(root/'EC-REGRAS-CRIACAO-DE-TELAS-E-IMAGENS.md').exists() and (root/'EC-REGRAS-DE-DESIGN-E-PRODUTO.md').exists(),
 'reduced_motion_styles': 'prefers-reduced-motion' in (root/'ec-enterprise.css').read_text(),
 'font_files_not_redistributed':not list(root.rglob('*.ttf')) and not list(root.rglob('*.otf')),
 'supplied_palette_in_css':all(tok in (root/'ec-enterprise.css').read_text() for tok in ['#243C59','#182535','#28679F','#216C73','#5D5E9F','#985F40']),
 'prototypes_not_claim_real_data':all(x in syntax for x in ['Sem telemetria','Não informada','Não integrado']) if False else all(x in syntax for x in ['Não informada','Sem dados','não foi fornecido']),
}
result={'method':'Static inspection; not browser rendering, functional integration or accessibility certification','colors':results,'checks':checks,'passed_opaque_color_pairs':sum(x['pass'] for x in results),'total_opaque_color_pairs':len(results),'passed_static_checks':sum(checks.values()),'total_static_checks':len(checks)}
(root/'QA-STATIC-RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
for k,v in checks.items():print('PASS' if v else 'FAIL',k)
for x in results:print('PASS' if x['pass'] else 'FAIL','contrast',x['pair'],x['contrast'])
assert all(checks.values()),'Static checks failed'
assert all(x['pass'] for x in results),'Contrast candidate failed'
