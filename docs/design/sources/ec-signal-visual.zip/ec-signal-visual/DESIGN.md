# Ec / Signal — Visual Design Contract

**Document:** `DESIGN.md`  
**Product:** Ec — enterprise continuous integration, delivery, and deployment (CI/CD) platform  
**Design language:** Ec / Signal · Precision Atelier · Precision Workbench  
**Revision:** 1.0 — Ox color and typography adoption proposal, November 11, 2026  
**Documentation language:** English  
**Product interface language:** Brazilian Portuguese (`pt-BR`), with internationalization support  
**Scope:** visual identity, typography, colors, information architecture, layouts, components, states, responsive behavior, UX, accessibility, prototypes, and visual review  
**Implementation status:** Design specification. An adopted design direction is not evidence of a completed code migration or validated production behavior.

> **Design intent:** **Precision without noise.** Ec must look and behave like a professional engineering workbench: purposeful, sophisticated, data-first, information-dense without being cramped, and unmistakably a CI/CD product.
>
> **Inheritance rule:** Preserve the **Ec product, workflows, application layout, design language, and proprietary iconography**. Adopt the **Ox palette and IBM Plex typography** as the new Ec visual reference. No other Ox product behavior, native framework, feature, navigation pattern, artifact model, or implementation contract is inherited.

---

## 1. Authority, source boundaries, and change control

### 1.1 Source hierarchy

1. `EC-REGRAS-CRIACAO-DE-TELAS-E-IMAGENS.md` — mandatory screen, image, and visual-prototype requirements.
2. `EC-REGRAS-DE-DESIGN-E-PRODUTO.md` — mandatory product, UX, declarative configuration, accessibility, safety, and architecture requirements.
3. **Explicit visual decision for this revision:** use the supplied Ox `DESIGN.md` **only for color palette and typography**.
4. Verified Ec visual artifacts and approved design decisions — Ec / Signal, Precision Atelier, Precision Workbench, Ec Signal Glyphs, existing navigation, and working interaction patterns.
5. This document — the consolidated visual specification for future Ec screen design and review.

If the normative Ec documents conflict with an example in this document, the normative rule prevails. No legacy Ox-native UI, desktop conventions, agent-task model, SDD process, or Iced/Rust renderer contract is transferred to Ec by implication.

The source Ox document describes its own original Light colors as preserved and several complementary colors as candidates. This Ec document **retains that distinction**. A proposed color extension is not a copied, validated Ox token.

### 1.2 Design decision states

| Label | Meaning | Not evidence of |
| --- | --- | --- |
| **SOURCE-PRESERVED** | A role and exact value copied from the supplied Ox palette or type contract | Implementation in Ec |
| **ADOPTED-DIRECTION** | Selected visual requirement in this Ec design document | Completed migration or measured success |
| **PROPOSED** | Candidate needing visual, accessibility, and compatibility review | Approval or default activation |
| **IMPLEMENTED** | Observed in identified Ec code and a specific revision | General correctness or accessibility |
| **VERIFIED** | Checked in a stated scenario with method, inputs, and results | Other themes, browsers, users, or production |

Record every global change to typography, color semantics, tokens, component geometry, or navigation with a change log, source revision, affected components, comparative captures, results, and unresolved limitations. Do not silently rewrite tokens or assert that all Ec versions have already adopted this contract.

### 1.3 Product boundary

Ec is a **web-based** CI/CD product. The intended frontend is **Vue.js + TypeScript**; the planned server/control plane and execution agents are **Rust**. Backend details inform the interface but are not a reason to replicate Ox's native desktop implementation or its task-centric navigation.

The documented visual prototype may be static or demonstrative. It does not prove that APIs, authorization, CI execution, agent scheduling, deployments, YAML parsing, or synchronization are operational.

---

## 2. Identity and art direction

**Brand:** Ec / Signal. The product is named **Ec**, never a different name. **Precision Atelier** is the foundational aesthetic; **Precision Workbench** is its workspace-oriented evolution.

### 2.1 Core traits

- **Precision:** deliberate alignment, controlled geometry, strong typography, restrained color, and accurate status representations.
- **Control:** visible scope, clear action hierarchy, inspectable consequences, and predictable editing/review flows.
- **Trust:** distinguish confirmed, proposed, unknown, blocked, and disconnected states; never overstate operational certainty.
- **Technical sophistication:** connected navigation and inspectors, useful density, proper code/log typography, and task-specific compositions.
- **Independent character:** the Ec brand, icons, component anatomy, and interaction language must not imitate a competitor's distinctive design.

### 2.2 Atmosphere

Keep the global chrome quiet. Surfaces are mainly neutral, with slate-blue institutional chrome and **purposeful** contextual color. Use tonal boundaries and thin separators for docked tools; reserve shadows for actual overlays. The information, graph, tree, log, table, or editor appropriate to the task must visually dominate.

Do not use marketing-landing-page hero sections, glassmorphism, neon, decorative gradients, heavy shadows, repeated independent cards, illustration-first dashboards, or indiscriminate colorful badges. A premium enterprise appearance comes from rigor, legibility, and consistently resolved interaction details.

### 2.3 Explicitly preserved from Ec

- Nine-domain product architecture and the distinction between global and project-scoped navigation.
- The three-level navigation model: global navigation → context/location → task workspace.
- Persistent workspace chrome, command access, contextual navigator, dominant primary work area, and adjacent inspector where useful.
- Precision Workbench's integrated, docked-panel composition rather than a generic card grid.
- Ec Signal Glyphs, the product's existing original SVG iconography system.
- Signal Thread: cross-view contextual reference from selected item or event to relevant evidence, without asserting causation.
- Two themes with equivalent content and actions, normal/compact density, and responsive task alternatives.
- Visual, Form, and YAML modes describing one intended canonical declarative configuration model.

**Changed by this document:** the reference **palette** and the default **sans-serif typography**. The old Ec Signal Blue `#175CD3` and Inter typeface are not the new design defaults; existing consumers must be inventoried and migrated deliberately.

---

## 3. Color foundation — Ox palette adopted for Ec

### 3.1 Source-preserved Light palette

These are **exact source values** from the supplied Ox `DESIGN.md`, retained with their original visual roles. They are the source for Ec's new Light design. Do not approximate them with arbitrary variants or claim a conversion is identical without testing.

| Role | Exact Ox value(s) | Ec visual use |
| --- | --- | --- |
| Institutional shell | `#243C59` | Brand-bearing chrome; optional expanded navigation surfaces |
| Deep shell | `#182535` | Recessed rail, deep context, high-level chrome |
| Primary action / strong action | `#28679F` / `#205483` | Primary CTA, selected action, interactive emphasis |
| Muted brand blue | `#6E9FCF` | Secondary graphic accents; never essential tiny text on white |
| Soft blue / highlight | `#B1D0F0` / `#D5E7F9` | Limited contextual emphasis, not full-workspace decoration |
| Selection background | `#E8F2FD` | Selection with persistent visible marker and focus separation |
| Legacy blue-tinted canvas/tool | `#EDF3FA` / `#F6F9FD` | Compatibility or selected subareas; not mandatory global backgrounds |
| Reading/editor surface | `#FFFFFF` | Main reading area, editor, logs, content surfaces |
| Primary text | `#263548` | Main UI text on light surfaces |
| Secondary text | `#43566E` | Explanations, secondary values |
| Muted text | `#52657C` | Metadata with verified contrast |
| Text on institutional shell | `#F6FAFE` | Shell labels and chrome text |
| Decorative/soft borders | `#CBD8E6` / `#E4ECF5` | Separators only; not essential input/focus boundaries |
| Success / success surface | `#226B50` / `#EDF6F0` | Confirmed success and validated successful operations |
| Warning / warning surface | `#80521D` / `#FFF4E3` | Relevant risk, attention, intervention, or blocking with text |
| Error / error surface | `#A53848` / `#FCEEF1` | Actual failure or contextual destructive consequence |
| Inference / inference surface | `#775C8B` / `#F3EEF7` | Explicit inference or hypothesis **only** |

**Brand hierarchy:** institutional slate blue identifies the shell; Ox action blue `#28679F` replaces the earlier Ec primary-action blue. Use blue for action, selection, focus, and the brand; do not make every chart and card blue.

### 3.2 Additional colors already present in the Ox source

The source also documents the following **context-category roles**. They are useful to reduce excessive white-and-blue repetition in Ec, but must not be mistaken for operational status colors.

| Context | Source value | Subtle background | Ec mapping | State |
| --- | --- | --- | --- | --- |
| Execution context | `#216C73` | `#EAF5F3` | Execution category, traces, timeline grouping, analytical relationships | SOURCE-PRESERVED; application to Ec is ADOPTED-DIRECTION |
| Architecture / dependencies | `#5D5E9F` | `#EEEFFA` | DAG dependencies, project relationships, inherited configuration provenance | SOURCE-PRESERVED; application to Ec is ADOPTED-DIRECTION |
| Change impact | `#985F40` | `#F8F1EA` | Review of impacted resources or comparisons **without implying warning** | SOURCE-PRESERVED; application to Ec is ADOPTED-DIRECTION |

These markers are small: icon, 2–3 px contextual stripe, connector, relationship badge, or limited analytical surface. Do not tint entire workspaces by domain. Use an explicitly labeled legend if colors distinguish series or relationship classes.

### 3.3 Neutral Light workspace candidates from Ox

The supplied Ox document names this candidate neutral family:

| Role | Candidate value | Status |
| --- | --- | --- |
| Navigation neutral | `#F2F4F6` | PROPOSED in the Ox source |
| Workspace neutral | `#F7F8FA` | PROPOSED in the Ox source |
| Recessed/tool header | `#E8ECEF` | PROPOSED in the Ox source |
| Editor/reading surface | `#FFFFFF` | SOURCE-PRESERVED |
| Functional control outline | `#7A8798` | PROPOSED in the Ox source |

**Preferred evaluation direction for Ec:** use the above neutrals to keep the workspace from becoming uniformly white or pale blue. Keep white where reading, logs, and editors require clarity. The original Ox blue-tinted backgrounds remain available as compatibility/reference colors, **not an instruction to repaint every screen blue**.

Do not silently mark these candidates implemented. Apply them to the same fixtures and compare Light screens, toolbar separation, borders, input affordances, and accessibility before accepting them.

### 3.4 Other Ox color proposals — not automatically adopted

The source includes proposed status midtones `#2F8060`, `#A26720`, `#C14B58`; status borders `#8BBAA4`, `#D9B579`, `#DFA4AC`; code teal `#2B7078`/`#E7F2F1`; and document mineral `#6E6259`/`#F6F3EF`.

These are **PROPOSED**, not replacements for the preserved colors above. They may be compared for specific readability/role needs only. No automatic extra category, theme, or series should be introduced to make the screen look more colorful.

### 3.5 Ec-specific Dark theme extension

The uploaded Ox source **does not define a complete locked Dark palette with exact final values**. Ec nevertheless requires a functional Dark theme. The following is a **PROPOSED Ec dark adaptation**, using Ec's existing dark neutrals and chromatic counterparts within the Ox hue families. Do not attribute these exact values to Ox, treat them as validated, or turn them into a production default without a comparative review.

| Role | Proposed Dark value | Notes |
| --- | --- | --- |
| Workspace canvas | `#10151E` | Ec legacy dark neutral retained as a bridge |
| Content / editor surface | `#171F2B` | Ec legacy dark neutral retained as a bridge |
| Navigation shell | `#121923` | Ec legacy dark neutral retained as a bridge |
| Institutional shell emphasis | `#243C59` | Exact Ox shell role, where appropriate |
| Deep context | `#182535` | Exact Ox deep shell |
| Tool/recessed surface | `#202C3C` | New Ec candidate |
| Structural border | `#344151` | Ec legacy dark boundary |
| Primary text | `#F6FAFE` | Exact Ox shell-text color repurposed with contrast review |
| Secondary text | `#CAD5E2` | New Ec candidate |
| Muted text | `#A9B8C9` | New Ec candidate |
| Action / focus | `#8BB5FF` | Ec legacy dark-blue bridge, pending adoption |
| Selected background | `#1D304C` | Ec legacy dark-selection bridge |
| Success | `#69D0A5` | Ec legacy dark-success bridge |
| Warning | `#FFC46A` | Ec legacy dark-warning bridge |
| Error | `#FF91A1` | Ec legacy dark-error bridge |
| Inference | `#D6B5E7` | New Ec candidate in Ox violet family |
| Execution relationship | `#8FD2D2` | New Ec candidate in Ox teal family |
| Dependency relationship | `#B4B4EE` | New Ec candidate in Ox violet family |
| Impact relationship | `#E4B695` | New Ec candidate in Ox brown family |

Every Dark role must preserve the **same meaning** as Light. Test primary, secondary, selected, hover, focus, disabled, overlays, graph strokes, logs, YAML, diff, and error states on their actual rendered backgrounds. A dark scheme is not an algorithmically inverted Light scheme.

### 3.6 Role-to-token naming

Use semantic CSS custom properties rather than hard-coded page-specific hex values. Recommended names:

| Semantic token | Light value / decision |
| --- | --- |
| `--ec-color-shell` | `#243C59` |
| `--ec-color-shell-deep` | `#182535` |
| `--ec-color-action` | `#28679F` |
| `--ec-color-action-strong` | `#205483` |
| `--ec-color-action-soft` | `#D5E7F9` |
| `--ec-color-selected` | `#E8F2FD` |
| `--ec-color-surface-reading` | `#FFFFFF` |
| `--ec-color-text` | `#263548` |
| `--ec-color-text-secondary` | `#43566E` |
| `--ec-color-text-muted` | `#52657C` |
| `--ec-color-on-shell` | `#F6FAFE` |
| `--ec-color-border-soft` | `#CBD8E6` |
| `--ec-color-border-decorative` | `#E4ECF5` |
| `--ec-color-success` / `--ec-color-success-bg` | `#226B50` / `#EDF6F0` |
| `--ec-color-warning` / `--ec-color-warning-bg` | `#80521D` / `#FFF4E3` |
| `--ec-color-danger` / `--ec-color-danger-bg` | `#A53848` / `#FCEEF1` |
| `--ec-color-inference` / `--ec-color-inference-bg` | `#775C8B` / `#F3EEF7` |
| `--ec-color-execution` / `--ec-color-execution-bg` | `#216C73` / `#EAF5F3` |
| `--ec-color-dependency` / `--ec-color-dependency-bg` | `#5D5E9F` / `#EEEFFA` |
| `--ec-color-impact` / `--ec-color-impact-bg` | `#985F40` / `#F8F1EA` |
| `--ec-color-canvas`, `--ec-color-nav`, `--ec-color-tool-header`, `--ec-color-control-outline` | Evaluate the source-proposed neutral candidates in §3.3 |

Define primitive colors separately from semantic roles. Component variants consume semantic tokens. Theme selectors override semantic values without changing their meanings. Density changes geometry, **not** color semantics. CSS/design tokens are presentation assets and do not constitute an alternate Ec resource-configuration language; **YAML remains the only canonical declarative configuration format for Ec resources**.

### 3.7 Color application rules

- Use a **neutral-first** layout. Blue is not a universal card, metadata, and chart color.
- Pair a state label with an icon/shape and accessible text; hue alone is never sufficient.
- Do not use success green to indicate ordinary selection, nor error red for generic emphasis.
- Running is not automatically success. Operational activity may use teal with explicit state text.
- Purple **dependency category** and purple **inferred relationship** have different meanings and must be visually differentiated by marker/line style and label.
- An unknown condition uses neutral styling, not inference violet or success green.
- Reserve the most saturated accents for meaningful focal or active elements.
- Measure contrast in real component states and final composite surfaces, not isolated swatches only.

---

## 4. Typography — Ox IBM Plex system adopted for Ec

### 4.1 Typeface adoption

| Role | Ec typeface after this design decision | Fallback | Status |
| --- | --- | --- | --- |
| Interface, navigation, tables, controls, dialogs | **IBM Plex Sans** | `ui-sans-serif, system-ui, sans-serif` | SOURCE-PRESERVED in Ox; ADOPTED-DIRECTION for Ec |
| YAML, code, logs, paths, commits, IDs, technical traces | **IBM Plex Mono** | `ui-monospace, monospace` | SOURCE-PRESERVED in Ox; ADOPTED-DIRECTION for Ec |

**Inter is not the new default.** It belongs to the previous Ec visual baseline and the source Ox A/B exploration. Do not retain it as an equal default or automatically substitute JetBrains Mono. Confirm licensed fonts, actual font weights, language glyph coverage, browser rendering, and fallback before changing deployed assets.

### 4.2 Source-preserved typographic scale

These are the Ox source's logical-size ranges. Treat them as **CSS pixel design starting points for Ec web interfaces**, not as a claim of identical native/DOM rasterization.

| Usage | Target size | Font | Guidance |
| --- | --- | --- | --- |
| Workspace/task heading | `22–24px` | IBM Plex Sans Semibold | Technical heading, no marketing hero treatment |
| Page/dialog heading | `20–22px` | IBM Plex Sans Semibold | Clear hierarchy and efficient vertical rhythm |
| Panel heading/body | `15–16px` | IBM Plex Sans | Readable explanations and controls |
| Button, tree, table | `14–15px` | IBM Plex Sans | Stable interactive targets; do not shrink essential data |
| Metadata | `13px` | IBM Plex Sans / Mono as appropriate | `12px` only after contextual readability review |
| Code/YAML/diff | `15px` | IBM Plex Mono | Approximately `26px` line-height; preserve punctuation and long lines |
| Technical trace | `13–14px` | IBM Plex Mono | Correlation IDs, timestamps, event order |
| Metric | `18–28px` | IBM Plex Sans, tabular numerals | Always show unit, time range, source, scope |
| Graph label | `12–14px` | IBM Plex Sans / Mono | Full identifier accessible on inspection |

Recommended weights: normal body `400`, secondary emphasis `500`, primary heading `600`, exceptional emphasis `700`. These are implementation guidelines; use only weights actually available or supported by the chosen font build. Do not create apparent density by rendering essential text at 10–11px.

### 4.3 Typography mechanics

- Use `font-variant-numeric: tabular-nums` for counters, durations, aligned table numbers, percentages, and metrics.
- Check ambiguity in `0/O`, `1/l/I`, braces, quotes, operators, paths, branches, file names, and hash prefixes.
- Disable discretionary code ligatures by default unless an explicit tested option is introduced.
- Keep line wrapping intentional. Technical data can scroll horizontally within its own region rather than being silently truncated.
- Test Portuguese diacritics and longer localized strings; the **document language is English**, the **product UI locale is pt-BR**.
- Avoid squeezing captions or labels to compensate for increased font metrics; recalibrate component geometry and layouts.
- Never bundle or redistribute font binaries without checking licensing and provenance.

### 4.4 Migration notes

The previous Ec system used Inter for interface text and IBM Plex Mono for technical content. This contract **changes the visual reference** to IBM Plex Sans/Mono but does not claim that the deployed Ec version has been migrated. Compare the same content, viewport, density, and themes before replacing font resources or declaring parity.

---

## 5. Ec product architecture and navigation

Ec is not only a pipeline editor. The global information architecture must cover these nine domains, with local navigation used where appropriate:

| Domain | User questions and major destinations |
| --- | --- |
| **Overview** | Instance health, recent activity, failed builds, queue pressure, alerts, operational triage |
| **Projects** | Project/subproject hierarchy, repositories, policies, parameters, team ownership, project configuration |
| **Pipelines** | Pipeline library, triggers, jobs, DAG authoring, templates, validation, Visual/Form/YAML, change review |
| **Executions** | Build history, queue, attempts, logs, tests, artifacts, failures, retry/cancel conditions |
| **Deliveries** | Environments, releases, promotions, approvals, deployment evidence, supported rollback paths |
| **Infrastructure** | Agents, pools, slots, capacity, requirements, compatibility, maintenance, connectivity, diagnosis |
| **People & Access** | Users, teams, roles, effective permissions, invitations, scope, access audit |
| **Extensions & Integrations** | Plugins, repositories, Git providers, webhooks, notifications, compatibility, permissions, health |
| **Administration** | Global configuration, instance health, retention, audit, security, policies, updates |

Do not place every subfeature permanently in the primary rail. Separate **global scope**, **project scope**, and **resource detail** with breadcrumbs and context navigation. A project hierarchy is not the same thing as a pipeline dependency graph.

Use discoverable search/command access, recent resources, favorites when supported, deep links, and clear return-to-context behavior. Show the active resource and permission context before exposing high-impact actions.

---

## 6. Ec application shell and workspace composition

**Keep the Ec Precision Workbench layout. Do not import Ox's native desktop shell or task-plan workbench.**

### 6.1 Canonical Ec spatial hierarchy

1. **Global Navigation Rail:** Ec identity; nine-domain navigation; compact, consistent glyphs; active destination visibly selected.
2. **Command Bar / Global Header:** current scope, resource search/commands, notifications, theme/density controls, user context, and simulation/connectivity information.
3. **Context Navigator:** local project/resource tree or related entities, shown when the current task benefits.
4. **Workspace Header:** resource title, location, relevant status/revision, and one clear primary action.
5. **Primary Workspace:** task-dominant chart, tree/data grid, DAG, logs, YAML editor, form, timeline, or catalog.
6. **Inspector / Properties Pane:** adjacent to current selection, grouped by semantics, collapsible/resizable when useful.
7. **Context/Status Surface:** source, time, data freshness, demonstration state, warnings, or synchronization condition; not a decorative footer.

These are **functional regions**, not a requirement to display seven separate bands at once. Collapse or merge secondary surfaces when the primary work area needs space.

### 6.2 Ec geometry reference

The existing Ec Precision Workbench source uses a compact navigation rail, compact command bar, docked workspace regions, and an inspector. Historic observed values include approximately `72px` for the rail, `48px` for the global toolbar, `224px` for a context navigator, and `304px` for an inspector in one desktop layout. They are **Ec evidence and adjustable design references, not Ox geometry or immutable requirements**.

Use fluid `minmax(0,1fr)` areas, adjustable panel widths where valuable, and context-specific resizing. Do not impose arbitrary maximum widths on large tables, DAGs, and log editors. Panel layout must remain usable when a navigator or inspector is hidden or reopened.

### 6.3 Composition rules

- Use docked surfaces, precise separators, controlled whitespace, and consistent alignment rather than several independent cards for one task.
- Avoid stacks of large headings, redundant breadcrumbs, and oversized page padding.
- Distinguish selection, keyboard focus, hover, and operational status.
- Reserve overlay shadows for dialogs, command palettes, menus, and floating surfaces.
- Keep form/editing, monitoring, and triage modes visually distinguishable even when sharing components.
- Use CSS Grid for multi-dimensional workspace structures, Flexbox for local alignment, Container Queries for area-dependent components, and Media Queries for viewport-dependent layout changes.
- Design long names, deep hierarchies, hidden panels, collapsed navigation, and zoom from the beginning.

---

## 7. Spacing, shape, borders, depth, and density

### 7.1 Spacing and rhythm

Ec's existing scale is `4, 8, 12, 16, 20, 24, 32, 40px`. Preserve its systematic rhythm. Normal mode prioritizes comfortable reading and clear targets; compact mode reduces gaps, row padding, and nonessential chrome **without shrinking critical text**.

### 7.2 Shape

Ec's workbench uses compact control shapes and relatively flat docked panels. Recommended continuity:

| Element | Ec geometry guidance |
| --- | --- |
| Docked editor/canvas/table | Flat or near-zero external corner radius |
| Buttons and inputs | Small, precise corners; around `4–6px` where current Ec components require |
| DAG nodes | Compact controlled rounding; ports/connectors remain optically aligned |
| Floating menus and popovers | Slightly softened corners with a clear elevation boundary |
| Dialogs | Moderately softened corners, clear hierarchy and consequences |
| Pills/badges | Used sparingly; not a default shape for every control |

The Ox source's native window geometry does **not** replace Ec's component and layout geometry.

### 7.3 Separators and focus

Use a layered distinction between structural split, component boundary, decorative divider, selected item, and focused control. Soft decorative border colors are not automatically strong enough for functional input outlines. Selection needs a filled/tonal region **plus** a persistent line, marker, or other non-color-only cue; focus needs an independent visible outline.

### 7.4 Motion

Motion must communicate relationship or feedback, not decorate. Keep Ec's restrained short transitions for panel movement, selection, and context continuity. Respect `prefers-reduced-motion`. Critical operational statuses must never be inferred from animation alone or from a temporary toast.

---

## 8. Ec Signal Glyphs — original iconography

Retain the proprietary **Ec Signal Glyphs** system and its established role-based SVG naming and geometry. The existing glyph library is an Ec asset; the Ox document's iconography notes are **not an instruction to replace it**.

- Preserve a shared outline grammar, optical alignment, consistent stroke weight, and distinct silhouettes for the nine navigation domains.
- Use standard small sizes in controls and tables, generally `16–20px`; larger sizes must be tested for optical balance.
- Source SVGs must be editable, safe, self-contained, and scalable; avoid scripts, remote assets, and ornamental effects.
- Apply `currentColor` for monochrome controls where suitable; theme colors come from semantic tokens.
- Do not replace resource names, critical statuses, permission outcomes, or destructive actions with unlabeled icons.
- For icon-only commands, provide accessible names, keyboard focus, tooltip/help, and clear action consequences.
- Use status symbol + visible text + meaningful color; do not duplicate a complete icon set to indicate each theme.
- Document symbol intent, location, size, usage restrictions, and changes to existing glyphs.

Use iconography where it accelerates recognition; leave it absent when it adds noise.

---

## 9. Status and truth semantics

### 9.1 Operational status vocabulary

Ec must distinguish at least:

| State | Meaning | Visual treatment |
| --- | --- | --- |
| Draft | Proposed desired configuration, not effective | Neutral with explicit draft label |
| Validating | Validation in progress | Activity icon plus text; never success styling |
| Validated | Validation result for a stated revision | Clear result with scope; not automatically published |
| Pending approval | Awaiting authorization | Explicit pending state; intervention styling only where required |
| Published | Versioned configuration recorded | Revision and publication status; not proof of reconciliation |
| Reconciling | Applying intended configuration | Operational progress and current context |
| Synced | Effective configuration matches intended revision | Confirmed synchronization label and source |
| Drifted | Actual state diverges | Explicit divergence + investigation path |
| Queued | Execution waiting in queue | Neutral queue indicator with reason/position only when known |
| Running | Execution currently active | Activity/teal context, never automatic success |
| Success | Confirmed successful operation | Ox success `#226B50` family with visible label |
| Failed | Confirmed failure | Ox error `#A53848` family and evidence path |
| Blocked | Prevented from progressing | Warning/intervention when justified, with specific reason |
| Cancel requested | Request received but completion unknown | Pending label, not final cancelled state |
| Cancelled | Observed cancellation | Explicit final state; no implicit rollback |
| Skipped | Not executed due to rule/condition | Neutral distinct state and explanation |
| Offline | Agent/system not connected | Distinct from cancelled or failed build |
| Unknown / unavailable | Evidence or connectivity not available | Neutral, never inference or success styling |
| Inferred | Hypothesis/projection | Ox inference violet, explicit origin/uncertainty and distinctive line/shape |

A single incident can include several concepts; keep them distinct. A test failure is not an infrastructure outage. A blocked Windows job is not caused by unrelated Linux test failures. Do not equate a role with runtime state, a request with confirmed success, a historical estimate with live telemetry, or an unavailable value with zero.

### 9.2 Semantic color priority

Brand/action color is not operational status. Dependency violet is not the same semantic role as inferred violet; differentiation requires labels and stroke/marker conventions. Execution teal represents **context/activity**, not a successful outcome. Unknown states must be explicit and neutral. Permission denied is an authorization outcome, not simply a red decoration.

### 9.3 Honest UI feedback

Never show a change as saved, synchronized, executed, authorized, or published before confirmed by the relevant service. A visual prototype must label actions and fixtures as **demonstrative**. If service data is unavailable, display an explicit unavailable/degraded state and a supported next step.

---

## 10. Canonical YAML configuration and editing views

**YAML is the single canonical declarative configuration source for desired Ec resources.** Visual and Form modes project/edit the same semantic model; neither becomes a separate authoritative configuration source.

### 10.1 Three complementary modes

- **Visual:** domain-appropriate representations such as project hierarchy, DAG authoring, permission matrix, or relationship map.
- **Form:** a complete, grouped, accessible property editor with advanced settings and validation near fields.
- **YAML:** source-oriented editor with line numbers, syntax, schema-aware guidance, search, folding, errors, revisions, and diff.

Unsupported visual mappings must remain accessible in Form/YAML with a clear indicator. Never silently discard unknown extension fields, comments, references, or advanced settings. Semantic round-trip is an **engineering requirement**; the design must not claim it was verified unless an actual parser/model test was performed.

### 10.2 Change/review flow

**Select resource → edit draft → validate → inspect diff and impact → authorize/approve → version YAML → reconcile → display confirmed effective state.**

Show draft, proposed, published, effective, and per-execution revisions as distinct when relevant. Concurrent changes require conflict detection and explicit resolution; no silent last-writer-wins behavior. A draft may be invalid; invalid YAML may not be published.

### 10.3 Secrets and operational data

Credentials and secrets are referenced securely and never displayed in plaintext YAML, screenshots, logs, or previews. Builds, queues, leases, logs, sessions, metrics, artifacts, and audit events are **operational state**, not YAML desired configuration.

---

## 11. Component architecture and interaction contracts

Every reusable component must define its purpose, semantic props/slots, states, keyboard path, responsive behavior, theme/density behavior, content constraints, and evidence/test criteria. Reuse shared components instead of creating a separate visual language per screen.

| Family | Required visual and interaction contract |
| --- | --- |
| Global rail / context navigator | Current domain/scope, correct active marker, keyboard discovery, collapsible behavior |
| Breadcrumb / context switcher | Global-to-project scope, location, deep links, no hierarchy confusion |
| Command bar / search | Contextual search, commands with accessible labels and state/permission checks |
| Tabs / segmented modes | One active view, persistent selection, independent dirty/error indicators |
| Buttons / actions | Primary vs secondary vs destructive, clear feedback and explicit consequences |
| Inputs/selects | Persistent label, typed value, helper, validation, accessible error and functional boundary |
| Form sections | Grouped semantics, explicit defaults, conditional/advanced fields with no silent loss |
| Dense data grid | Sort, filter, paginate/virtualize when needed, numeric alignment, contextual selection |
| Project tree | Accessible disclosure, hierarchical indentation, selected resource vs focus separation |
| Inspector | Identity of selected object, properties and origin, adjacent or dismissible, return context |
| Status indicator | Text + symbol + semantic color, specific reason and source when known |
| YAML editor | Monospace, line/column, validation, revision, diff, technical syntax and accessible errors |
| Diff/review | Addition/removal and source/target revisions beyond color, impact, confirmation flow |
| DAG/canvas | Distinct nodes/edges, selection/ports, dependencies, validation; alternative structured view |
| Chart | Title, question, scope, period, unit, legend, provenance, action/evidence linkage |
| Log viewer | Monospace, preserved order, timestamps, source/job/step, search, connection state |
| Timeline | Event order, stage, timestamp, provenance, actual/estimated distinction |
| Permission matrix | Effective vs assigned/inherited, scope, allowed/denied/approval, safe proposal flow |
| Plugin catalog | Source, version, compatibility, trust verification status, permissions, health |
| Notifications/dialogs | Meaningful feedback, accessible focus/escape, high-impact explanation and confirmation |
| Loading/empty/error | Honest reason, stable structural position, meaningful safe next action |

Component states as applicable: default, hover, focus-visible, active, selected, disabled, loading, error, warning, success, empty, permission-denied, offline/degraded, conflict, pending approval, and stale. Do not add irrelevant states merely to fill a checklist.

---

## 12. Screen composition by Ec domain

### 12.1 Overview — Operations Command Center

**Persona:** operator or engineering lead. **Task:** identify what failed, where, since when, and what can be investigated.

Use a principal mixed/analytical chart with scope and timeframe; adjacent incident triage; meaningful build and capacity indicators; and navigation into evidence. The current chart/event selection must remain coherent with corresponding execution details. Avoid a wall of colorful KPI cards. Apply secondary Ox teal and dependency/impact tones to **actual different series or relationships only**; do not invent new series.

### 12.2 Projects — Enterprise Project Explorer

**Persona:** platform/project administrator and developer. **Task:** navigate project/subproject hierarchy and manage contextual resources.

Use an integrated project tree, dominant resource/detail region, and adjacent inspector. Include project path/key, owner, teams, repositories, associated pipelines, inherited/local policies and parameters, draft/revision state, actions, and impact preview where supported. Hierarchy can have a structured list alternative. Moving, archiving, or changing inheritance must surface effects before confirmation. Ox dependency violet may identify **relationship/provenance**, with visible labels.

### 12.3 Pipelines — Engineering Designer

**Persona:** developer/project administrator. **Task:** author/review a pipeline and reason about dependencies.

Dominant DAG canvas; job/step library when useful; inspector; Visual/Form/YAML; validation and diff. Directed acyclic dependency graph has deterministic direction and ports; no hidden cycles. Distinguish editing graph from a runtime monitor. Use Ox action blue for selected node, an Ox dependency color for predecessor/dependency relationships, and independent focus styling. Do not pretend drag, minimap, or node connectors are implemented unless they are actually interactive. Large graphs need structured keyboard alternatives.

### 12.4 Executions — Diagnostic Workbench

**Persona:** developer/operator. **Task:** investigate one build/run and its evidence.

Show execution identity, project/pipeline, status, revision of code/config, agent/pool, trigger, time, steps, tests, logs, artifacts, and authorized retry/cancel where available. Logs/test evidence dominate technical investigation. Do not invent stack traces, test names, or artifact content. Retry is a new attempt under policy, not an exactly-once promise. Distinguish queued, running, failed, cancelled, blocked, and disconnected states.

### 12.5 Deliveries — Environments and Releases

**Persona:** release operator/approver. **Task:** understand destination, revision, gating, deployment evidence, and consequence.

Use environment/resource list, release detail, approval context, change window, promotion path, deployment timeline, and audit trail. Review the destination, artifact, revision, requester, risks, and policy before approval. Do not imply universal automatic rollback, an approval without authorization, or production deployment from a mock click.

### 12.6 Infrastructure — Agent and Pool Operations

**Persona:** platform operator. **Task:** understand capacity, availability, compatibility, and blocking causes.

Use inventory/data grid, pool-capacity distribution, selected-agent diagnostics, and job eligibility explanation. Separate configuration of pools/requirements from operational heartbeat, slots, queues, leases, and connection state. Execution teal may classify activity; success green must remain reserved for confirmed successful outcomes. Make incompatible-agent and offline-agent reasons explicit.

### 12.7 People & Access — Governance Console

**Persona:** administrator/auditor. **Task:** understand who can do what, why, and at which scope.

Use searchable user/team data tables, effective-permission matrix, role bindings, scope hierarchy, and contextual inspector. Clearly distinguish assigned, direct, inherited, effective, denied, and pending approval. Proposing permission changes is not granting access. Authentication identities and sessions are not created by YAML alone; credentials remain outside declarative files.

### 12.8 Extensions & Integrations — Verified Ecosystem

**Persona:** administrator/integration owner. **Task:** discover, evaluate, configure, and govern plugins/integrations.

Use searchable catalog, version/origin/compatibility, requested permissions, installation/update review, dependencies, and diagnostics. Distinguish installed, active, compatible, trusted, and failing. Never award trust or imply arbitrary plugin execution without verification and isolation evidence. YAML is the canonical desired configuration representation; runtime plugin health is operational.

### 12.9 Administration — Instance Governance

**Persona:** platform administrator. **Task:** manage global policies and observe system/organizational implications.

Use structured preferences/policies, audit tables, configuration revisions, retention, security, instance health, and guarded actions. Avoid a generic dashboard of cards. Separate authorized state changes from requests, and preview risks of destructive or privilege-modifying operations.

Each domain needs list/detail/create-edit/review/error experiences where applicable. A menu entry is not proof of a complete designed or implemented feature.

---

## 13. Data visualization — Ec Chart System

Charts must answer a specific operational question: failed-build trend, success rate, duration percentile, queue wait, agent occupancy, retries, deployment outcomes, or other justified metric. Every chart includes **title, scope, period, unit, source, freshness, and legend**. Never show invented telemetry as live.

### 13.1 Composition

- Main task can use a hero analytical chart; secondary charts must earn their space.
- Mixed charts may combine bars and lines for distinct, correlated quantities with clearly labeled axes.
- Avoid ambiguous multiple Y axes; prefer synchronized smaller plots when scales cannot be compared safely.
- Use consistent series identity throughout filtering, crosshair/tooltip, drill-down, and Signal Thread navigation.
- Show event markers only when correlation is grounded. A shared timestamp is not causal evidence.
- Provide accessible table/summary alternatives and full values on inspection.

### 13.2 Chromatic discipline

- Main interactive focus remains Ox action blue.
- A genuinely distinct operational series may use source Ox teal `#216C73`.
- A dependency/correlation series may use `#5D5E9F` with labels; inference is separately denoted.
- Comparison/impact may use source Ox brown `#985F40` where meaningful.
- Status colors are for statuses, **not** general chart series.
- If only one series exists, keep one series; never fabricate extra data to exhibit the palette.

---

## 14. Detailed canvas, logs, and source editing

### 14.1 DAG and dependency map

Use the existing Ec node conventions and proportional layouts. A node must expose identity, role/type, pool/requirement, timeout or relevant summary, and dependency context; inspector/Form/YAML expose details. Edges show direction and avoid ambiguous overlaps. Selected node, predecessor, validation error, keyboard focus, and running state are independent visual dimensions. Prevent/signal cycles and broken references in actual editing implementations; a static image is not proof of validation.

### 14.2 YAML editor and diff

IBM Plex Mono is the canonical technical typeface. Support clear line numbers, error location (file/line/column/path), source revision, folding, compare mode, and visible proposed/effective distinctions. Errors must have cause and an actionable recommended correction. Invalid drafts may exist but are never effective. Maintain semantics of references, keys, lists, and advanced fields; if formatting/comments cannot be preserved, show diff before rewriting.

### 14.3 Logs, tests, and artifacts

Provide timestamps, source execution/job/step, severity, line identity, ordered incremental content when supported, and reconnect/loss state. Separate test failures, build failures, infra faults, and cancellation. Artifacts display name, type, size, integrity, origin, retention, and permitted access when known. Redact secrets in all representations.

---

## 15. Responsive and adaptive behavior

Ec is a **web** application. Dense authoring is desktop-first; essential consultation, triage, approval, and monitoring remain available on smaller screens.

| Reference viewport | Design obligation |
| --- | --- |
| `1920 × 1080` | Multi-pane workspaces, efficient distribution of primary work and inspector |
| `1440 × 900` | Primary visual QA baseline for screen hierarchy and comparison |
| `768 × 1024` | Collapse/reposition secondary navigation, structured detail, inspector as drawer if necessary |
| `390 × 844` | Task-first mobile composition; intact status and actions; structured DAG/table alternative |

Additionally test intermediate widths, 200% and 400% browser zoom, long strings, and compact/normal density. Do not clip critical actions/status. Allow **local** scroll in logs and dense tables; avoid unexplained global horizontal overflow.

An inspector or navigator hidden at small widths must have an accessible restoration control. Do not miniaturize a DAG until unreadable; use an equivalent ordered job/dependency list. Preserve mode access (Visual/Form/YAML) and review states even when the layout adapts.

---

## 16. Accessibility, localization, and interaction

**Target:** WCAG 2.2 AA for web interfaces; this is a design target, **not certification**.

- Contrast goals: ordinary text at least `4.5:1`; qualifying large text `3:1`; essential non-text boundaries and focus `3:1` where applicable.
- Evaluate contrast on actual rendered opaque/translucent surfaces and all relevant states; do not assume isolated HEX pairs prove WCAG conformance.
- Preserve visible keyboard focus independent from selection; ensure Tab/Shift+Tab, Enter/Space, arrow navigation in trees/grids, Escape dismissal, and return focus for overlays.
- Use accessible names for icon-only actions; tooltips supplement, not replace, accessible labels.
- Pair states with wording plus icon/shape; color is never the sole evidence.
- Make errors, live-region messages, confirmations, and permission denials understandable and persistent long enough to inspect.
- Respect reduced motion, user zoom, assistive technologies, and high-contrast needs when evaluated.
- Keep Portuguese (Brazil) UI content localization-ready, with longer labels, time zones, numeric formats, and correct technical identifiers.
- Test actual keyboard and screen-reader interaction where possible. CSS focus styling or screenshots alone cannot establish assistive-technology support.

Do not automatically present an untested design as accessible merely because the palette appears high-contrast.

---

## 17. Feedback, permissions, trust, and safety presentation

A high-impact action must state what changes, what can be affected, what approval is required, and what confirmation has actually occurred. For deleting/moving projects, rotating credentials, changing access, installing plugins, cancelling builds, or deploying releases, use a clear review/impact stage.

Display permission-denied and not-yet-authorized actions honestly. Avoid optimistic confirmation of administrative operations before service acknowledgment. A retry is an explicit new attempt. Unknown post-cancel effects are not shown as rolled back. Distinguish disconnected agent from failed test and rejected permission from missing credentials.

Mockups and static HTML prototypes must visibly indicate simulation; interactive controls must either demonstrate a clear local behavior or accurately explain unavailable real effects. Never imply actual authentication, production integrations, or applied policy from a UI animation.

---

## 18. Ec token migration — previous Ec to Ox visual reference

This is a **planned visual migration mapping**, not evidence that every component has already changed.

| Previous Ec role / example | New target | Migration guidance |
| --- | --- | --- |
| Primary action `#175CD3` | Ox action `#28679F` | Audit primary buttons, active controls, links, and focus; check contrast and feedback |
| Darker primary action variants | Ox strong action `#205483` | Use only in appropriate strong/pressed contexts with tested contrast |
| Ec neutral shell | Ox shell `#243C59` and deep shell `#182535` | Preserve Ec navigation geometry; avoid painting all tool panels dark blue |
| Light canvas `#F5F6F8` / later Ec `#EDF0F4` | Evaluate Ox neutral candidate `#F7F8FA` | PROPOSED until visual comparison and adoption |
| Navigation/tool surfaces | Evaluate Ox `#F2F4F6` / `#E8ECEF` | PROPOSED; keep workbench spatial hierarchy |
| Light selection `#E9F1FF` | Ox selection `#E8F2FD` | Keep selected marker distinct from focus |
| Primary text from prior Ec | Ox `#263548` | Check readable contrast and visual hierarchy |
| Supporting text from prior Ec | Ox `#43566E` and `#52657C` | Audit labels, metadata, dense data grids |
| Existing success/failure/warning styles | Ox `#226B50`, `#A53848`, `#80521D` families | Preserve semantics and full state coverage; verify all surfaces |
| Context teal/violet/brown | Ox `#216C73`, `#5D5E9F`, `#985F40` | Use for contextual relationships, not generic status substitutes |
| Inter interface font | **IBM Plex Sans** | Compare font metrics and reflow; retain fallback handling |
| IBM Plex Mono | **IBM Plex Mono** | Preserve; adopt Ox source sizing for YAML/logs/diff where legible |
| Ec Signal Glyphs | **Ec Signal Glyphs** | No replacement; adapt semantic coloring and typography alignment only |
| Ec Precision Workbench | **Ec Precision Workbench** | Preserve shell, view composition, components, interactions and navigation |

For each migration, identify actual source components, expected before/after, required screenshot pair, theme, density, and potential regressions. Do not change form, table, node, and inspector geometry only to mimic Ox's desktop sizing.

---

## 19. Source assets, licensing, and safe reuse

Keep the Ec logo, Ec Signal Glyphs, and original product iconography. Reuse an Ox **color value** and **typeface choice** without copying Ox logos, illustrations, layouts, native renderer code, or product-specific terminology.

- Use properly licensed IBM Plex assets and document font provenance and weights.
- Do not attach or redistribute font binaries as a design document deliverable unless distribution rights and project packaging are explicitly handled.
- SVGs must not contain scripts, hidden external references, or mixed semantic conventions.
- Images from earlier Ec versions are design references, not proof that functionality is implemented.
- Maintain a consistent collection naming convention: domain, screen, theme, viewport, state, revision.

---

## 20. Screen briefs, prototypes, and review artifacts

Every new Ec screen or substantial redesign must specify:

1. Domain, screen, and navigation placement.
2. Persona, permissions, primary user task, and expected outcome.
3. View mode: Visual, Form, YAML, consultation, or operational monitoring.
4. Viewport, theme, density, responsive alternative, and zoom expectations.
5. Data fixture, entity relationships, units, provenance, and state freshness.
6. Primary/secondary/destructive actions, authorization and risk.
7. Canonical YAML reference if desired declarative configuration is involved.
8. Critical interactions: selection, editing, invalid input, review, cancel, confirm, and unavailable states.
9. Existing Ec components/tokens reused and any proposed deviations.
10. Evidence of inspection: screenshots, keyboard, accessibility, and scenario results as actually executed.

Expected design artifacts include navigation maps, user flows, annotated wireframes, high-fidelity Light/Dark views, responsive variants, component specifications, critical-state library, navigable prototype where applicable, and before/after comparisons. A static image is a visual reference, not a functional or usability test.

---

## 21. Quality assurance, evidence, and acceptance

### 21.1 Review order

1. Identify the actual Ec source revision and the screenshot/prototype under review.
2. Inventory the **current** palette/type usage and user journeys; do not guess missing screens.
3. Classify defects: **P0** safety/accessibility/false-state, **P1** blocked workflow, **P2** material friction, **P3** polish.
4. Fix semantic, permission, accessibility, and navigation issues before cosmetic refinements.
5. Apply Ox palette and IBM Plex typography to identical fixtures and comparable viewports.
6. Inspect Light/Dark and normal/compact with before/after captures.
7. Check focus, keyboard routes, long content, SVG alignment, color semantics, and data accuracy.
8. Record what was verified, what remained conceptual, and which candidates were adopted or rejected.

### 21.2 Deterministic design acceptance gates

- Zero loss of critical status/actions on target widths, with documented scroll alternatives.
- Shared visible components consume approved tokens or a recorded exception; new hard-coded colors are reviewed.
- All **verified** relevant contrast pairs meet their applicable WCAG targets.
- Primary task remains visually dominant and reachable; independent panels do not compete unnecessarily.
- Light/Dark and responsive layouts carry the same critical information and actions.
- Visual/Form/YAML show one conceptual desired configuration with explicit draft/published/effective distinctions.
- No fake telemetry, inferred causes, plugin trust, authorization, saved state, or deployment success.
- Original Ec glyphs and domain layouts remain coherent after typography/color migration.
- No accidental return to Inter or the former Ec blue as an undocumented system default.

### 21.3 Comparative visual-quality assessment

Use qualitative and optionally scored comparison of visual hierarchy, typography, composition, palette/contrast, data-visualization craft, component finishing, and distinctiveness. A score is an **internal heuristic**, not external or scientific validation. Compare identical content at the same viewport, density, and theme. Where possible, test comprehension and task completion with representative engineers/operators instead of presuming visual preference implies productivity.

### 21.4 Documentation of actual verification

For every reported test include: exact screen/build, browser/device/viewport, source fixture, tested state, tool/method, expected result, actual result, and limitation. Distinguish captured, inspected, interacted, automated-checked, and assistive-tested coverage. Do not equate token comparison with correct rendered UI or a mock click with server authorization.

---

## 22. Future Ec design coverage

Continue Ec's nine-domain roadmap using one design system and the migrated visual palette/typography. Prioritize complete user journeys over accumulating shallow pages. Indicative workstreams:

- Infrastructure: agent inventory, pool capacity, compatibility, maintenance, diagnostics, connectivity.
- Deliveries: environments, approvals, release/promotions, deployment evidence and appropriate rollback UI.
- Extensions & Integrations: versioned plugin catalog, requested permissions, compatibility, origin and health.
- Administration: security policies, instance settings, retention, audit and observability.
- Extended project, people/access, pipeline, and execution experiences where coverage audits identify real gaps.

Feature names and screens in this document are design coverage objectives, **not claims of existing backend support**. Track each as proposed, designed, implemented, verified, or released with explicit evidence.

---

## 23. Do / Don't

### Do

- Use the **Ox exact source palette** with retained semantics and **IBM Plex Sans/Mono** as the Ec reference typography.
- Keep the **Ec Precision Workbench layout**, nine domains, Ec Signal Glyphs, and task-specific workspaces.
- Use neutral surfaces with intentional color accents, not uniform blue or white.
- Prefer readable tables, trees, DAGs, timelines, logs, editors, and contextual inspectors over generic cards.
- Preserve clear labels, timestamps, scope, units, freshness, and source metadata.
- Make critical states inspectable and distinguish configuration from operational observation.
- Treat Dark values not provided by Ox as **proposed Ec adaptations** until evaluated.
- Document typography/token migration and validate actual content reflow.

### Don't

- Copy the Ox navigation, task/plan architecture, native Iced/Rust design constraints, or desktop-specific components.
- Rebrand Ec, replace Ec Signal Glyphs, or redesign every layout to mimic Ox.
- Treat proposed colors as locked source values or claim untested WCAG compliance.
- Convert declarative Ec configuration to JSON, TOML, XML, or a private DSL.
- Use tiny text, unreadable logs, color-only warnings, or universal cards to improve perceived density.
- Make invented operational metrics, integrations, plugin trust, or publication appear genuine.
- Use teal for generic success or purple for unknown conditions.

---

## 24. Open Design generation guide

**Design system:** `Ec / Signal — Precision Workbench`  
**Color reference:** exact Ox palette documented in §3; neutral Light candidates require review  
**Typography:** IBM Plex Sans + IBM Plex Mono  
**Icons:** existing Ec Signal Glyphs SVG system  
**Primary theme:** Light Precision; alternative: Dark Precision with explicitly proposed dark-role values  
**Product:** full-scope Ec CI/CD web platform, not Ox native desktop software  
**Interface language:** Brazilian Portuguese  
**Prototype status:** demonstration only unless a supported service and verification are provided

For each design:

1. Read and apply the two mandatory Ec normative files before working.
2. Use this document for palette, typography, and Ec visual presentation.
3. Audit the current Ec screen or component; avoid replacing functional layouts blindly.
4. Choose a task-appropriate composition with a dominant workspace and contextual inspector as needed.
5. Apply the Ox source colors semantically; do not color every surface blue, violet, or teal.
6. Apply IBM Plex typography and ensure real text fits; adjust geometry only where needed.
7. Reuse Ec Signal Glyphs with clear accessible labeling.
8. Show Light/Dark, relevant responsive states, keyboard/focus, permissions, and realistic data labeling.
9. Make Visual/Form/YAML and draft/revision/publication/synchronization distinctions visible where relevant.
10. Compare against the existing Ec visual baseline and state exact verification limits.

**Ready-to-use one-paragraph brief (English):**

> Design or refine this Ec / Signal enterprise CI/CD workspace in the established Precision Workbench composition. Keep Ec's navigation, resource hierarchy, panels, domain workflows, and Ec Signal Glyphs. Adopt the exact Ox legacy color roles for Light and IBM Plex Sans/Mono typography; use neutral surfaces, institutional slate-blue chrome, action blue for interaction, and restrained teal/violet/brown contextual markers where their meanings are explicit. Propose and test Dark counterparts without attributing invented values to Ox. Preserve YAML as the sole canonical source of desired declarative resource configuration, retain Visual/Form/YAML semantic equivalence as a requirement, and distinguish demonstrative from operational states. Prioritize legible technical data, accessible interaction, functional density, and high-quality Light/Dark responsive layouts over decorative UI.

---

## 25. References, provenance, and limitations

### Ec authoritative files

- `EC-REGRAS-CRIACAO-DE-TELAS-E-IMAGENS.md` — mandatory visual/interface requirements.
- `EC-REGRAS-DE-DESIGN-E-PRODUTO.md` — mandatory product architecture, YAML, UX, security, accessibility, and engineering constraints.

### Color and typography source

- Supplied Ox `DESIGN.md`, revision **4.1**, dated **November 11, 2026** — used **exclusively** for palette and typography. Its Light values and role names are preserved exactly in §3 and its IBM Plex scale is retained in §4. Native desktop layout, Ox functional screens, Iced integration, task/evidence contracts, and SDD workflows are explicitly **not transferred**.

### Ec visual continuity

- Ec / Signal Precision Atelier and Precision Workbench design materials, including the supplied Ec visual bundle with `signal.css`, `workbench.css`, `projects.css`, and handoff. Existing versions are evidence of layout and components, not proof of current production deployment.
- Ec Signal Glyphs visual-system materials, when available, remain the source for icons.

### External standards and technical references

- WCAG 2.2: https://www.w3.org/TR/WCAG22/
- WAI-ARIA Authoring Practices: https://www.w3.org/WAI/ARIA/apg/
- YAML 1.2.2: https://yaml.org/spec/1.2.2/
- OWASP CI/CD Security: https://cheatsheetseries.owasp.org/cheatsheets/CI_CD_Security_Cheat_Sheet.html
- IBM Plex provenance: https://github.com/IBM/plex

### Design acceptance limitation

This document specifies the **intended** Ec visual system. It does not demonstrate successful migration to IBM Plex Sans, deployment of Ox colors, accessibility conformance, actual server operations, source-compatible YAML editing, or user-tested preference. Verify those claims in the real Ec consumer and retain separate evidence for each.

**Final rule:** every Ec screen should make clear **where the user is, what is being inspected, what can be done, what the effects and permissions are, which YAML defines desired configuration when applicable, and what the system has actually confirmed**. The visual identity is Ec; the only imported Ox design primitives are the explicitly documented **palette and typography**.
