# Ec / Signal v0.10 — Enterprise Workbench

Abra `index.html` diretamente no navegador. Nenhum servidor, build ou serviço é necessário. A identidade evolui Precision Atelier para Precision Workbench; a direção A foi selecionada e a B permanece como exploração comparável.

## Base preservada

A v0.9 navegável está em `baseline/v09/index.html`, com cópias dos três fontes visuais e do handoff/manifesto anteriores. As documentações históricas v0.9 agora apontam para essa entrada preservada. A v0.8 permanece em `v08.html`. O pacote Projeto-Ec.zip não foi recebido; foi usada a base editável local, sem inferir conteúdo ausente.

## Fontes e sistema

- `workbench.css`: materiais, hierarquia, geometria e reflow compartilhados.
- `workbench.js`: apresentação do shell, comandos, biblioteca e propriedades redimensionáveis.
- `index.html`: mantém funções, fixture e handlers anteriores, com chamada da camada visual no render.
- `signal.css`, `projects.css`, `project-workspace.js`: padrões e fluxos existentes reutilizados.
- `fixtures/projects-v09.json`: fixture preservada; nenhum proprietário, política real ou métrica foi acrescentado.
- `docs/v010/`: auditoria, direções, sistema consolidado e migração, biblioteca, antes/depois, mockups, validação e roadmap.
- `mockups/v010/`: 117 capturas reais. Antes/depois usa1440×900, Normal e a mesma seleção por workspace.
- `tests/v010/`: scripts reproduzíveis e resultados finais; registro inicial do seletor ambíguo preservado.

## Uso e estados

Navegue pelos cinco workspaces no rail. O botão da command bar expande a navegação. Tema e densidade têm comandos diretos; Ctrl/Cmd+K abre a busca. Propriedades podem ser recolhidas. Em desktop, arraste o divisor ou use setas, Home e End. Em mobile, use o menu e a árvore revelável; todos os modos e propostas permanecem acessíveis. A biblioteca de jobs é recolhível.

Os três percursos de Projetos e os três históricos continuam demonstrativos. Propostas terminam em pendência; nenhum clique publica ou concede acesso. Campos alternam entre as mesmas projeções locais; YAML arbitrário, schema e round-trip real não foram implementados. O estado operacional não é convertido em configuração desejada.

## Verificações

28 verificações funcionais;222 amostras responsivas sem overflow global;30 pares de contraste; paridade de conteúdo Light/Dark; fixture completa idêntica à baseline. Registros em `docs/v010/validation.html`. Sem alegação de WCAG integral, produtividade, autorização, telemetria ou usabilidade comprovadas. Leitores de tela, dispositivos touch reais, outros navegadores, zoom200% e grande escala permanecem pendentes.

## Próximos passos de design

Infrastructure Operations; Delivery & Environments; Extensions & Administration. Auditar cobertura histórica antes de assumir ausências. Ver `docs/v010/roadmap.html`.
