import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const root=new URL('.',import.meta.url);
const src=file=>fs.readFileSync(new URL(file,root),'utf8');
const html=src('index.html'),css=src('ec-enterprise.css'),js=src('ec-enterprise.js');
assert(html.includes('ec-enterprise.css'),'theme CSS linked');
assert(html.includes('ec-enterprise.js'),'four domain JS linked');
assert(html.includes("const names={projects:"),'old navigation retained');
for(const v of ['overview','projects','pipelines','executions','deliveries','infrastructure','people','extensions','administration']) assert(html.includes(`${v}:'`),`view ${v} should have navigation name`);
const sandbox={document:{addEventListener:()=>{}},state:{theme:'light',density:'normal'},button:(t,a,c='',ex='')=>`<button data-action="${a}" class="${c}" ${ex}>${t}</button>`,icon:(n)=>`<i>${n}</i>`,heading:(k,t,d,a='')=>`<header><h1>${t}</h1><p>${d}</p>${a}</header>`,esc:(s)=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;'),status:(label,type)=>`<span class="${type}">${label}</span>`,render:()=>{},announce:()=>{},setView:()=>{}};
vm.createContext(sandbox);vm.runInContext(js,sandbox);
const required={infrastructure:['Inventário de agentes','linux-runner-03','Windows','Conectividade'],deliveries:['Ambientes','Desenvolvimento','Homologação','Produção'],extensions:['Git Provider','Não verificado','Nenhuma extensão'],administration:['Aparência','IBM Plex Sans','Dark Precision']};
for(const [view,texts] of Object.entries(required)){
 const page=vm.runInContext(`ecEnterpriseView('${view}')`,sandbox);
 assert(page.length>1000,`${view} page length`);
 for(const term of texts) assert(page.includes(term),`${view} should contain ${term}`);
 assert(!page.includes('undefined'),`${view}: undefined content`);
 console.log('PASS view',view,'chars',page.length);
}
for(const [view,tab] of [['infrastructure','pools'],['infrastructure','diagnostics'],['deliveries','approvals'],['deliveries','history'],['extensions','permissions'],['extensions','configuration'],['administration','policies'],['administration','audit']]){
 const key={infrastructure:'infraTab',deliveries:'deliverTab',extensions:'extensionsTab',administration:'adminTab'}[view];
 vm.runInContext(`ecUI.${key}='${tab}'`,sandbox);
 const page=vm.runInContext(`ecEnterpriseView('${view}')`,sandbox);
 assert(page.length>700,`${view}/${tab} content`);
 assert(!page.includes('undefined'),`${view}/${tab}: undefined content`);
 console.log('PASS tab',view,tab,'chars',page.length);
}
for(const token of ['#243C59','#182535','#28679F','#205483','#216C73','#5D5E9F','#985F40','#A53848','#775C8B']) assert(css.toLowerCase().includes(token.toLowerCase()),`missing source color ${token}`);
for(const term of ['IBM Plex Sans','IBM Plex Mono','prefers-reduced-motion','focus-visible','data-theme=dark'])assert(css.includes(term),`missing CSS ${term}`);
assert(html.indexOf('<script src="ec-enterprise.js"') < html.indexOf('<script src="project-workspace.js"'),'scripts loaded before initial project render');
console.log('PASS source palette / font / accessible controls / script order');
